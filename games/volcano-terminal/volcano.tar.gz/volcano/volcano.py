#!/usr/bin/env python3
"""Volcano Adventure (terminal edition) - entry point.

    python3 volcano.py [--ascii] [--no-music] [--no-voice] [--seed N] [--autoplay]
"""
import argparse
import atexit
import locale
import os
import signal
import sys
import time

os.environ.setdefault("ESCDELAY", "25")   # make Esc respond quickly

import curses  # noqa: E402

import game as G  # noqa: E402
from audio import Audio  # noqa: E402
from render import Renderer  # noqa: E402

FPS = 30
AUTOPLAY_DELAY = 0.6
AUTOPLAY_WIN_HOLD = 3.0


def key_name(k):
    if k in (10, 13, curses.KEY_ENTER):
        return "enter"
    if k == 32:
        return "space"
    if k == 27:
        return "esc"
    arrows = {curses.KEY_LEFT: "left", curses.KEY_RIGHT: "right",
              curses.KEY_UP: "up", curses.KEY_DOWN: "down"}
    if k in arrows:
        return arrows[k]
    if 0 <= k < 128:
        ch = chr(k)
        if ch.isalpha():
            return ch.lower()
        if ch.isdigit():
            return ch
    return None


def run(stdscr, args, audio):
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    stdscr.nodelay(True)
    stdscr.keypad(True)
    renderer = Renderer(stdscr, ascii_mode=args.ascii)
    game = G.Game(seed=args.seed, music_on=not args.no_music,
                  voice_on=not args.no_voice)
    frame = 1.0 / FPS
    win_since = None
    while True:
        now = time.monotonic()
        game.update(now)
        resized = False
        while True:
            k = stdscr.getch()
            if k == -1:
                break
            if k == curses.KEY_RESIZE:
                try:
                    curses.update_lines_cols()
                except AttributeError:
                    pass
                renderer.resize()
                resized = True
                continue
            game.key(key_name(k))
        if args.autoplay:
            if game.state == G.WIN:
                if win_since is None:
                    win_since = now
                elif now - win_since >= AUTOPLAY_WIN_HOLD:
                    break
            else:
                win_since = None
                k = game.expected_key()
                if k and now - game.prompt_time >= AUTOPLAY_DELAY:
                    game.key(k)
        for ev in game.pop_events():
            audio.handle(ev)
        audio.tick()
        if game.quit:
            break
        renderer.frame(game, now, force=resized)
        spare = frame - (time.monotonic() - now)
        if spare > 0:
            time.sleep(spare)   # frame pacing only; game delays use the timer queue


def main(argv=None):
    p = argparse.ArgumentParser(description="Volcano Adventure - a letter-learning "
                                "'floor is lava' game for the terminal.")
    p.add_argument("--ascii", action="store_true", help="ASCII-only sprites and borders")
    p.add_argument("--no-music", action="store_true", help="start with music off")
    p.add_argument("--no-voice", action="store_true", help="start with speech off")
    p.add_argument("--seed", type=int, default=None, help="fixed random seed")
    p.add_argument("--autoplay", action="store_true",
                   help="the game plays itself (smoke test), then exits")
    args = p.parse_args(argv)

    locale.setlocale(locale.LC_ALL, "")
    enc = (locale.getpreferredencoding(False) or "").lower().replace("-", "")
    if enc != "utf8":
        args.ascii = True   # terminal can't show Unicode: fall back safely

    audio = Audio(music_on=not args.no_music, voice_on=not args.no_voice)
    atexit.register(audio.close)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        signal.signal(signal.SIGHUP, lambda *_: sys.exit(0))
    except (AttributeError, ValueError):
        pass
    try:
        curses.wrapper(run, args, audio)
    except KeyboardInterrupt:
        pass
    finally:
        audio.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
