#!/usr/bin/env python3
"""Volcano Adventure - graphics edition (pygame).

    python3 volcano_gfx.py [--window] [--res 540|720|1080] [--no-music]
                           [--no-voice] [--seed N] [--autoplay] [--fps N]

Same game rules as the terminal edition (game.py); this file only adds a
window, pictures and pygame sound. Needs pygame (sudo apt install python3-pygame).
"""
import argparse
import os
import shutil
import sys
import threading
import time

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "1")    # smooth scaling to the screen

import pygame  # noqa: E402

import audio as A  # noqa: E402
import game as G  # noqa: E402
import voice  # noqa: E402
from gfx import DH, DW, Renderer  # noqa: E402

AUTOPLAY_DELAY = 0.6
AUTOPLAY_WIN_HOLD = 3.0


class MixerAudio(A.Audio):
    """Music and effects through pygame.mixer (no child processes);
    speech still goes through espeak-ng / espeak / spd-say."""

    def __init__(self, music_on, voice_on):
        super().__init__(music_on, voice_on, enabled=False)
        for name in A.SPEAKERS:
            path = shutil.which(name)
            if path:
                self.speaker = (name, path)
                break
        self.sounds = {}
        self._raw = {}
        self._clip_cache = {}
        self.channel = None
        pygame.mixer.set_num_channels(12)
        pygame.mixer.set_reserved(1)            # channel 0 is the guide's voice
        self.voice_chan = pygame.mixer.Channel(0)
        threading.Thread(target=self._synth_raw, daemon=True).start()

    def _synth_raw(self):
        try:
            for name in A.SFX:
                self._raw[name] = A.render_sfx(name)
            self._raw["music"] = A.render_music()
        except Exception:
            pass

    def play(self, name):
        if self.music_on and name in self.sounds:
            self.sounds[name].play()

    # ---- pre-recorded voice through the mixer (espeak only as a fallback)
    def say(self, text):
        if not self.voice_on:
            return
        clips = voice.clips_for(text)
        if not clips:
            return super().say(text)
        try:
            freq, size, ch = pygame.mixer.get_init()
            gap = b"\0" * (int(freq * voice.GAP) * (abs(size) // 8) * ch)
            raws = []
            for p in clips:
                raw = self._clip_cache.get(p)
                if raw is None:
                    raw = self._clip_cache[p] = pygame.mixer.Sound(p).get_raw()
                raws.append(raw)
            self.stop_speech()
            self.voice_chan.play(pygame.mixer.Sound(buffer=gap.join(raws)))
        except Exception:
            super().say(text)

    def stop_speech(self):
        if getattr(self, "voice_chan", None):
            self.voice_chan.stop()
        super().stop_speech()

    def handle(self, event):
        kind, val = event
        if kind == "music" and not val and self.channel:
            self.channel.stop()
            self.channel = None
        super().handle(event)

    def tick(self):
        # turn finished synthesis into Sounds on the main thread
        for name in list(self._raw):
            try:
                self.sounds[name] = pygame.mixer.Sound(buffer=self._raw.pop(name))
            except Exception:
                pass
        if self.music_on and "music" in self.sounds:
            if self.channel is None or not self.channel.get_busy():
                self.channel = self.sounds["music"].play(loops=-1)
        if self.procs:
            self.procs = [p for p in self.procs if p.poll() is None]

    def close(self):
        try:
            pygame.mixer.stop()
        except Exception:
            pass
        super().close()


def make_audio(args):
    try:
        pygame.mixer.pre_init(A.RATE, -16, 1, 1024)
        pygame.mixer.init()
        if pygame.mixer.get_init():
            return MixerAudio(not args.no_music, not args.no_voice)
    except Exception:
        pass
    # no sound device for pygame: fall back to aplay & co (or silence)
    return A.Audio(not args.no_music, not args.no_voice)


KEYMAP = {pygame.K_RETURN: "enter", pygame.K_KP_ENTER: "enter", pygame.K_SPACE: "space",
          pygame.K_ESCAPE: "esc", pygame.K_LEFT: "left", pygame.K_RIGHT: "right",
          pygame.K_UP: "up", pygame.K_DOWN: "down"}


def key_name(ev):
    if ev.key in KEYMAP:
        return KEYMAP[ev.key]
    if pygame.K_a <= ev.key <= pygame.K_z:
        return chr(ev.key)
    if pygame.K_0 <= ev.key <= pygame.K_9:
        return chr(ev.key)
    if pygame.K_KP0 <= ev.key <= pygame.K_KP9:
        return str(ev.key - pygame.K_KP0)
    return None


def main(argv=None):
    p = argparse.ArgumentParser(description="Volcano Adventure - graphics edition")
    p.add_argument("--window", action="store_true", help="run in a window instead of full screen")
    p.add_argument("--res", type=int, choices=(540, 720, 1080), default=None,
                   help="drawing resolution (default 720, or the screen height if smaller)")
    p.add_argument("--fps", type=int, default=30, help="frames per second (default 30)")
    p.add_argument("--no-music", action="store_true", help="start with music off")
    p.add_argument("--no-voice", action="store_true", help="start with speech off")
    p.add_argument("--seed", type=int, default=None, help="fixed random seed")
    p.add_argument("--autoplay", action="store_true", help="the game plays itself, then exits")
    args = p.parse_args(argv)

    try:
        pygame.display.init()
    except pygame.error as e:
        print(f"Can't open a graphics screen here ({e}).", file=sys.stderr)
        return 3            # the launcher then starts the text version
    pygame.font.init()
    info = pygame.display.Info()
    screen_h = info.current_h if info.current_h > 0 else 720
    res = args.res or min(720, max(540, screen_h))
    K = res / DH
    size = (int(round(DW * K)), int(round(DH * K)))
    flags = pygame.SCALED
    if not args.window:
        flags |= pygame.FULLSCREEN
    try:
        screen = pygame.display.set_mode(size, flags)
    except pygame.error:
        try:
            screen = pygame.display.set_mode(size)
        except pygame.error as e:
            print(f"Can't open a graphics screen here ({e}).", file=sys.stderr)
            return 3
    pygame.display.set_caption("Volcano Adventure")
    audio = make_audio(args)
    renderer = Renderer(screen, K)
    game = G.Game(seed=args.seed, music_on=not args.no_music, voice_on=not args.no_voice)
    clock = pygame.time.Clock()
    win_since = None
    last = time.monotonic()
    try:
        while not game.quit:
            now = time.monotonic()
            dt = min(0.1, now - last)
            last = now
            game.update(now)
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    game.quit = True
                elif ev.type == pygame.KEYDOWN:
                    game.key(key_name(ev))
                elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    if game.confirm_quit:
                        game.key("x")       # tap = keep playing
                    elif game.state == G.TITLE:
                        game.key("enter")
                    else:
                        game.key(renderer.click(ev.pos))
            if args.autoplay:
                if game.state == G.WIN:
                    win_since = win_since or now
                    if now - win_since >= AUTOPLAY_WIN_HOLD:
                        break
                else:
                    win_since = None
                    k = game.expected_key()
                    if k and now - game.prompt_time >= AUTOPLAY_DELAY:
                        game.key(k)
            for e in game.pop_events():
                audio.handle(e)
            audio.tick()
            renderer.draw(game, now, dt)
            pygame.display.flip()
            clock.tick(args.fps)
    except KeyboardInterrupt:
        pass
    finally:
        audio.close()
        pygame.quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())
