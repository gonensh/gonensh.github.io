"""Volcano Adventure - pure game logic and state machine.

No curses and no audio here. Feed it key names with key() and time with
update(); read its public attributes; drain pop_events() for sounds/speech.

Key names: 'a'..'z', '0'..'9', 'enter', 'space', 'esc',
           'left', 'right', 'up', 'down'.
Events:    ('sound', name) ('say', text) ('music', bool) ('voice', bool)
"""
import heapq
import random
import time

# ---------------------------------------------------------------- data

KEY_POS = {
    'Q': (0, 0.5), 'W': (0, 1.5), 'E': (0, 2.5), 'R': (0, 3.5), 'T': (0, 4.5),
    'Y': (0, 5.5), 'U': (0, 6.5), 'I': (0, 7.5), 'O': (0, 8.5), 'P': (0, 9.5),
    'A': (1, 1.0), 'S': (1, 2.0), 'D': (1, 3.0), 'F': (1, 4.0), 'G': (1, 5.0),
    'H': (1, 6.0), 'J': (1, 7.0), 'K': (1, 8.0), 'L': (1, 9.0),
    'Z': (2, 2.0), 'X': (2, 3.0), 'C': (2, 4.0), 'V': (2, 5.0), 'B': (2, 6.0),
    'N': (2, 7.0), 'M': (2, 8.0),
}

LEVELS = [
    ("Base Camp", 3, "FJ"),
    ("Rocky Ledge", 4, "ASDFJKL"),
    ("Steam Vents", 4, "ASDFGHJKL"),
    ("Vowel Ridge", 5, "ASDFGHJKLEIOU"),
    ("High Ridge", 5, "QWERTYUIOPASDFGHJKL"),
    ("The Summit", 6, "ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
]

CUM = []
_total = 0
for _name, _steps, _letters in LEVELS:
    _total += _steps
    CUM.append(_total)
TOTAL = CUM[-1]
GEMS_TOTAL = len(LEVELS)

ORDER = ["run", "row", "slug", "run", "row"]

CHEERS = ["Woohoo!", "Nice jump!", "You got it!", "Great!", "Way to go!",
          "Awesome!", "Super!"]


def calls(letter):
    return [f"Jump to {letter}!", f"Find the {letter}!", f"Hop to {letter}!",
            f"Where's {letter}? Press it!"]


RUN_MOVES = ("left", "right", "hop", "duck")

# move -> (prompt text, speech, keys)
MOVES = {
    "left": ("⬅️ Jump Left!", "Jump left!", ("left", "a")),
    "right": ("➡️ Jump Right!", "Jump right!", ("right", "d")),
    "hop": ("⬆️ Hop!", "Hop!", ("up", "w", "space")),
    "duck": ("⬇️ Duck!", "Duck!", ("down", "s")),
    "row": ("🚣 Row!", "Row!", ("space", "enter", "up", "right")),
    "throw": ("🐌 Throw an ice gem!", "Throw an ice gem at the slug!",
              ("space", "enter")),
    "chest": ("🧰 Open the chest — press A!", "A treasure chest! Press A!",
              ("a",)),
    "zap": ("🐌 Zap the slug — press B!", "The slug is back! Press B!",
            ("b",)),
}
RUN_KEYS = {k for m in RUN_MOVES for k in MOVES[m][2]}

TITLE, CLIMB, INTERLUDE, SPACE, WIN = "title", "climb", "interlude", "space", "win"

BANNERS = {
    "run": ("THE FLOOR IS LAVA!", 1.3, "The floor is lava! Follow the moves!", 0.95),
    "row": ("THE FLOOR IS LAVA!", 1.3, "The floor is lava! Time to row!", 0.95),
    "slug": ("A VOLCANIC SLUG!", 1.5, "Uh oh — a volcanic slug! Get ready!", 1.15),
}

ROCK_W = 7


def col_x(letter, play_width, rock_width=ROCK_W):
    """Horizontal centre of a rock for this letter, from its keyboard column."""
    margin = rock_width / 2.0 + 2
    _r, c = KEY_POS[letter.upper()]
    return margin + ((c - 0.5) / 9.0) * (play_width - 2 * margin)


def ease_out(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


# ---------------------------------------------------------------- game

class Game:
    def __init__(self, seed=None, music_on=True, voice_on=True,
                 clock=time.monotonic):
        self.rng = random.Random(seed)
        self.clock = clock
        self.now = clock()
        self.music_on = music_on
        self.voice_on = voice_on
        self.events = []
        self.quit = False
        self.confirm_quit = False
        self.version = 0
        self._seq = 0
        self._reset_fields()
        self.state = TITLE
        self._ready()

    # ---- infrastructure
    def _reset_fields(self):
        self.timers = []
        self.tweens = {}
        self.level = 0
        self.cur = 0
        self.gems = 0
        self.rocks = []
        self.target = None
        self.accepting = False
        self.prompt_time = self.now
        self.state_time = self.now
        self.kind = None          # interlude kind
        self.moves = []
        self.step = 0
        self.done = 0
        self.banner = ""
        self.prompt = ""          # bottom panel prompt for move sections
        self.speech = ""
        self.boat = False
        self.snail = False
        self.obj = None           # 'slug' | 'chest' during slug fight
        self.obj_letter = None
        self.obj_frozen = False
        self.chest_open = False
        self.ball = False
        self.ball_frozen = False
        self.win_text = False

    def _set_state(self, s):
        self.state = s
        self.state_time = self.now
        self.version += 1

    def schedule(self, delay, callback):
        self._seq += 1
        heapq.heappush(self.timers, (self.now + delay, self._seq, callback))

    def tween(self, name, duration, data=None):
        self.tweens[name] = (self.now, duration, data)

    def tween_t(self, name, now=None):
        """(progress 0..1, data) for a tween, or None if never started."""
        tw = self.tweens.get(name)
        if not tw:
            return None
        now = self.now if now is None else now
        start, dur, data = tw
        t = 1.0 if dur <= 0 else (now - start) / dur
        return max(0.0, min(1.0, t)), data

    def animating(self, now=None):
        now = self.now if now is None else now
        return any(now < s + d for s, d, _ in self.tweens.values())

    def update(self, now=None):
        self.now = self.clock() if now is None else now
        ran = False
        while self.timers and self.timers[0][0] <= self.now:
            _due, _seq, cb = heapq.heappop(self.timers)
            cb()
            ran = True
        if ran:
            self.version += 1

    def pop_events(self):
        ev, self.events = self.events, []
        return ev

    def _sound(self, name):
        self.events.append(("sound", name))

    def _say(self, text):
        self.speech = text
        self.events.append(("say", text))
        self.tween("guide", 0.5)

    def _ready(self):
        self.accepting = True
        self.prompt_time = self.now
        self.version += 1

    # ---- public helpers
    def level_name(self):
        return LEVELS[self.level][0]

    def level_letters(self):
        return LEVELS[self.level][2]

    def add_rock(self):
        prev = self.rocks[-1] if self.rocks else None
        choices = [c for c in self.level_letters() if c != prev]
        self.rocks.append(self.rng.choice(choices))
        self.target = self.rocks[-1]

    def make_moves(self, kind):
        if kind == "run":
            seq = []
            while len(seq) < 5:
                seq.append(self.rng.choice(
                    [m for m in RUN_MOVES if not seq or m != seq[-1]]))
            return seq
        if kind == "row":
            return ["row"] * 6
        return ["throw", "chest", "zap"]

    def current_move(self):
        if self.state == INTERLUDE and self.moves and self.step < len(self.moves):
            return self.moves[self.step]
        return None

    def expected_key(self):
        """The key that would advance the game right now (for autoplay)."""
        if self.confirm_quit:
            return None
        if self.state == TITLE:
            return "enter"
        if not self.accepting:
            return None
        if self.state == CLIMB:
            return self.target.lower()
        if self.state == INTERLUDE:
            m = self.current_move()
            return MOVES[m][2][0] if m else None
        if self.state == SPACE:
            return "a"
        if self.state == WIN:
            return "enter"
        return None

    # ---- flow
    def start(self):
        """Full reset into CLIMB at Base Camp."""
        self._reset_fields()
        self._set_state(CLIMB)
        self.rocks = [self.rng.choice(LEVELS[0][2])]
        self.add_rock()
        self._say(self.rng.choice(calls(self.target)))
        self._ready()

    def _next_prompt(self):
        self.add_rock()
        self._say(f"{self.rng.choice(CHEERS)} {self.rng.choice(calls(self.target))}")
        self._ready()

    def _start_interlude(self):
        self.kind = ORDER[self.level]
        self._set_state(INTERLUDE)
        self.moves = self.make_moves(self.kind)
        self.step = 0
        self.done = 0
        self.prompt = ""
        text, dur, speech, delay = BANNERS[self.kind]
        self.banner = text
        self.tween("banner", dur)
        self._sound("lava")
        self._say(speech)
        if self.kind == "row":
            self.boat = True
            self.snail = True
            self.tween("snail", 1.2)
        self.schedule(delay, self._interlude_prompt)

    def _interlude_prompt(self):
        m = self.moves[self.step]
        if m in ("throw", "zap"):
            self.obj = "slug"
            self.obj_letter = "B" if m == "zap" else None
            self.obj_frozen = False
            self.tween("objin", 0.6)
            self.tweens.pop("objoff", None)
        elif m == "chest":
            self.obj = "chest"
            self.obj_letter = "A"
            self.obj_frozen = False
            self.chest_open = False
            self.tween("objin", 0.6)
            self.tweens.pop("objoff", None)
        prompt, speech, _keys = MOVES[m]
        self.prompt = prompt
        self._say(speech)
        self._ready()

    def _advance(self):
        self.step += 1
        if self.step >= len(self.moves):
            self._end_interlude()
        else:
            self._interlude_prompt()

    def _end_interlude(self):
        self.boat = False
        self.snail = False
        self.obj = None
        self.obj_letter = None
        self.prompt = ""
        self.moves = []
        self.kind = None
        self._set_state(CLIMB)
        self.level += 1
        self.add_rock()
        self._say(f"Nice moves! Keep climbing — Jump to {self.target}!")
        self._ready()

    def _start_space(self):
        self._set_state(SPACE)
        self.banner = "3… 2… 1… BLAST OFF!"
        self.tween("banner", 1.6)
        self._say("Blast off into space!")
        self.schedule(1.7, self._ball_in)

    def _ball_in(self):
        self.ball = True
        self.ball_frozen = False
        self.tween("ballin", 1.0)
        self.prompt = "☄️ A lava ball! Press A to freeze it!"
        self._say("A lava ball is coming! Press A to throw an ice gem!")
        self._ready()

    def _ball_hit(self):
        self.ball_frozen = True
        self._sound("gem")
        self.prompt = "You froze it! 🧊 You saved the day!"
        self._say(self.prompt)
        self.schedule(0.7, lambda: self.tween("balloff", 1.0))
        self.schedule(1.7, self._win)

    def _win(self):
        self._set_state(WIN)
        self.prompt = ""
        self.tween("confetti", 3.0)
        self._sound("win")
        self._say("You made it to the top of the volcano! You did it!")
        self.schedule(0.7, self._win_text)

    def _win_text(self):
        self.win_text = True
        self._ready()

    # ---- input
    def key(self, name):
        if name is None:
            return
        self.version += 1
        if self.confirm_quit:
            if name == "esc":
                self.quit = True
            self.confirm_quit = False
            return
        if name == "esc":
            if self.state == TITLE:
                self.quit = True
            else:
                self.confirm_quit = True
            return
        if name == "1":
            self.music_on = not self.music_on
            self.events.append(("music", self.music_on))
            return
        if name == "2":
            self.voice_on = not self.voice_on
            self.events.append(("voice", self.voice_on))
            return
        if name == "0":
            self.start()
            return
        if self.state == TITLE:
            if name in ("enter", "space"):
                self.start()
            return
        if not self.accepting:
            return
        if self.state == CLIMB:
            self._climb_key(name)
        elif self.state == INTERLUDE:
            self._interlude_key(name)
        elif self.state == SPACE:
            if name == "a":
                self.accepting = False
                self._sound("good")
                self.tween("throw", 0.45)
                self.schedule(0.45, self._ball_hit)
        elif self.state == WIN:
            if name in ("enter", "space"):
                self.start()

    def _climb_key(self, name):
        if len(name) != 1 or not name.isalpha():
            return
        letter = name.upper()
        if letter not in self.level_letters():
            return
        if letter != self.target:
            self.tween("shake", 0.4)
            self._say(f"That's {letter}. Find {self.target}! It's glowing. ✨")
            return
        # correct
        self.accepting = False
        self.cur += 1
        self._sound("jump")
        self.tween("hop", 0.36, self.cur - 1)
        if self.cur == CUM[self.level]:
            self.gems += 1
            self._sound("gem")
            self.tween("gempop", 0.6)
            if self.cur == TOTAL:
                self.schedule(0.5, self._start_space)
            else:
                self.schedule(0.34, self._start_interlude)
        else:
            self.schedule(0.25, self._next_prompt)

    def _interlude_key(self, name):
        m = self.current_move()
        if m is None:
            return
        keys = MOVES[m][2]
        if m in RUN_MOVES:
            if name in keys:
                self._move_ok(m)
            elif name in RUN_KEYS:
                self._say(f"{MOVES[m][1]} You can do it!")
        elif m == "row":
            if name in keys:
                self._move_ok(m)
        elif m in ("throw", "zap"):
            if name in keys:
                self.accepting = False
                self.done += 1
                self.tween("throw", 0.5)
                self.schedule(0.5, self._freeze_obj)
                self.schedule(0.92, self._advance)
            elif m == "zap" and len(name) == 1 and name.isalpha():
                self._say("Press B!")
        elif m == "chest":
            if name in keys:
                self.accepting = False
                self.done += 1
                self.chest_open = True
                self.obj_letter = None
                self._sound("gem")
                self.tween("sparkle", 0.8)
                self.schedule(0.82, self._advance)
            elif len(name) == 1 and name.isalpha():
                self._say("Press A!")

    def _move_ok(self, m):
        self.accepting = False
        self.done += 1
        self.tween("move", 0.45, m)
        self._sound("good")
        self.schedule(0.52, self._advance)

    def _freeze_obj(self):
        self._sound("gem")
        self.obj_frozen = True
        self.obj_letter = None
        self.tween("objoff", 0.4)
