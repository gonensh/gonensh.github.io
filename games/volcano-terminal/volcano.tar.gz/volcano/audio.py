"""Sound for Volcano Adventure: synthesized WAVs, music loop, effects, speech.

Everything is optional. With no player found the game is silent; with no
speech tool, callouts are text only. Nothing here may crash the game.
"""
import math
import os
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import wave

RATE = 44100

SFX = {
    "jump": [(660, 0, 0.12, "square", 0.18), (990, 0.05, 0.12, "square", 0.15)],
    "good": [(880, 0, 0.10, "square", 0.20), (1320, 0.07, 0.14, "square", 0.17)],
    "gem": [(1047, 0, 0.09, "sine", 0.28), (1568, 0.07, 0.16, "sine", 0.22)],
    "lava": [(140, 0, 0.40, "sawtooth", 0.20), (90, 0, 0.40, "sawtooth", 0.16)],
    "win": [(523, 0.00, 0.2, "square", 0.20), (659, 0.13, 0.2, "square", 0.20),
            (784, 0.26, 0.2, "square", 0.20), (1047, 0.39, 0.2, "square", 0.20)],
}

MELODY = [659, 784, 880, 784, 659, 587, 523, 587,
          659, 784, 880, 1047, 880, 784, 659, 587]
BASS = [131, 196, 220, 175]
BPM = 132
MUSIC_MASTER = 0.42
LOOP_REPEATS = 4          # 4 x 3.64 s ~ 14.5 s per file

PLAYERS = [("pw-play", []), ("paplay", []), ("aplay", ["-q"])]
SPEAKERS = ["espeak-ng", "espeak", "spd-say"]


# ------------------------------------------------------------ synthesis

def _add_tone(buf, freq, start, dur, kind, vol):
    i0 = int(start * RATE)
    n = int(dur * RATE)
    if len(buf) < i0 + n:
        buf.extend([0.0] * (i0 + n - len(buf)))
    att = max(1, int(0.012 * RATE))
    decay = max(1, n - att)
    fall = math.exp(math.log(0.001) / decay)    # reaches -60 dB at the end
    inc = freq / RATE
    ph = 0.0
    env = 0.0
    two_pi = 2 * math.pi
    sin = math.sin
    for j in range(n):
        if j < att:
            env = j / att
        else:
            env *= fall
        ph += inc
        if ph >= 1.0:
            ph -= 1.0
        if kind == "square":
            s = 1.0 if ph < 0.5 else -1.0
        elif kind == "triangle":
            s = 4.0 * abs(ph - 0.5) - 1.0
        elif kind == "sawtooth":
            s = 2.0 * ph - 1.0
        else:
            s = sin(two_pi * ph)
        buf[i0 + j] += s * env * vol


def _to_bytes(buf):
    ints = [int(32767 * (1.0 if v > 1 else (-1.0 if v < -1 else v))) for v in buf]
    return struct.pack("<%dh" % len(ints), *ints)


def _write_wav(path, frames):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(frames)


def render_sfx(name):
    buf = []
    # Like the browser game, effects go through the same 0.42 master
    # volume as the music, which keeps the original balance.
    for f, start, dur, kind, vol in SFX[name]:
        _add_tone(buf, f, start, dur, kind, vol * MUSIC_MASTER)
    return _to_bytes(buf)


def render_music():
    eighth = 60.0 / BPM / 2
    loop_n = int(round(16 * eighth * RATE))
    buf = [0.0] * loop_n
    for i, f in enumerate(MELODY):
        _add_tone(buf, f, i * eighth, 0.9 * eighth, "square", 0.22 * MUSIC_MASTER)
    quarter = 2 * eighth
    for q in range(8):
        f = BASS[(q // 2) % len(BASS)]
        _add_tone(buf, f, q * quarter, 0.95 * quarter, "triangle", 0.28 * MUSIC_MASTER)
    return _to_bytes(buf[:loop_n]) * LOOP_REPEATS


# ------------------------------------------------------------ speech text

_LETTER_AFTER = re.compile(r"\b(to|the|Press|press|That's|Find|Where's) ([A-Z])\b")


def speech_text(text):
    text = text.replace("—", ",").replace("…", ".")
    return "".join(c for c in text if ord(c) < 128).strip()


def speech_ssml(text):
    t = speech_text(text)
    t = t.replace("&", "and").replace("<", " ").replace(">", " ")
    return _LETTER_AFTER.sub(
        r'\1 <say-as interpret-as="characters">\2</say-as>', t)


# ------------------------------------------------------------ audio engine

class Audio:
    def __init__(self, music_on=True, voice_on=True, enabled=True):
        self.music_on = music_on
        self.voice_on = voice_on
        self.player = None
        self.speaker = None
        self.files = {}
        self.procs = []
        self.music_proc = None
        self.speech_proc = None
        self.tmp = None
        self.ready = False
        self._closed = False
        if not enabled:
            return
        for name, extra in PLAYERS:
            path = shutil.which(name)
            if path:
                self.player = [path] + extra
                break
        for name in SPEAKERS:
            path = shutil.which(name)
            if path:
                self.speaker = (name, path)
                break
        if self.player:
            self.tmp = tempfile.mkdtemp(prefix="volcano-audio-")
            # Synthesis takes a few seconds on a slow Pi: do it in the
            # background so the title screen appears at once.
            threading.Thread(target=self._synth, daemon=True).start()

    def _synth(self):
        try:
            for name in SFX:
                if self._closed:
                    return
                path = os.path.join(self.tmp, name + ".wav")
                _write_wav(path, render_sfx(name))
                self.files[name] = path
            if self._closed:
                return
            path = os.path.join(self.tmp, "music.wav")
            _write_wav(path, render_music())
            self.files["music"] = path
            self.ready = True
        except Exception:
            pass

    def _spawn(self, cmd):
        try:
            p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        except Exception:
            return None
        self.procs.append(p)
        return p

    @staticmethod
    def _kill(p):
        if p is None:
            return
        try:
            if p.poll() is None:
                p.kill()
            p.wait(timeout=0.5)
        except Exception:
            pass

    # ---- reacting to game events
    def handle(self, event):
        kind, val = event
        if kind == "sound":
            self.play(val)
        elif kind == "say":
            self.say(val)
        elif kind == "music":
            self.music_on = val
            if not val:
                self._kill(self.music_proc)
                self.music_proc = None
        elif kind == "voice":
            self.voice_on = val
            if not val:
                self.stop_speech()

    def play(self, name):
        if not (self.music_on and self.player):
            return
        path = self.files.get(name)
        if path:
            self._spawn(self.player + [path])

    def say(self, text):
        if not (self.voice_on and self.speaker):
            return
        self.stop_speech()
        name, path = self.speaker
        if name == "spd-say":
            cmd = [path, speech_text(text)]
        else:
            cmd = [path, "-s", "150", "-p", "70", "-a", "120", "-m",
                   speech_ssml(text)]
        self.speech_proc = self._spawn(cmd)

    def stop_speech(self):
        self._kill(self.speech_proc)
        self.speech_proc = None
        if self.speaker and self.speaker[0] == "spd-say":
            try:
                subprocess.run([self.speaker[1], "-C"], timeout=1,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

    def tick(self):
        """Call once per frame: restarts the music loop, reaps children."""
        if self.music_on and self.player and "music" in self.files:
            if self.music_proc is None or self.music_proc.poll() is not None:
                self.music_proc = self._spawn(self.player + [self.files["music"]])
        if self.procs:
            self.procs = [p for p in self.procs if p.poll() is None]

    def close(self):
        self._closed = True
        for p in list(self.procs):
            self._kill(p)
        self.procs = []
        self.music_proc = self.speech_proc = None
        if self.speaker and self.speaker[0] == "spd-say":
            try:
                subprocess.run([self.speaker[1], "-C"], timeout=1,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass
        if self.tmp:
            shutil.rmtree(self.tmp, ignore_errors=True)
            self.tmp = None
