"""Unit tests for game.py (stdlib unittest, fixed seed, fake clock).

    python3 -m unittest test_game
"""
import unittest

import game as G


class FakeClock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


def make(seed=1):
    clock = FakeClock()
    return G.Game(seed=seed, clock=clock), clock


def advance(g, clock, seconds, step=0.02):
    end = clock.t + seconds
    while clock.t < end:
        clock.t += step
        g.update()


def wait_for_key(g, clock, limit=10.0, until=None):
    waited = 0.0
    while g.expected_key() is None and waited < limit:
        if until is not None and until(g):
            return None
        advance(g, clock, 0.05)
        waited += 0.05
    return g.expected_key()


def play_to(g, clock, until, log=None):
    """Press the right keys until until(g) is true. Returns steps taken."""
    for _ in range(2000):
        if until(g):
            return
        k = wait_for_key(g, clock, until=until)
        if until(g):
            return
        if k is None:
            raise AssertionError(f"stuck in {g.state}")
        if log is not None and g.state == G.INTERLUDE and g.kind not in [x[1] for x in log if x[0] == g.level]:
            log.append((g.level, g.kind))
        g.key(k)
        advance(g, clock, 0.05)
    raise AssertionError("never reached target state")


class TestData(unittest.TestCase):
    def test_cumulative(self):
        self.assertEqual(G.CUM, [3, 7, 11, 16, 21, 27])
        self.assertEqual(G.TOTAL, 27)

    def test_column_mapping(self):
        for width in (80, 200):
            xs = [G.col_x(c, width) for c in "QWERTYUIOP"]
            self.assertEqual(xs, sorted(xs))
            self.assertEqual(len(set(xs)), 10)
            unit = (width - 2 * (G.ROCK_W / 2 + 2)) / 9.0
            self.assertAlmostEqual(G.col_x("A", width) - G.col_x("Q", width), unit / 2)
            margin = G.ROCK_W / 2 + 2
            for c in G.KEY_POS:
                x = G.col_x(c, width)
                self.assertGreaterEqual(x, margin)
                self.assertLessEqual(x, width - margin)


class TestRocks(unittest.TestCase):
    def test_no_repeat_and_in_set(self):
        g, _ = make()
        g.start()
        for lv in range(len(G.LEVELS)):
            g.level = lv
            g.rocks = [g.level_letters()[0]]
            for _ in range(1000):
                g.add_rock()
            letters = g.level_letters()
            for a, b in zip(g.rocks[1:], g.rocks[2:]):
                self.assertNotEqual(a, b)
            for r in g.rocks:
                self.assertIn(r, letters)

    def test_rocks_in_level_set_during_play(self):
        g, c = make(3)
        g.start()
        seen = []

        def done(gm):
            if gm.state == G.CLIMB and len(gm.rocks) > gm.cur + 1:
                seen.append((gm.level, gm.target))
            return gm.state == G.WIN
        play_to(g, c, done)
        for lv, letter in seen:
            self.assertIn(letter, G.LEVELS[lv][2])


class TestFlow(unittest.TestCase):
    def test_interlude_order(self):
        g, c = make()
        g.key("enter")
        log = []
        play_to(g, c, lambda gm: gm.state == G.SPACE, log)
        self.assertEqual([k for _, k in log], G.ORDER)
        self.assertEqual([lv for lv, _ in log], [0, 1, 2, 3, 4])

    def test_no_interlude_after_last_level(self):
        g, c = make()
        g.key("enter")
        play_to(g, c, lambda gm: gm.level == 5 and gm.state == G.CLIMB)
        play_to(g, c, lambda gm: gm.state != G.CLIMB)
        self.assertEqual(g.state, G.SPACE)

    def test_sequences(self):
        for seed in range(200):
            g, _ = make(seed)
            run = g.make_moves("run")
            self.assertEqual(len(run), 5)
            for a, b in zip(run, run[1:]):
                self.assertNotEqual(a, b)
            for m in run:
                self.assertIn(m, G.RUN_MOVES)
        g, _ = make()
        self.assertEqual(g.make_moves("row"), ["row"] * 6)
        self.assertEqual(g.make_moves("slug"), ["throw", "chest", "zap"])

    def test_gems(self):
        g, c = make()
        g.key("enter")
        play_to(g, c, lambda gm: gm.state == G.WIN)
        self.assertEqual(g.gems, 6)
        self.assertEqual(g.cur, G.TOTAL)


class TestInput(unittest.TestCase):
    def test_wrong_keys(self):
        g, c = make()
        g.key("enter")
        target = g.target
        wrong = "J" if target == "F" else "F"
        before = (g.cur, g.level, g.gems)
        g.key(wrong.lower())
        self.assertEqual((g.cur, g.level, g.gems), before)
        self.assertIn("That's", g.speech)
        speech = g.speech
        for k in ("q", "a", "z", "5", "left", "space", "enter"):
            g.key(k)
            self.assertEqual((g.cur, g.level, g.gems), before)
        self.assertEqual(g.speech, speech)   # not-in-play keys are silent
        g.key(target.lower())
        self.assertEqual(g.cur, 1)

    def test_hold_to_repeat(self):
        g, c = make()
        g.key("enter")
        k = g.expected_key()
        g.key(k)
        g.key(k)
        g.key(k)
        self.assertEqual(g.cur, 1)

    def test_upper_case_equivalent(self):
        g, c = make()
        g.key("enter")
        g._climb_key(g.target)  # already upper-case letter works too
        self.assertEqual(g.cur, 1)

    def test_run_wrong_move(self):
        g, c = make()
        g.key("enter")
        play_to(g, c, lambda gm: gm.state == G.INTERLUDE and gm.accepting)
        m = g.current_move()
        other = next(x for x in G.RUN_MOVES if x != m)
        g.key(G.MOVES[other][2][0])
        self.assertEqual(g.done, 0)
        self.assertIn("You can do it!", g.speech)

    def test_space_only_a(self):
        g, c = make()
        g.key("enter")
        play_to(g, c, lambda gm: gm.state == G.SPACE)
        wait_for_key(g, c)
        for k in ("b", "enter", "space", "left", "s"):
            g.key(k)
            advance(g, c, 0.5)
            self.assertEqual(g.state, G.SPACE)
            self.assertFalse(g.ball_frozen)
        g.key("a")
        g.key("a")
        advance(g, c, 3.0)
        self.assertEqual(g.state, G.WIN)

    def test_esc_confirm(self):
        g, c = make()
        g.key("enter")
        g.key("esc")
        self.assertTrue(g.confirm_quit)
        g.key("x")
        self.assertFalse(g.confirm_quit)
        self.assertFalse(g.quit)
        g.key("esc")
        g.key("esc")
        self.assertTrue(g.quit)

    def test_esc_on_title_quits(self):
        g, _ = make()
        g.key("esc")
        self.assertTrue(g.quit)

    def test_toggles(self):
        g, _ = make()
        g.key("1")
        g.key("2")
        self.assertFalse(g.music_on)
        self.assertFalse(g.voice_on)
        self.assertIn(("music", False), g.pop_events())


class TestPlaythrough(unittest.TestCase):
    def test_full_and_restart(self):
        g, c = make(1)
        self.assertEqual(g.state, G.TITLE)
        g.key("enter")
        play_to(g, c, lambda gm: gm.state == G.WIN and gm.win_text)
        self.assertEqual(g.gems, 6)
        g.key("enter")
        self.assertEqual(g.state, G.CLIMB)
        self.assertEqual((g.cur, g.level, g.gems), (0, 0, 0))
        self.assertEqual(len(g.rocks), 2)
        self.assertFalse(g.ball or g.boat or g.win_text)

    def test_restart_key_mid_game(self):
        g, c = make(2)
        g.key("enter")
        play_to(g, c, lambda gm: gm.level == 2)
        g.key("0")
        self.assertEqual((g.state, g.cur, g.level, g.gems), (G.CLIMB, 0, 0, 0))
        advance(g, c, 5)   # no stale timers fire
        self.assertEqual((g.state, g.cur, g.level), (G.CLIMB, 0, 0))


class TestVoiceCoverage(unittest.TestCase):
    def test_every_callout_has_a_recording(self):
        import random
        import voice
        known = {voice.key(s) for s in voice.all_sentences()}
        said = set()
        keys = [chr(c) for c in range(97, 123)] + ["left", "right", "up", "down", "space", "enter"]
        for seed in range(25):
            g, c = make(seed)
            rnd = random.Random(seed)
            g.key("enter")
            for _ in range(3000):
                for kind, val in g.pop_events():
                    if kind == "say":
                        said.add(val)
                if g.state == G.WIN and g.win_text:
                    break
                k = wait_for_key(g, c)
                if k is None:
                    continue
                if rnd.random() < 0.5:
                    g.key(rnd.choice(keys))      # a wrong (or right) guess first
                    for kind, val in g.pop_events():
                        if kind == "say":
                            said.add(val)
                    k = g.expected_key()
                    if k is None:
                        continue
                g.key(k)
                advance(g, c, 0.05)
            for kind, val in g.pop_events():
                if kind == "say":
                    said.add(val)
        missing = {s for t in said for s in voice.sentences(t) if voice.key(s) not in known}
        self.assertEqual(missing, set())
        self.assertGreater(len(said), 150)


if __name__ == "__main__":
    unittest.main()
