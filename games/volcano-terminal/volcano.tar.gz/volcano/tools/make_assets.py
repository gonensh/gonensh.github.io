#!/usr/bin/env python3
"""Builds the PNG art in ../assets from SVG source (developer tool).

The game itself only loads the PNGs, so the Pi needs neither this script
nor rsvg-convert. Needs: rsvg-convert, Python 3 with Pillow.
Art is drawn at 2x the 960x540 design size.
"""
import math
import os
import random
import subprocess
import tempfile

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "assets")
SVG_NS = 'xmlns="http://www.w3.org/2000/svg"'


def render(name, svg, w, h):
    with tempfile.NamedTemporaryFile("w", suffix=".svg", delete=False) as f:
        f.write(svg)
        path = f.name
    out = os.path.join(OUT, name + ".png")
    subprocess.run(["rsvg-convert", "-w", str(w), "-h", str(h), path, "-o", out],
                   check=True)
    os.unlink(path)
    print("wrote", name, w, h)


# ---------------------------------------------------------------- characters
# Explorer, guide, boat, snail, slug, chest and crystal come from the
# browser version (volcano-adventure.html).

HERO = f"""<svg viewBox="0 0 64 64" {SVG_NS}>
<ellipse cx="32" cy="61.5" rx="15" ry="3" fill="rgba(0,0,0,.28)"/>
<rect x="26" y="48" width="4.6" height="9" rx="2.2" fill="#e6b98f"/>
<rect x="33.4" y="48" width="4.6" height="9" rx="2.2" fill="#e6b98f"/>
<path d="M23.5 55 h7 v3.2 q0 1.8-1.8 1.8 h-3.6 q-1.6 0-1.6-1.6z" fill="#2ea9b8"/>
<path d="M33.5 55 h7 q1.6 0 1.6 1.6 v1.6 q0 1.8-1.8 1.8 h-6.8z" fill="#2ea9b8"/>
<rect x="22.8" y="58.4" width="8.2" height="2" rx="1" fill="#fff"/>
<rect x="33" y="58.4" width="8.2" height="2" rx="1" fill="#fff"/>
<path d="M24 43 h16 l-0.6 6 h-5.4 l-2-3 -2 3 h-5.4 z" fill="#2bb0bf"/>
<path d="M23 28 q9-4 18 0 l-1.2 15 q-7.8 3-15.6 0 z" fill="#37c6d6"/>
<path d="M23 29 l-8 5 2.5 4 8-5z" fill="#37c6d6"/>
<path d="M41 29 l8 5 -2.5 4 -8-5z" fill="#37c6d6"/>
<circle cx="14.5" cy="35.5" r="2.7" fill="#e6b98f"/>
<circle cx="49.5" cy="35.5" r="2.7" fill="#e6b98f"/>
<path d="M27.6 28 l4.4 5.4 4.4-5.4z" fill="#2bb0bf"/>
<path d="M27.2 28 l4.8 5.8 4.8-5.8" fill="none" stroke="#1f96a4" stroke-width="1.1" stroke-linejoin="round"/>
<line x1="32" y1="33.4" x2="32" y2="43" stroke="#1f96a4" stroke-width="1"/>
<circle cx="32" cy="36.4" r=".6" fill="#eafffb"/>
<circle cx="32" cy="39.8" r=".6" fill="#eafffb"/>
<rect x="29.6" y="23.5" width="4.8" height="5.5" rx="2" fill="#e0b088"/>
<ellipse cx="32" cy="16.5" rx="9.8" ry="9.4" fill="#eec19a"/>
<circle cx="22.4" cy="17.4" r="1.9" fill="#eec19a"/>
<circle cx="41.6" cy="17.4" r="1.9" fill="#eec19a"/>
<circle cx="28.4" cy="16.6" r="1.5" fill="#2b2b2b"/>
<circle cx="35.6" cy="16.6" r="1.5" fill="#2b2b2b"/>
<circle cx="28.9" cy="16.1" r=".45" fill="#fff"/>
<circle cx="36.1" cy="16.1" r=".45" fill="#fff"/>
<path d="M27.5 20 q4.5 5 9 0 z" fill="#8a3320"/>
<path d="M28.5 20.4 q4 2.4 8 0 z" fill="#fff"/>
<path d="M21.5 13.5 a10.5 10 0 0 1 21 0 q0 1.4-1.4 1.4 h-18.2 q-1.4 0-1.4-1.4z" fill="#c98a4e"/>
<path d="M22 13 q-2.8 3-1.2 8 l3.4-.8 -1-6.4z" fill="#7d5227"/>
<path d="M42 13 q2.8 3 1.2 8 l-3.4-.8 1-6.4z" fill="#7d5227"/>
<path d="M22.5 13 q9.5-5 19 0" fill="none" stroke="#a56d38" stroke-width="0.9"/>
<rect x="23" y="6.5" width="18" height="5.6" rx="2.8" fill="#2b2b2b"/>
<circle cx="28" cy="9.4" r="3.6" fill="#9fe9f2" stroke="#111" stroke-width="1.3"/>
<circle cx="36" cy="9.4" r="3.6" fill="#9fe9f2" stroke="#111" stroke-width="1.3"/>
<rect x="31" y="7.8" width="2.4" height="2" fill="#3a3a3a"/>
</svg>"""

FACE = f"""<svg viewBox="0 0 64 64" {SVG_NS}>
<defs><radialGradient id="bg" cx=".5" cy=".42" r=".6"><stop offset="0" stop-color="#ffe6c4"/><stop offset="1" stop-color="#d99f70"/></radialGradient>
<clipPath id="c"><circle cx="32" cy="32" r="32"/></clipPath></defs>
<g clip-path="url(#c)">
<rect width="64" height="64" fill="url(#bg)"/>
<path d="M8 64 q4-14 24-14 t24 14 z" fill="#37c6d6"/>
<path d="M28 50 l4 5 4-5" fill="none" stroke="#1f96a4" stroke-width="1.6" stroke-linejoin="round"/>
<rect x="28" y="43" width="8" height="9" rx="3" fill="#e0b088"/>
<ellipse cx="32" cy="30" rx="16" ry="15.5" fill="#eec19a"/>
<circle cx="16" cy="31" r="2.6" fill="#eec19a"/>
<circle cx="48" cy="31" r="2.6" fill="#eec19a"/>
<circle cx="26" cy="30" r="2" fill="#2b2b2b"/>
<circle cx="38" cy="30" r="2" fill="#2b2b2b"/>
<circle cx="26.7" cy="29.2" r=".6" fill="#fff"/>
<circle cx="38.7" cy="29.2" r=".6" fill="#fff"/>
<path d="M24 35 q8 8 16 0 z" fill="#8a3320"/>
<path d="M25.5 35.8 q6.5 3.5 13 0 z" fill="#fff"/>
<path d="M17 26 a16 15 0 0 1 30 0 q0 2-2 2 h-26 q-2 0-2-2z" fill="#c98a4e"/>
<path d="M17.5 24 q-3.5 4-1.6 11 l4.6-1 -1.4-9z" fill="#7d5227"/>
<path d="M46.5 24 q3.5 4 1.6 11 l-4.6-1 1.4-9z" fill="#7d5227"/>
<path d="M18 25 q14-7 28 0" fill="none" stroke="#a56d38" stroke-width="1.2"/>
<rect x="19" y="15" width="26" height="8" rx="4" fill="#2b2b2b"/>
<circle cx="26" cy="19.5" r="5.2" fill="#9fe9f2" stroke="#111" stroke-width="1.8"/>
<circle cx="38" cy="19.5" r="5.2" fill="#9fe9f2" stroke="#111" stroke-width="1.8"/>
<rect x="30.5" y="17.5" width="3" height="3" fill="#3a3a3a"/>
</g></svg>"""

BOAT = f"""<svg viewBox="0 0 120 58" {SVG_NS}>
<rect x="2" y="18" width="36" height="4.2" rx="2.1" fill="#8a5a2b" transform="rotate(-20 20 20)"/>
<rect x="82" y="18" width="36" height="4.2" rx="2.1" fill="#8a5a2b" transform="rotate(20 100 20)"/>
<ellipse cx="7" cy="9" rx="6" ry="3.4" fill="#6f4620" transform="rotate(-20 7 9)"/>
<ellipse cx="113" cy="9" rx="6" ry="3.4" fill="#6f4620" transform="rotate(20 113 9)"/>
<path d="M10 26 q50 24 100 0 q-9 24 -50 24 q-41 0 -50 -24z" fill="#a86a34"/>
<path d="M10 26 q50 20 100 0" fill="none" stroke="#c98a4e" stroke-width="3.5"/>
<path d="M22 31 q28 13 76 0" fill="none" stroke="#7d4e24" stroke-width="1.6"/>
<path d="M32 36 q22 9 56 0" fill="none" stroke="#7d4e24" stroke-width="1.4"/>
</svg>"""

SNAIL = f"""<svg viewBox="0 0 90 62" {SVG_NS}>
<ellipse cx="45" cy="55" rx="32" ry="5" fill="rgba(0,0,0,.25)"/>
<path d="M6 52 q2-16 20-16 h20 q6 0 6 6 q0 8-10 8 h-2 q10 2 10 2 z" fill="#8fd46a"/>
<path d="M60 50 q10 0 12-8 q2-9-8-11 q-8-1-9 7 q-1 8 5 12z" fill="#8fd46a"/>
<line x1="66" y1="34" x2="63" y2="20" stroke="#8fd46a" stroke-width="3.4" stroke-linecap="round"/>
<line x1="72" y1="34" x2="76" y2="18" stroke="#8fd46a" stroke-width="3.4" stroke-linecap="round"/>
<circle cx="62" cy="18" r="4.2" fill="#fff" stroke="#2b2b2b" stroke-width="1.4"/>
<circle cx="77" cy="16" r="4.2" fill="#fff" stroke="#2b2b2b" stroke-width="1.4"/>
<circle cx="62.5" cy="18.5" r="1.8" fill="#2b2b2b"/>
<circle cx="77.5" cy="16.5" r="1.8" fill="#2b2b2b"/>
<path d="M60 44 q5 4 9 1" stroke="#3c7a2a" stroke-width="2" fill="none" stroke-linecap="round"/>
<circle cx="30" cy="34" r="20" fill="#e0913f" stroke="#b06e28" stroke-width="2.5"/>
<circle cx="30" cy="34" r="13" fill="none" stroke="#b06e28" stroke-width="2.2"/>
<circle cx="30" cy="34" r="6.5" fill="none" stroke="#b06e28" stroke-width="2"/>
<circle cx="30" cy="34" r="3" fill="#7fe9df" stroke="#eafffb" stroke-width="1.2"/>
</svg>"""


def slug(body, belly, spots, brow, mouth, extra=""):
    return f"""<svg viewBox="0 0 100 60" {SVG_NS}>
<ellipse cx="50" cy="55" rx="40" ry="4" fill="rgba(0,0,0,.25)"/>
<path d="M6 50 q4-22 34-22 h20 q28 0 32 20 q1 6-6 6 h-74 q-7 0-6-4z" fill="{body}"/>
<path d="M20 40 q22-15 50-7 q-26-1 -42 9z" fill="{belly}"/>
<circle cx="32" cy="43" r="4" fill="{spots}"/>
<circle cx="50" cy="47" r="3.4" fill="{spots}"/>
<circle cx="66" cy="43" r="3" fill="{spots}"/>
<path d="M74 48 q16 0 18-12 q2-12-12-13 q-12-1-13 10 q-1 11 7 15z" fill="{body}"/>
<line x1="80" y1="30" x2="77" y2="16" stroke="{body}" stroke-width="4" stroke-linecap="round"/>
<line x1="88" y1="30" x2="92" y2="14" stroke="{body}" stroke-width="4" stroke-linecap="round"/>
<circle cx="76" cy="15" r="5" fill="#fff" stroke="#2b2b2b" stroke-width="1.5"/>
<circle cx="92" cy="13" r="5" fill="#fff" stroke="#2b2b2b" stroke-width="1.5"/>
<circle cx="77" cy="15.6" r="2.2" fill="#2b2b2b"/>
<circle cx="93" cy="13.6" r="2.2" fill="#2b2b2b"/>
<path d="M70 9 l10 4 M98 6 l-9 5" stroke="{brow}" stroke-width="2.2" stroke-linecap="round"/>
<path d="M75 45 q7 3 13 0" stroke="{mouth}" stroke-width="2.2" fill="none" stroke-linecap="round"/>
{extra}</svg>"""


SLUG = slug("#e2571f", "#ff8a3d", "#ffcf4d", "#a5340f", "#7a2a0c")
ICE_SHINE = """<path d="M18 36 l8-6 M40 31 l10-3 M84 26 l4-4" stroke="#ffffff" stroke-width="2" stroke-linecap="round" opacity=".85"/>
<path d="M10 49 q30-8 80-2" stroke="#ffffff" stroke-width="1.4" fill="none" opacity=".5"/>"""
SLUG_ICE = slug("#7fd3e6", "#c4f3fb", "#eafffb", "#3a8fa3", "#2a6a7a", ICE_SHINE)

CHEST = f"""<svg viewBox="0 0 80 70" {SVG_NS}>
<ellipse cx="40" cy="66" rx="30" ry="4" fill="rgba(0,0,0,.25)"/>
<rect x="10" y="34" width="60" height="28" rx="5" fill="#9a5a2b"/>
<rect x="10" y="34" width="60" height="9" fill="#7d4a22"/>
<path d="M10 34 q0-16 30-16 q30 0 30 16 z" fill="#b06e34"/>
<rect x="20" y="18" width="5" height="44" fill="#caa24a"/>
<rect x="55" y="18" width="5" height="44" fill="#caa24a"/>
<rect x="8" y="40" width="64" height="5" fill="#caa24a"/>
<rect x="35" y="40" width="10" height="11" rx="2" fill="#ffd23f" stroke="#a5781f" stroke-width="1.5"/>
<circle cx="40" cy="45" r="1.6" fill="#7a5a12"/>
</svg>"""

CHEST_OPEN = f"""<svg viewBox="0 0 80 70" {SVG_NS}>
<defs><radialGradient id="glow" cx=".5" cy=".6" r=".5"><stop offset="0" stop-color="#fff6c2"/><stop offset=".5" stop-color="#ffd23f" stop-opacity=".7"/><stop offset="1" stop-color="#ffd23f" stop-opacity="0"/></radialGradient></defs>
<ellipse cx="40" cy="66" rx="30" ry="4" fill="rgba(0,0,0,.25)"/>
<ellipse cx="40" cy="30" rx="34" ry="22" fill="url(#glow)"/>
<path d="M12 22 q0-16 28-18 q28 2 28 18 z" fill="#8c552a"/>
<rect x="21" y="5" width="4" height="17" fill="#caa24a"/>
<rect x="55" y="5" width="4" height="17" fill="#caa24a"/>
<rect x="10" y="34" width="60" height="28" rx="5" fill="#9a5a2b"/>
<path d="M12 34 q28-8 56 0 z" fill="#3b220e"/>
<circle cx="30" cy="31" r="4" fill="#ffd23f" stroke="#a5781f"/><circle cx="40" cy="29" r="4.4" fill="#ffe36b" stroke="#a5781f"/>
<circle cx="50" cy="31" r="4" fill="#ffd23f" stroke="#a5781f"/>
<path d="M40 18 L45 25 L40 33 L35 25 Z" fill="#7fe9df" stroke="#eafffb" stroke-width="1.2"/>
<rect x="20" y="34" width="5" height="28" fill="#caa24a"/>
<rect x="55" y="34" width="5" height="28" fill="#caa24a"/>
<rect x="8" y="40" width="64" height="5" fill="#caa24a"/>
<rect x="35" y="40" width="10" height="11" rx="2" fill="#ffd23f" stroke="#a5781f" stroke-width="1.5"/>
<circle cx="40" cy="45" r="1.6" fill="#7a5a12"/>
</svg>"""

CRYSTAL = f"""<svg viewBox="0 0 24 32" {SVG_NS}>
<path d="M12 1 L21 11 L12 31 L3 11 Z" fill="#7fe9df" stroke="#eafffb" stroke-width="1.6" stroke-linejoin="round"/>
<path d="M12 1 L12 31 M3 11 L21 11 M12 1 L6.5 11 M12 1 L17.5 11" stroke="#37c6d6" stroke-width="1"/>
</svg>"""


def ball(c0, c1, c2, inset, extra):
    return f"""<svg viewBox="0 0 100 100" {SVG_NS}>
<defs><radialGradient id="b" cx=".36" cy=".3" r=".7"><stop offset="0" stop-color="{c0}"/><stop offset=".52" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></radialGradient>
<radialGradient id="s" cx=".72" cy=".78" r=".55"><stop offset="0" stop-color="{inset}" stop-opacity=".6"/><stop offset="1" stop-color="{inset}" stop-opacity="0"/></radialGradient></defs>
<circle cx="50" cy="50" r="46" fill="url(#b)"/>
<circle cx="50" cy="50" r="46" fill="url(#s)"/>
{extra}
<ellipse cx="36" cy="30" rx="12" ry="7" fill="#fff" opacity=".35" transform="rotate(-30 36 30)"/>
</svg>"""


BALL = ball("#ffe36b", "#ff5a1f", "#c81d1d", "#8c0a0a",
            '<path d="M22 58 l14-6 8 9 12-4 M60 30 l8 10 -6 10 M40 80 l10-8 14 4" '
            'stroke="#7a1208" stroke-width="2.6" fill="none" stroke-linecap="round" opacity=".55"/>')
BALL_ICE = ball("#eafffb", "#7fe9df", "#37c6d6", "#14788a",
                '<path d="M50 4 L64 40 L96 50 L62 60 L50 96 L38 60 L4 50 L36 40 Z" '
                'fill="#ffffff" opacity=".22"/><path d="M30 26 l40 48 M70 26 l-40 48" '
                'stroke="#ffffff" stroke-width="1.5" opacity=".5"/>')

# ---------------------------------------------------------------- rocks

ROCK_SHAPES = [
    "20,6 50,0 78,8 96,32 92,62 80,90 52,100 24,92 4,66 6,34",
    "14,14 42,4 72,6 94,26 100,54 88,82 62,96 32,98 8,74 2,42",
    "24,4 54,6 80,2 96,34 90,60 98,84 66,96 34,100 10,78 6,40",
    "16,10 48,2 76,12 90,28 98,56 84,86 58,94 28,96 10,70 4,38",
]


def rock(shape_i, target):
    pts = ROCK_SHAPES[shape_i]
    # 100-unit rock inside a 130-unit canvas (room for shadow + glow)
    pts = " ".join(f"{float(x) + 15},{float(y) + 12}" for x, y in
                   (p.split(",") for p in pts.split()))
    if target:
        g0, g1, shade, glow, glow_op = "#9ffce4", "#3fe0b4", "#005a46", "#5ef2c7", ".9"
        speck = "#2aa889"
    else:
        g0, g1, shade, glow, glow_op = "#8a8077", "#2f2824", "#000000", "#ff5a1e", ".45"
        speck = "#4a413b"
    rnd = random.Random(shape_i * 7 + 3)
    specks = "".join(
        f'<circle cx="{rnd.uniform(30, 100):.1f}" cy="{rnd.uniform(28, 100):.1f}" '
        f'r="{rnd.uniform(1.2, 3.2):.1f}" fill="{speck}" opacity=".55"/>' for _ in range(14))
    cracks = (f'<path d="M{rnd.uniform(35,55):.0f} {rnd.uniform(25,40):.0f} l8 10 -3 9 7 8" '
              f'stroke="{speck}" stroke-width="1.6" fill="none" opacity=".6"/>'
              f'<path d="M{rnd.uniform(70,90):.0f} {rnd.uniform(60,80):.0f} l-9 6 2 10" '
              f'stroke="{speck}" stroke-width="1.4" fill="none" opacity=".5"/>')
    return f"""<svg viewBox="0 0 130 130" {SVG_NS}>
<defs>
<linearGradient id="g" x1=".3" y1="0" x2=".7" y2="1"><stop offset="0" stop-color="{g0}"/><stop offset="1" stop-color="{g1}"/></linearGradient>
<radialGradient id="hl" cx=".36" cy=".26" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".38"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
<radialGradient id="sh" cx=".72" cy=".74" r=".46"><stop offset="0" stop-color="{shade}" stop-opacity=".45"/><stop offset="1" stop-color="{shade}" stop-opacity="0"/></radialGradient>
<radialGradient id="wm" cx=".5" cy=".95" r=".5"><stop offset="0" stop-color="#ff7a3c" stop-opacity=".35"/><stop offset="1" stop-color="#ff7a3c" stop-opacity="0"/></radialGradient>
<clipPath id="c"><polygon points="{pts}"/></clipPath>
<filter id="glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="5"/></filter>
<filter id="drop" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter>
</defs>
<polygon points="{pts}" fill="{glow}" opacity="{glow_op}" filter="url(#glow)"/>
<polygon points="{pts}" fill="#000" opacity=".55" filter="url(#drop)" transform="translate(0 6)"/>
<polygon points="{pts}" fill="url(#g)"/>
<g clip-path="url(#c)">
<rect width="130" height="130" fill="url(#hl)"/><rect width="130" height="130" fill="url(#sh)"/>
<rect width="130" height="130" fill="url(#wm)"/>{specks}{cracks}
</g>
<polygon points="{pts}" fill="none" stroke="#fff" stroke-opacity=".18" stroke-width="1.5"/>
</svg>"""


# ---------------------------------------------------------------- scenes
# 1920x1080 = 2x the 960x540 design; the play field starts at y=196 (98*2).

FIELD_TOP = 196
FIELD_H = 1080 - FIELD_TOP


def _ridge(rnd, base, top_min, top_max, step):
    pts = [f"0,{base}"]
    x = 0
    while x < 1920:
        pts.append(f"{x},{rnd.uniform(top_min, top_max):.0f}")
        x += rnd.uniform(step * .5, step * 1.5)
    pts.append(f"1920,{rnd.uniform(top_min, top_max):.0f}")
    pts.append(f"1920,{base}")
    return " ".join(pts)


def _crack(rnd, x, y, n, step):
    d = f"M{x:.0f} {y:.0f}"
    ang = rnd.uniform(0, math.pi)
    for _ in range(n):
        ang += rnd.uniform(-.7, .7)
        x += math.cos(ang) * step
        y += math.sin(ang) * step * .45      # flattened: lake seen at an angle
        d += f" L{x:.0f} {y:.0f}"
    return d


def background():
    rnd = random.Random(11)
    hz_h = int(FIELD_H * 0.16)
    hz_b = FIELD_TOP + hz_h
    lava_top = FIELD_TOP + int(FIELD_H * 0.15)
    far = _ridge(rnd, hz_b, FIELD_TOP + 28, FIELD_TOP + 70, 120)
    near = _ridge(rnd, hz_b + 4, hz_b - 70, hz_b - 22, 70)
    cracks = []
    for _ in range(46):
        x, y = rnd.uniform(-50, 1970), rnd.uniform(lava_top + 30, 1080)
        w = rnd.uniform(2.5, 6) * (0.6 + (y - lava_top) / 900)
        cracks.append(f'<path d="{_crack(rnd, x, y, rnd.randint(4, 9), rnd.uniform(28, 60))}" '
                      f'stroke="#5a0808" stroke-width="{w:.1f}" fill="none" stroke-linejoin="round" '
                      f'stroke-linecap="round" opacity="{rnd.uniform(.18, .38):.2f}"/>')
    for _ in range(14):
        x, y = rnd.uniform(0, 1920), rnd.uniform(lava_top + 60, 1060)
        cracks.append(f'<path d="{_crack(rnd, x, y, rnd.randint(3, 6), rnd.uniform(20, 40))}" '
                      f'stroke="#fff0a0" stroke-width="{rnd.uniform(1.5, 3):.1f}" fill="none" '
                      f'stroke-linecap="round" opacity="{rnd.uniform(.25, .5):.2f}" filter="url(#soft)"/>')
    crust = []
    for _ in range(26):
        cx, cy = rnd.uniform(0, 1920), rnd.uniform(lava_top + 40, 1080)
        r = rnd.uniform(40, 110) * (0.5 + (cy - lava_top) / 800)
        pts = " ".join(f"{cx + math.cos(a) * r * rnd.uniform(.6, 1.1):.0f},"
                       f"{cy + math.sin(a) * r * .42 * rnd.uniform(.6, 1.1):.0f}"
                       for a in [i * math.pi / 5 for i in range(10)])
        crust.append(f'<polygon points="{pts}" fill="#7a1010" opacity="{rnd.uniform(.12, .25):.2f}" filter="url(#soft2)"/>')
    return f"""<svg viewBox="0 0 1920 1080" {SVG_NS}>
<defs>
<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241147"/><stop offset="1" stop-color="#3d1f5c"/></linearGradient>
<linearGradient id="lava" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff8a2a"/><stop offset=".3" stop-color="#ff5a1f"/><stop offset=".78" stop-color="#c81d1d"/><stop offset="1" stop-color="#7c0f0f"/></linearGradient>
<radialGradient id="hot" cx=".5" cy="1.3" r=".9"><stop offset="0" stop-color="#ffe36b" stop-opacity=".8"/><stop offset=".6" stop-color="#ffe36b" stop-opacity="0"/></radialGradient>
<radialGradient id="rim" cx=".5" cy="0" r=".7"><stop offset="0" stop-color="#ffb04a" stop-opacity=".6"/><stop offset="1" stop-color="#ff963c" stop-opacity="0"/></radialGradient>
<radialGradient id="vig" cx=".5" cy=".45" r=".75"><stop offset=".6" stop-color="#5a0808" stop-opacity="0"/><stop offset="1" stop-color="#5a0808" stop-opacity=".5"/></radialGradient>
<linearGradient id="hz" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1512"/><stop offset=".52" stop-color="#47201a"/><stop offset=".84" stop-color="#7a2c17"/><stop offset="1" stop-color="#b34015"/></linearGradient>
<linearGradient id="farg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a2420"/><stop offset="1" stop-color="#7a3018"/></linearGradient>
<linearGradient id="nearg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e100d"/><stop offset=".8" stop-color="#2a140f"/><stop offset="1" stop-color="#6a2410"/></linearGradient>
<linearGradient id="hline" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd27a" stop-opacity="0"/><stop offset=".5" stop-color="#ffd27a" stop-opacity=".85"/><stop offset="1" stop-color="#ff7a2a" stop-opacity="0"/></linearGradient>
<filter id="soft"><feGaussianBlur stdDeviation="2.5"/></filter>
<filter id="soft2"><feGaussianBlur stdDeviation="6"/></filter>
<filter id="haze"><feGaussianBlur stdDeviation="10"/></filter>
</defs>
<rect width="1920" height="1080" fill="url(#sky)"/>
<rect y="{lava_top}" width="1920" height="{1080 - lava_top}" fill="url(#lava)"/>
{"".join(crust)}
<rect y="{lava_top}" width="1920" height="{1080 - lava_top}" fill="url(#hot)"/>
<rect y="{lava_top}" width="1920" height="{1080 - lava_top}" fill="url(#rim)"/>
{"".join(cracks)}
<rect y="{lava_top}" width="1920" height="{1080 - lava_top}" fill="url(#vig)"/>
<rect y="{FIELD_TOP}" width="1920" height="{hz_h}" fill="url(#hz)"/>
<polygon points="{far}" fill="url(#farg)" opacity=".85"/>
<rect y="{hz_b - 40}" width="1920" height="70" fill="#ff8a3a" opacity=".35" filter="url(#haze)"/>
<polygon points="{near}" fill="url(#nearg)"/>
<rect y="{hz_b - 8}" width="1920" height="20" fill="url(#hline)"/>
</svg>"""


def space():
    rnd = random.Random(5)
    dust = "".join(f'<circle cx="{rnd.uniform(0,1920):.0f}" cy="{rnd.uniform(0,1080):.0f}" '
                   f'r="{rnd.uniform(.6,1.6):.1f}" fill="#fff" opacity="{rnd.uniform(.15,.5):.2f}"/>'
                   for _ in range(260))
    return f"""<svg viewBox="0 0 1920 1080" {SVG_NS}>
<defs>
<radialGradient id="sp" cx=".5" cy="1.25" r="1.3"><stop offset="0" stop-color="#2e1b57"/><stop offset=".7" stop-color="#0b0a1e"/></radialGradient>
<radialGradient id="neb1" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#7a3cc8" stop-opacity=".35"/><stop offset="1" stop-color="#7a3cc8" stop-opacity="0"/></radialGradient>
<radialGradient id="neb2" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#2fb6c4" stop-opacity=".22"/><stop offset="1" stop-color="#2fb6c4" stop-opacity="0"/></radialGradient>
<radialGradient id="pl" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ff9a5a"/><stop offset=".6" stop-color="#c8401d"/><stop offset="1" stop-color="#5a1208"/></radialGradient>
<radialGradient id="earthglow" cx=".5" cy=".5" r=".5"><stop offset=".7" stop-color="#ff7a2a" stop-opacity=".35"/><stop offset="1" stop-color="#ff7a2a" stop-opacity="0"/></radialGradient>
</defs>
<rect width="1920" height="1080" fill="url(#sp)"/>
<ellipse cx="1350" cy="300" rx="700" ry="320" fill="url(#neb1)"/>
<ellipse cx="420" cy="760" rx="620" ry="300" fill="url(#neb2)"/>
{dust}
<circle cx="960" cy="1720" r="900" fill="url(#earthglow)"/>
<circle cx="960" cy="1760" r="820" fill="url(#pl)"/>
<path d="M890 952 L940 912 Q960 906 980 912 L1030 952 Z" fill="#5a1a0c"/>
<ellipse cx="960" cy="912" rx="20" ry="5" fill="#ffd23f"/>
<radialGradient id="vg" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffb347" stop-opacity=".55"/><stop offset="1" stop-color="#ffb347" stop-opacity="0"/></radialGradient>
<circle cx="960" cy="905" r="60" fill="url(#vg)"/>
</svg>"""


VOLCANO = f"""<svg viewBox="0 0 400 300" {SVG_NS}>
<defs>
<linearGradient id="cone" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6a5d55"/><stop offset=".55" stop-color="#3a2f2a"/><stop offset="1" stop-color="#1e1714"/></linearGradient>
<radialGradient id="crater" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff2b0"/><stop offset=".5" stop-color="#ffb02e"/><stop offset="1" stop-color="#ff5a1f"/></radialGradient>
<linearGradient id="drip" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd23f"/><stop offset="1" stop-color="#ff3d14"/></linearGradient>
<radialGradient id="glow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffb347" stop-opacity=".8"/><stop offset="1" stop-color="#ff5a1f" stop-opacity="0"/></radialGradient>
<filter id="b"><feGaussianBlur stdDeviation="4"/></filter>
</defs>
<ellipse cx="200" cy="70" rx="120" ry="70" fill="url(#glow)"/>
<circle cx="168" cy="40" r="20" fill="#5a4a5e" opacity=".55" filter="url(#b)"/>
<circle cx="200" cy="26" r="26" fill="#6a5a6e" opacity=".5" filter="url(#b)"/>
<circle cx="236" cy="38" r="18" fill="#5a4a5e" opacity=".5" filter="url(#b)"/>
<path d="M10 290 L150 92 Q200 76 250 92 L390 290 Z" fill="url(#cone)"/>
<path d="M150 92 Q200 76 250 92 L262 108 Q200 96 138 108 Z" fill="#2a201c"/>
<ellipse cx="200" cy="92" rx="50" ry="12" fill="url(#crater)"/>
<path d="M172 96 q-6 40 -22 70 q-6 14 4 16 q10 2 12-14 q4-30 18-70 z" fill="url(#drip)"/>
<path d="M222 96 q10 30 30 52 q8 10 0 14 q-8 4 -14-8 q-12-24 -24-56 z" fill="url(#drip)"/>
<path d="M200 98 q2 50 -4 96 q-2 12 6 12 q8 0 6-12 q-4-46 0-96 z" fill="url(#drip)"/>
<path d="M60 250 l40-10 30 14 M290 230 l40 18 M120 200 l24-6" stroke="#15100d" stroke-width="3" fill="none" opacity=".6"/>
<path d="M0 290 Q200 270 400 290 L400 300 L0 300 Z" fill="#ff5a1f"/>
<path d="M0 292 Q100 284 200 292 T400 292" stroke="#ffd23f" stroke-width="3" fill="none"/>
</svg>"""

NOTE = f"""<svg viewBox="0 0 24 24" {SVG_NS}><path d="M9 18 V5 l11-2 v13" stroke="#fff4e0" stroke-width="2.4" fill="none" stroke-linejoin="round"/>
<circle cx="6.5" cy="18" r="3.2" fill="#fff4e0"/><circle cx="17.5" cy="16" r="3.2" fill="#fff4e0"/></svg>"""
SPEAKER = f"""<svg viewBox="0 0 24 24" {SVG_NS}><path d="M3 9 h4 l5-4 v14 l-5-4 h-4 z" fill="#fff4e0"/>
<path d="M15.5 8.5 q3 3.5 0 7 M18 6 q5 6 0 12" stroke="#fff4e0" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>"""


# ---------------------------------------------------------------- raster-only

def glow(name, rgb, size=256, falloff=2.2):
    img = Image.new("RGBA", (size, size))
    px = img.load()
    c = (size - 1) / 2
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - c, y - c) / c
            a = max(0.0, 1 - d) ** falloff
            px[x, y] = (*rgb, int(255 * a))
    img.save(os.path.join(OUT, name + ".png"))
    print("wrote", name)


def ring(name, size=136, width=8):
    stops = [(0, (255, 204, 51)), (.25, (255, 90, 31)), (.5, (200, 29, 29)),
             (.75, (255, 122, 31)), (1, (255, 204, 51))]

    def col(t):
        for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
            if t <= t1:
                k = (t - t0) / (t1 - t0)
                return tuple(int(a + (b - a) * k) for a, b in zip(c0, c1))
        return stops[-1][1]
    ss = 3
    big = Image.new("RGBA", (size * ss, size * ss))
    px = big.load()
    c = (size * ss - 1) / 2
    r_out, r_in = c, c - width * ss
    for y in range(size * ss):
        for x in range(size * ss):
            d = math.hypot(x - c, y - c)
            if r_in <= d <= r_out:
                t = (math.atan2(y - c, x - c) / (2 * math.pi)) % 1
                px[x, y] = (*col(t), 255)
    big.resize((size, size), Image.LANCZOS).save(os.path.join(OUT, name + ".png"))
    print("wrote", name)


def main():
    os.makedirs(OUT, exist_ok=True)
    render("hero", HERO, 200, 200)
    render("hero_float", HERO.replace('<ellipse cx="32" cy="61.5" rx="15" ry="3" fill="rgba(0,0,0,.28)"/>', ""), 200, 200)
    render("face", FACE, 116, 116)
    render("boat", BOAT, 320, 155)
    render("snail", SNAIL, 240, 165)
    render("slug", SLUG, 340, 204)
    render("slug_ice", SLUG_ICE, 340, 204)
    render("chest", CHEST, 270, 236)
    render("chest_open", CHEST_OPEN, 270, 236)
    render("crystal", CRYSTAL, 72, 96)
    render("ball", BALL, 240, 240)
    render("ball_ice", BALL_ICE, 240, 240)
    for i in range(len(ROCK_SHAPES)):
        render(f"rock{i}", rock(i, False), 218, 218)
        render(f"rock{i}_t", rock(i, True), 218, 218)
    render("bg", background(), 1920, 1080)
    render("space", space(), 1920, 1080)
    render("volcano", VOLCANO, 640, 480)
    render("note", NOTE, 48, 48)
    render("speaker", SPEAKER, 48, 48)
    glow("glow_teal", (94, 242, 199))
    glow("glow_orange", (255, 122, 42))
    glow("glow_yellow", (255, 236, 160), falloff=1.6)
    glow("glow_ice", (159, 233, 242))
    glow("glow_white", (255, 255, 255), size=64, falloff=1.8)
    ring("ring")


if __name__ == "__main__":
    main()
