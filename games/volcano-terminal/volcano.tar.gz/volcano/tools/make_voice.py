#!/usr/bin/env python3
"""Records the guide's voice into ../voice/*.wav (developer tool).

Uses Kokoro (Apache-2.0 neural TTS) through kokoro-onnx:
    pip install kokoro-onnx scipy
    model files: https://github.com/thewh1teagle/kokoro-onnx/releases (model-files-v1.0)
    python3 tools/make_voice.py --model kokoro-v1.0.onnx --voices voices-v1.0.bin

The game only plays the WAVs, so the Pi needs none of this.
"""
import argparse
import os
import re
import sys
import wave

import numpy as np
from scipy.signal import resample_poly

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import voice  # noqa: E402

LETTER_NAMES = {  # how each letter must sound (Kokoro phonemes, stressed)
    "A": "ˈeɪ", "B": "bˈiː", "C": "sˈiː", "D": "dˈiː", "E": "ˈiː", "F": "ˈɛf", "G": "dʒˈiː",
    "H": "ˈeɪtʃ", "I": "ˈaɪ", "J": "dʒˈeɪ", "K": "kˈeɪ", "L": "ˈɛl", "M": "ˈɛm", "N": "ˈɛn",
    "O": "ˈoʊ", "P": "pˈiː", "Q": "kjˈuː", "R": "ˈɑːɹ", "S": "ˈɛs", "T": "tˈiː", "U": "jˈuː",
    "V": "vˈiː", "W": "dˈʌbəljˌuː", "X": "ˈɛks", "Y": "wˈaɪ", "Z": "zˈiː"}
# Where the phonemizer reads a called-out letter as the word "a"
PHONEME_FIXES = [("pɹˈɛs ɐ ", "pɹˈɛs ˈeɪ ")]
LETTER_USE = re.compile(r"\b(?:to|the|Press|That's|Find|Where's) ([A-Z])\b")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="kokoro-v1.0.onnx")
    p.add_argument("--voices", default="voices-v1.0.bin")
    p.add_argument("--voice", default="af_heart")
    p.add_argument("--speed", type=float, default=0.92)
    p.add_argument("--rate", type=int, default=22050)
    p.add_argument("--out", default=voice.VOICE_DIR)
    a = p.parse_args()

    from kokoro_onnx import Kokoro
    k = Kokoro(a.model, a.voices)
    os.makedirs(a.out, exist_ok=True)
    for old in os.listdir(a.out):
        if old.endswith(".wav"):
            os.remove(os.path.join(a.out, old))
    total = 0
    for s in voice.all_sentences():
        text = s.replace("—", ",")
        ph = k.tokenizer.phonemize(text, "en-us")
        for bad, good in PHONEME_FIXES:
            ph = ph.replace(bad, good)
        for letter in LETTER_USE.findall(s):
            if LETTER_NAMES[letter] not in ph:
                sys.exit(f"letter {letter} not pronounced as a letter in {s!r}: {ph}")
        audio, sr = k.create(ph, voice=a.voice, speed=a.speed, is_phonemes=True)
        audio = audio.astype(np.float64)
        if sr != a.rate:
            g = np.gcd(sr, a.rate)
            audio = resample_poly(audio, a.rate // g, sr // g)
        # trim near-silence, short fades, normalise to -1 dBFS
        idx = np.where(np.abs(audio) > 0.01)[0]
        if len(idx):
            audio = audio[max(0, idx[0] - 200): idx[-1] + 400]
        fade = min(len(audio) // 4, int(0.006 * a.rate))
        if fade:
            audio[:fade] *= np.linspace(0, 1, fade)
            audio[-fade:] *= np.linspace(1, 0, fade)
        audio *= 0.89 / max(1e-6, np.max(np.abs(audio)))
        pcm = (audio * 32767).astype("<i2").tobytes()
        with wave.open(voice.clip_path(s, a.out), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(a.rate)
            w.writeframes(pcm)
        total += len(pcm)
        print(f"{voice.key(s):40s} {len(pcm) / 2 / a.rate:4.2f}s")
    print(f"{len(voice.all_sentences())} clips, {total / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
