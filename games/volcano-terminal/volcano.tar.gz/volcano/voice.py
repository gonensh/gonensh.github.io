"""Pre-recorded guide voice.

Everything the guide says is built from a fixed set of sentences, so they
are recorded ahead of time with a neural voice (tools/make_voice.py) and
shipped as WAV clips in voice/. At run time a callout is split into
sentences and the matching clips are played back to back. This costs the
Pi nothing but file reads, so it sounds the same on a Pi Zero as anywhere.
If a sentence has no clip, the caller falls back to espeak.
"""
import os
import re

import game as G

HERE = os.path.dirname(os.path.abspath(__file__))
VOICE_DIR = os.path.join(HERE, "voice")
GAP = 0.12          # seconds of silence between sentences

_SPLIT = re.compile(r"(?<=[.!?])\s+")


def sentences(text):
    """Split a callout into sentences (emoji and the like removed)."""
    text = "".join(c for c in text if ord(c) < 0x2000 or c in "—’…")
    return [s.strip() for s in _SPLIT.split(text) if re.search(r"[A-Za-z]", s)]


def key(sentence):
    """File-name key: 'Where's A?' -> 'wheres_a'."""
    s = sentence.lower().replace("’", "'").replace("'", "")
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


def all_sentences():
    """Every sentence game.py can say (kept in step by test_game.py)."""
    out = []
    for letter in G.KEY_POS:
        out += [f"Jump to {letter}!", f"Find the {letter}!", f"Hop to {letter}!",
                f"Where's {letter}?", f"That's {letter}.", f"Find {letter}!",
                f"Keep climbing — Jump to {letter}!"]
    out += list(G.CHEERS)
    out += ["Press it!", "It's glowing.", "Nice moves!",
            "The floor is lava!", "Follow the moves!", "Time to row!",
            "Uh oh — a volcanic slug!", "Get ready!",
            "Jump left!", "Jump right!", "Hop!", "Duck!", "Row!", "You can do it!",
            "Throw an ice gem at the slug!", "A treasure chest!", "Press A!",
            "The slug is back!", "Press B!",
            "Blast off into space!", "A lava ball is coming!",
            "Press A to throw an ice gem!", "You froze it!", "You saved the day!",
            "You made it to the top of the volcano!", "You did it!"]
    return out


def clip_path(sentence, base=VOICE_DIR):
    return os.path.join(base, key(sentence) + ".wav")


def clips_for(text, base=VOICE_DIR):
    """Clip files for a callout, or None if any sentence isn't recorded."""
    paths = [clip_path(s, base) for s in sentences(text)]
    if not paths or not all(os.path.exists(p) for p in paths):
        return None
    return paths


def available(base=VOICE_DIR):
    return os.path.isdir(base) and any(n.endswith(".wav") for n in os.listdir(base))


def join_wav(paths, out_path):
    """Join clips (all the same format) into one WAV with short gaps."""
    import wave
    frames, params = [], None
    for p in paths:
        with wave.open(p, "rb") as w:
            params = params or w.getparams()
            frames.append(w.readframes(w.getnframes()))
    gap = b"\0" * (int(params.framerate * GAP) * params.sampwidth * params.nchannels)
    with wave.open(out_path, "wb") as w:
        w.setnchannels(params.nchannels)
        w.setsampwidth(params.sampwidth)
        w.setframerate(params.framerate)
        w.writeframes(gap.join(frames))
    return out_path
