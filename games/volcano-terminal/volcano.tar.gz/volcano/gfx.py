"""Graphics renderer for Volcano Adventure (pygame).

Reads game.Game state each frame and draws it. Everything is laid out on a
960x540 design grid and scaled by K to the real window size. Art is
pre-made PNG (see tools/make_assets.py); here we only scale it once at
start-up and then blit, which keeps it light enough for a Raspberry Pi.
"""
import math
import os
import random
import re

import pygame

import game as G

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")
FONT = os.path.join(ASSETS, "FredokaOne-Regular.ttf")

DW, DH = 960, 540               # design size
FIELD_TOP = 98                  # play field starts below HUD + level tag
FIELD_H = DH - FIELD_TOP

CREAM = (255, 244, 224)
SUN = (255, 210, 63)
TEAL = (94, 242, 199)
INK = (26, 14, 46)
GEMTXT = (191, 244, 234)
CONFETTI = [(94, 242, 199), (255, 210, 63), (255, 90, 31), (143, 251, 224), (255, 244, 224)]

TITLE_RICH = [("The whole floor is ", CREAM), ("hot lava", SUN), ("! Climb the volcano to collect the magical ", CREAM),
              ("ice gems", SUN), (". Your guide calls a letter — ", CREAM), ("press that key", SUN),
              (" to leap to the glowing rock. When the floor is lava, ", CREAM), ("follow the moves", SUN),
              (" to run and row your way across!", CREAM)]

_KEEP = re.compile(r"[^ -ÿ—…•’]")


def clean(text):
    """Drop emoji and other glyphs the font doesn't have."""
    return re.sub(r"\s+", " ", _KEEP.sub("", text)).strip()


def ease_out(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def back_out(t, s=1.4):
    """Overshoot ease, like the browser's cubic-bezier(.3,1.3,.5,1)."""
    t = max(0.0, min(1.0, t)) - 1
    return t * t * ((s + 1) * t + s) + 1


def lerp(a, b, t):
    return a + (b - a) * t


class Renderer:
    def __init__(self, screen, K):
        self.screen = screen
        self.K = K
        self.W, self.H = screen.get_size()
        self._fonts = {}
        self._text = {}
        self._panels = {}
        self._glow = {}
        self._rot = {}
        self.hot = []                  # clickable (rect, key) pairs
        self.particles = []            # confetti
        self.pops = []                 # lava bubble rings
        self.rng = random.Random(3)
        self._seen = {}                # last tween start times we reacted to
        self.meter = 0.0
        self._load()
        self.embers = [self._new_ember(True) for _ in range(18)]
        self.stars = [(self.rng.uniform(0, DW), self.rng.uniform(FIELD_TOP, DH),
                       self.rng.uniform(1, 2.6), self.rng.uniform(0, 6.28)) for _ in range(70)]

    # ------------------------------------------------------------ helpers
    def s(self, v):
        return int(round(v * self.K))

    def img(self, name, w, h=None, alpha=True):
        surf = pygame.image.load(os.path.join(ASSETS, name + ".png"))
        surf = surf.convert_alpha() if alpha else surf.convert()
        if h is None:
            h = w * surf.get_height() / surf.get_width()
        return pygame.transform.smoothscale(surf, (max(1, self.s(w)), max(1, self.s(h))))

    def _load(self):
        self.bg = self.img("bg", DW, DH, alpha=False)
        self.space_bg = self.img("space", DW, DH, alpha=False)
        self.hero = self.img("hero", 100)
        self.space_hero = self.img("hero_float", 130)
        self.face = self.img("face", 52)
        self.ring = self.img("ring", 62)
        self.boat = self.img("boat", 160)
        self.snail = self.img("snail", 110)
        self.slug = self.img("slug", 170)
        self.slug_ice = self.img("slug_ice", 170)
        self.chest = self.img("chest", 125)
        self.chest_open = self.img("chest_open", 125)
        self.crystal = self.img("crystal", 34)
        self.crystal_small = self.img("crystal", 18)
        self.ball = self.img("ball", 112)
        self.ball_ice = self.img("ball_ice", 112)
        self.volcano = self.img("volcano", 230)
        self.note = self.img("note", 24)
        self.speaker = self.img("speaker", 24)
        self.rocks = [self.img(f"rock{i}", 109) for i in range(4)]
        self.rocks_t = [self.img(f"rock{i}_t", 109) for i in range(4)]
        self._glow_src = {}
        for n in ("teal", "orange", "yellow", "ice", "white"):
            src = pygame.image.load(os.path.join(ASSETS, f"glow_{n}.png")).convert_alpha()
            self._glow_src[n] = src

    def font(self, size):
        size = max(6, self.s(size))
        f = self._fonts.get(size)
        if f is None:
            f = self._fonts[size] = pygame.font.Font(FONT, size)
        return f

    def text(self, txt, size, color, shadow=(0, 0, 0, 150), sh=2, outline=None):
        key = (txt, size, color, shadow, sh, outline)
        surf = self._text.get(key)
        if surf is not None:
            return surf
        f = self.font(size)
        main = f.render(txt, True, color)
        pad = self.s(sh) + 2 + (2 if outline else 0)
        surf = pygame.Surface((main.get_width() + pad * 2, main.get_height() + pad * 2), pygame.SRCALPHA)
        if outline:
            o = f.render(txt, True, outline)
            r = max(1, self.s(2))
            for dx in (-r, 0, r):
                for dy in (-r, 0, r):
                    if dx or dy:
                        surf.blit(o, (pad + dx, pad + dy))
        if shadow:
            sd = f.render(txt, True, shadow[:3])
            sd.set_alpha(shadow[3])
            surf.blit(sd, (pad, pad + self.s(sh)))
        surf.blit(main, (pad, pad))
        if len(self._text) > 600:
            self._text.clear()
        self._text[key] = surf
        return surf

    def blit_c(self, surf, cx, cy):
        """Blit centred on design point (cx, cy)."""
        r = surf.get_rect(center=(self.s(cx), self.s(cy)))
        self.screen.blit(surf, r)
        return r

    def panel(self, w, h, r, top, bottom=None, border=None, bw=0, alpha=255):
        key = (w, h, r, top, bottom, border, bw, alpha)
        surf = self._panels.get(key)
        if surf is not None:
            return surf
        ss = 2
        W, H = max(2, self.s(w) * ss), max(2, self.s(h) * ss)
        grad = pygame.Surface((W, H), pygame.SRCALPHA)
        bottom = bottom or top
        for y in range(H):
            t = y / max(1, H - 1)
            c = [int(lerp(a, b, t)) for a, b in zip(top, bottom)]
            if len(c) == 3:
                c.append(255)
            pygame.draw.line(grad, c, (0, y), (W, y))
        mask = pygame.Surface((W, H), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, alpha), (0, 0, W, H), border_radius=self.s(r) * ss)
        grad.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        if border:
            pygame.draw.rect(grad, border, (0, 0, W, H), width=max(1, self.s(bw) * ss),
                             border_radius=self.s(r) * ss)
        surf = pygame.transform.smoothscale(grad, (W // ss, H // ss))
        self._panels[key] = surf
        return surf

    def glow(self, name, size, strength=1.0):
        """Additive glow sprite: blit with BLEND_RGB_ADD."""
        px = max(2, self.s(size))
        if px > 12:   # snap to ~5% size steps so pulsing glows hit the cache
            px = int(round(1.05 ** round(math.log(px, 1.05))))
        lvl = max(1, min(10, int(round(strength * 10))))
        key = (name, px, lvl)
        surf = self._glow.get(key)
        if surf is None:
            src = pygame.transform.smoothscale(self._glow_src[name], (px, px))
            surf = pygame.Surface((px, px))
            surf.fill((0, 0, 0))
            surf.blit(src, (0, 0))
            if lvl < 10:
                k = int(255 * lvl / 10)
                surf.fill((k, k, k), special_flags=pygame.BLEND_RGB_MULT)
            if len(self._glow) > 2000:
                self._glow.clear()
            self._glow[key] = surf
        return surf

    def add_glow(self, name, cx, cy, size, strength=1.0, squash=1.0):
        g = self.glow(name, size, strength)
        if squash != 1.0:
            squash = round(squash * 20) / 20
            key = ("sq", id(g), squash)
            sq = self._glow.get(key)
            if sq is None:
                sq = self._glow[key] = pygame.transform.smoothscale(
                    g, (g.get_width(), max(1, int(g.get_height() * squash))))
            g = sq
        r = g.get_rect(center=(self.s(cx), self.s(cy)))
        self.screen.blit(g, r, special_flags=pygame.BLEND_RGB_ADD)

    def rotated(self, surf, angle, scale=1.0):
        a = round(angle * 2) / 2
        sc = round(scale, 2)
        if a == 0 and sc == 1.0:
            return surf
        key = (id(surf), a, sc)
        out = self._rot.get(key)
        if out is None:
            if len(self._rot) > 300:
                self._rot.clear()
            out = self._rot[key] = pygame.transform.rotozoom(surf, a, sc)
        return out

    def wrap(self, txt, size, width):
        f = self.font(size)
        words, lines, cur = txt.split(" "), [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if f.size(t)[0] <= self.s(width) or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines

    # ------------------------------------------------------------ geometry
    rock_size = 84
    step = 143
    anchor = 0.56 * FIELD_H          # rock centre (field coords) of the current rock
    margin = 125

    def rock_x(self, letter):
        # same mapping as the browser game; 40 px on the right for the meter
        return self.margin + ((G.KEY_POS[letter][1] - 0.5) / 9.0) * (DW - 40 - 2 * self.margin)

    def rock_y(self, i, cam):
        return FIELD_TOP + self.anchor + (cam - i) * self.step

    def hero_anchor(self):
        return FIELD_TOP + self.anchor - (self.rock_size * 0.5 + 100 * 0.30)

    # ------------------------------------------------------------ frame
    def draw(self, game, now, dt):
        self.dt = dt
        self.hot = []
        self._react(game, now)
        if game.state == G.TITLE:
            self.draw_title(game, now)
        else:
            if game.state in (G.SPACE, G.WIN):
                self.draw_space(game, now)
            else:
                self.draw_world(game, now)
            self.draw_hud(game, now)
            self.draw_banner(game, now)
            if game.state == G.WIN:
                self.draw_win(game, now)
        self.draw_particles(dt)
        if game.confirm_quit:
            self.draw_confirm()

    def _react(self, game, now):
        """Start one-shot effects when the game starts certain tweens."""
        for name in ("sparkle", "confetti"):
            tw = game.tweens.get(name)
            start = tw[0] if tw else None
            if start is not None and self._seen.get(name) != start:
                self._seen[name] = start
                if name == "sparkle":
                    x, y = self.obj_pos(game, now)
                    self.burst(x, y - 30, 60, 160)
                else:
                    self.burst(DW / 2, DH * 0.35, 180, DW * 0.7)

    # ------------------------------------------------------------ world
    def draw_world(self, game, now):
        scr = self.screen
        scr.blit(self.bg, (0, 0))
        self.draw_lava_fx(now)
        self.draw_embers(now)
        if not game.rocks:
            return
        clip = pygame.Rect(0, self.s(FIELD_TOP), self.W, self.H - self.s(FIELD_TOP))
        scr.set_clip(clip)

        cam = float(game.cur)
        hop = game.tween_t("hop", now)
        hop_t = None
        if game.state == G.CLIMB and hop and hop[0] < 1:
            hop_t, frm = hop
            cam = frm + ease_out(hop_t)

        # rocks
        shake = game.tween_t("shake", now)
        for i, letter in enumerate(game.rocks):
            y = self.rock_y(i, cam)
            if y < FIELD_TOP - 80 or y > DH + 80:
                continue
            if game.boat and i == game.cur:
                continue
            x = self.rock_x(letter)
            target = game.state == G.CLIMB and i == game.cur + 1
            surf = (self.rocks_t if target else self.rocks)[i % 4]
            if target:
                pulse = 0.5 + 0.5 * math.sin(now * 2 * math.pi / 1.1)
                self.add_glow("teal", x, y, 150 + 30 * pulse, 0.45 + 0.35 * pulse)
            ang = 0
            if target and shake and shake[0] < 1:
                k = math.sin(shake[0] * math.pi * 4) * (1 - shake[0])
                x += 4 * k
                ang = -5 * k
            r = self.blit_c(self.rotated(surf, ang), x, y)
            col = INK if target else CREAM
            sh = (255, 255, 255, 90) if target else (0, 0, 0, 170)
            self.blit_c(self.text(letter, 40, col, shadow=sh), x, y - 2)
            self.hot.append((r, letter.lower()))
            if target:
                bob = 8 * (0.5 - 0.5 * math.cos(now * 2 * math.pi / 1.1))
                cy = y - self.rock_size * 0.62 - 6 + bob
                self.add_glow("teal", x, cy, 60, 0.7)
                self.blit_c(self.crystal, x, cy)

        # hero
        hx = self.rock_x(game.rocks[game.cur])
        hy = self.hero_anchor()
        ang, scale, squash = 0.0, 1.0, 1.0
        if hop_t is not None:
            x0 = self.rock_x(game.rocks[hop[1]])
            hx = lerp(x0, hx, ease_out(hop_t))
            k = math.sin(math.pi * min(1, hop_t / 0.9))
            hy -= 56 * k
            scale = 1 + 0.06 * k
        mv = game.tween_t("move", now)
        if game.state == G.INTERLUDE and mv and mv[0] < 1:
            t, m = mv
            k = math.sin(math.pi * t)
            if m == "left":
                hx -= 34 * k
                ang = 12 * k
            elif m == "right":
                hx += 34 * k
                ang = -12 * k
            elif m == "hop":
                hy -= 58 * k
                scale = 1 + 0.06 * k
            elif m == "duck":
                squash = 1 - 0.3 * k
                hy += 16 * k
            elif m == "row":
                w = math.sin(t * 2 * math.pi)
                hx -= 16 * w
                ang = 8 * w
        hero = self.rotated(self.hero, ang, scale)
        if squash != 1.0:
            hero = pygame.transform.smoothscale(hero, (hero.get_width(), int(hero.get_height() * squash)))
            hy += (1 - squash) * 50
        self.blit_c(hero, hx, hy)
        self.hero_pos = (hx, hy)

        # boat (drawn over the hero so he sits inside it)
        if game.boat:
            t = now * 2 * math.pi / 1.9
            by = self.hero_anchor() + 100 * 0.16 - 2 * (0.5 + 0.5 * math.sin(t))
            self.blit_c(self.rotated(self.boat, 1.5 * math.sin(t)), self.rock_x(game.rocks[game.cur]), by)

        scr.set_clip(None)
        # snail
        if game.snail:
            sn = game.tween_t("snail", now)
            t = back_out(sn[0]) if sn else 1
            bob = 4 * math.sin(now * 2 * math.pi / 1.6)
            self.blit_c(self.snail, lerp(-110, 14 + 55, t), DH - 8 - 38 + bob)
        # slug fight
        if game.obj:
            self.draw_obj(game, now)
        self.draw_meter(game, now)
        if game.state == G.CLIMB:
            self.draw_keys(game, now)
        elif game.state == G.INTERLUDE:
            self.draw_moves(game, now)

    def draw_lava_fx(self, now):
        lava_top = FIELD_TOP + FIELD_H * 0.15
        lava_h = DH - lava_top
        for i, (fx, fy, w) in enumerate([(.14, .28, 74), (.55, .58, 98), (.84, .22, 64),
                                         (.32, .80, 84), (.72, .86, 70), (.45, .18, 60)]):
            ph = math.sin(now * 2 * math.pi / 3.2 + i * 1.3)
            self.add_glow("yellow", fx * DW, lava_top + fy * lava_h - 6 * (0.5 + 0.5 * ph),
                          w * 1.7 * (1 + 0.04 * ph), 0.45 + 0.25 * ph, squash=0.55)
        # little bubbles that pop on the surface
        if self.rng.random() < 0.08:
            self.pops.append([self.rng.uniform(20, DW - 60), self.rng.uniform(lava_top + 30, DH - 10), now])
        alive = []
        for x, y, t0 in self.pops:
            t = (now - t0) / 0.7
            if t < 1:
                alive.append([x, y, t0])
                r = self.s(3 + 9 * t)
                pygame.draw.ellipse(self.screen, (255, 230, 140), (self.s(x) - r, self.s(y) - r // 2, 2 * r, r),
                                    max(1, self.s(2 * (1 - t))))
        self.pops = alive

    def _new_ember(self, anywhere=False):
        r = self.rng
        return [r.uniform(0, DW), r.uniform(0, DH) if anywhere else DH + 10,
                r.uniform(18, 40), r.uniform(-4, 6), r.uniform(3, 7)]

    def draw_embers(self, now):
        dt = self.dt
        for e in self.embers:
            e[1] -= e[2] * dt
            e[0] += e[3] * dt
            if e[1] < -10:
                e[:] = self._new_ember()
            fade = min(1, (DH - e[1]) / 60) * min(1, max(0, e[1]) / 80)
            self.add_glow("yellow", e[0], e[1], e[4] * 2.4, 0.8 * fade)

    def obj_home(self, game):
        hero_x = self.rock_x(game.rocks[game.cur])
        right = hero_x < DW * 0.62
        return (DW * 0.91 - 85 if right else 120), right

    def obj_pos(self, game, now):
        home, right = self.obj_home(game)
        y = FIELD_TOP + FIELD_H * 0.48
        x = home
        tin = game.tween_t("objin", now)
        if tin and tin[0] < 1:
            edge = DW + 120 if right else -120
            x = lerp(edge, home, back_out(tin[0]))
        return x, y

    def draw_obj(self, game, now):
        x, y = self.obj_pos(game, now)
        _home, right = self.obj_home(game)
        if game.obj == "slug":
            surf = self.slug_ice if game.obj_frozen else self.slug
            if not right:
                surf = pygame.transform.flip(surf, True, False)
            ang = 0
            alpha = 255
            if game.obj_frozen:
                ang = -6 if right else 6
                off = game.tween_t("objoff", now)
                if off:
                    if off[0] >= 1:
                        return
                    alpha = int(255 * (1 - off[0]))
                self.add_glow("ice", x, y, 230, 0.6)
            else:
                y += 3 * math.sin(now * 2 * math.pi / 1.1)
                ang = 2 * math.sin(now * 2 * math.pi / 1.1)
            s2 = self.rotated(surf, ang)
            if alpha < 255:
                s2 = s2.copy()
                s2.set_alpha(alpha)
            r = self.blit_c(s2, x, y)
        else:
            pop = game.tween_t("sparkle", now)
            dy = -10 * math.sin(math.pi * min(1, pop[0] / 0.6)) if pop and pop[0] < 1 else 0
            if game.chest_open:
                self.add_glow("yellow", x, y - 20, 200, 0.7)
            r = self.blit_c(self.chest_open if game.chest_open else self.chest, x, y + dy)
        key = game.expected_key()
        if key:
            self.hot.append((r, key))
        if game.obj_letter:
            ly = y - (60 if game.obj == "slug" else 72)
            self.add_glow("teal", x, ly, 110, 0.6)
            self.blit_c(self.text(game.obj_letter, 50, TEAL, shadow=(0, 0, 0, 160), sh=3), x, ly)
        th = game.tween_t("throw", now)
        if th and th[0] < 1 and hasattr(self, "hero_pos"):
            self.draw_gem_fly(self.hero_pos, (x, y - 10), th[0])

    def draw_gem_fly(self, frm, to, t):
        k = ease_out(t)
        gx, gy = lerp(frm[0], to[0], k), lerp(frm[1], to[1], k) - 26 * math.sin(math.pi * t)
        self.add_glow("teal", gx, gy, 70, 0.9)
        self.blit_c(self.rotated(self.crystal, -220 * t), gx, gy)

    def draw_meter(self, game, now):
        target = game.cur / G.TOTAL
        self.meter += (target - self.meter) * 0.15
        x, y0, y1, w = DW - 34, FIELD_TOP + 10, DH - 10, 22
        self.screen.blit(self.panel(w, y1 - y0, 11, (0, 0, 0, 80), border=(255, 255, 255, 50), bw=2),
                         (self.s(x), self.s(y0)))
        full = self.panel(w - 4, y1 - y0 - 4, 9, (94, 242, 199), (63, 224, 180))
        fh = self.s((y1 - y0 - 4) * self.meter)
        if fh > 2:
            # reveal the bottom part of a pre-made full bar
            fh = min(fh, full.get_height())
            self.screen.blit(full, (self.s(x + 2), self.s(y1 - 2) - fh),
                             pygame.Rect(0, full.get_height() - fh, full.get_width(), fh))
        # flag
        fx, fy = self.s(x + w / 2), self.s(y0 + 6)
        pygame.draw.line(self.screen, CREAM, (fx - self.s(4), fy), (fx - self.s(4), fy + self.s(16)), max(1, self.s(2)))
        pygame.draw.polygon(self.screen, (230, 50, 40),
                            [(fx - self.s(3), fy), (fx + self.s(8), fy + self.s(4)), (fx - self.s(3), fy + self.s(9))])

    # ------------------------------------------------------------ bottom panels
    def key_cap(self, w, h, hot):
        if hot:
            return self.panel(w, h, 10, (159, 252, 228), (94, 242, 199)), (31, 158, 125)
        return self.panel(w, h, 10, (255, 230, 196), (233, 185, 138)), (179, 129, 63)

    def draw_cap(self, x, y, w, h, hot, now, alpha=255):
        cap, shade = self.key_cap(w, h, hot)
        if hot:
            self.add_glow("teal", x + w / 2, y + h / 2, w * 2.2, 0.35 + 0.3 * (0.5 + 0.5 * math.sin(now * 6.28)))
        under = self.panel(w, h, 10, shade)
        if alpha < 255:
            cap, under = cap.copy(), under.copy()
            cap.set_alpha(alpha)
            under.set_alpha(alpha)
        self.screen.blit(under, (self.s(x), self.s(y + 4)))
        self.screen.blit(cap, (self.s(x), self.s(y)))
        return pygame.Rect(self.s(x), self.s(y), self.s(w), self.s(h + 4))

    def draw_keys(self, game, now):
        letters = game.level_letters()
        has_target = len(game.rocks) > game.cur + 1
        unit, kw, kh = 42, 36, 36
        width = 9 * unit + kw
        x0 = (DW - width) / 2
        y0 = DH - 3 * (kh + 8) - 18
        self.screen.blit(self.panel(width + 28, 3 * (kh + 8) + 14, 18, (20, 8, 6, 200),
                                    border=(255, 140, 60, 80), bw=2), (self.s(x0 - 14), self.s(y0 - 8)))
        for letter, (r, c) in G.KEY_POS.items():
            x = x0 + (c - 0.5) * unit
            y = y0 + r * (kh + 8)
            active = letter in letters
            hot = active and has_target and letter == game.target
            rect = self.draw_cap(x, y, kw, kh, hot, now, 255 if active else 60)
            col = INK if active else (90, 60, 40)
            self.blit_c(self.text(letter, 21, col, shadow=None), x + kw / 2, y + kh / 2)
            if active:
                self.hot.append((rect, letter.lower()))

    def draw_move_panel(self, prompt, dots, buttons, now):
        """buttons: list of (label, sublabel, key, hot, icon)."""
        w = 560
        x0 = (DW - w) / 2
        h = 150
        y0 = DH - h - 8
        self.screen.blit(self.panel(w, h, 24, (20, 8, 6, 150), border=(255, 140, 60, 90), bw=2),
                         (self.s(x0), self.s(y0)))
        if prompt:
            self.blit_c(self.text(clean(prompt), 32, SUN, shadow=(0, 0, 0, 120), sh=3), DW / 2, y0 + 28)
        if dots:
            n = len(dots)
            for i, st in enumerate(dots):
                cx = DW / 2 + (i - (n - 1) / 2) * 18
                col = {"done": TEAL, "now": SUN}.get(st, (255, 255, 255))
                rad = 7 if st == "now" else 5.5
                alpha = 255 if st else 70
                dot = pygame.Surface((self.s(16), self.s(16)), pygame.SRCALPHA)
                pygame.draw.circle(dot, (*col, alpha), (self.s(8), self.s(8)), self.s(rad))
                self.blit_c(dot, cx, y0 + 58)
        if buttons:
            bw = [max(84, 24 + self.font(18).size(b[0])[0] / self.K) if not b[4] else 92 for b in buttons]
            total = sum(bw) + 12 * (len(buttons) - 1)
            x = DW / 2 - total / 2
            for (label, sub, key, hot, icon), wdt in zip(buttons, bw):
                rect = self.draw_cap(x, y0 + 72, wdt, 62, hot, now)
                cx = x + wdt / 2
                if icon:
                    self.draw_arrow(icon, cx, y0 + 96, INK)
                    self.blit_c(self.text(sub, 14, INK, shadow=None), cx, y0 + 122)
                else:
                    self.blit_c(self.text(label, 24, INK, shadow=None), cx, y0 + 96)
                    self.blit_c(self.text(sub, 13, INK, shadow=None), cx, y0 + 120)
                self.hot.append((rect, key))
                x += wdt + 12

    def draw_arrow(self, direction, cx, cy, color):
        pts = [(0, -12), (11, 1), (4, 1), (4, 12), (-4, 12), (-4, 1), (-11, 1)]   # pointing up
        rot = {"up": 0, "right": 90, "down": 180, "left": 270}[direction]
        a = math.radians(rot)
        out = [(self.s(cx + px * math.cos(a) - py * math.sin(a)),
                self.s(cy + px * math.sin(a) + py * math.cos(a))) for px, py in pts]
        pygame.draw.polygon(self.screen, color, out)

    def draw_moves(self, game, now):
        if not game.prompt:
            return
        m = game.current_move()
        dots = []
        for i in range(len(game.moves)):
            dots.append("done" if i < game.done else ("now" if i == game.step else ""))
        if m in G.RUN_MOVES:
            spec = [("left", "Left (A)", "left"), ("down", "Duck (S)", "duck"),
                    ("up", "Hop (W)", "hop"), ("right", "Right (D)", "right")]
            buttons = [("", sub, G.MOVES[mv][2][0], mv == m, icon) for icon, sub, mv in spec]
        elif m == "row":
            buttons = [("Row!", "Space", "space", True, None)]
        elif m == "throw":
            buttons = [("Throw!", "Space", "space", True, None)]
        elif m == "chest":
            buttons = [("A", "Open!", "a", True, None)]
        else:
            buttons = [("B", "Zap!", "b", True, None)]
        if not game.accepting:
            buttons = [(a, b, c, False, e) for a, b, c, d, e in buttons]
        self.draw_move_panel(game.prompt, dots, buttons, now)

    # ------------------------------------------------------------ HUD
    def draw_hud(self, game, now):
        scr = self.screen
        # guide pill
        lines = self.wrap(clean(game.speech), 19, 400)[:2]
        tw = max([self.font(19).size(l)[0] / self.K for l in lines] + [60])
        pw = min(520, 86 + tw)
        scr.blit(self.panel(pw, 66, 33, (20, 8, 6, 110), border=(255, 140, 60, 80), bw=2),
                 (self.s(12), self.s(8)))
        bob = 0
        g = game.tween_t("guide", now)
        if g and g[0] < 1:
            bob = -4 * abs(math.sin(g[0] * 2 * math.pi))
        ring = self.rotated(self.ring, -(now * 60) % 360)
        self.add_glow("orange", 45, 41 + bob, 90, 0.5)
        self.blit_c(ring, 45, 41 + bob)
        self.blit_c(self.face, 45, 41 + bob)
        for i, ln in enumerate(lines):
            y = 41 + (i - (len(lines) - 1) / 2) * 22
            surf = self.text(ln, 19, CREAM, shadow=(0, 0, 0, 140))
            scr.blit(surf, surf.get_rect(midleft=(self.s(84), self.s(y))))
        # gems
        pop = game.tween_t("gempop", now)
        sc = 1 + 0.25 * math.sin(math.pi * min(1, pop[0] / 0.8)) if pop and pop[0] < 1 else 1
        gem = pygame.Surface((self.s(104), self.s(40)), pygame.SRCALPHA)
        gem.blit(self.panel(104, 40, 20, (20, 8, 6, 110), border=(127, 233, 223, 110), bw=2), (0, 0))
        gem.blit(self.crystal_small, self.crystal_small.get_rect(center=(self.s(22), self.s(20))))
        t1 = self.text(str(game.gems), 22, GEMTXT, shadow=(0, 0, 0, 120))
        gem.blit(t1, t1.get_rect(midleft=(self.s(34), self.s(20))))
        t2 = self.text(f"/{G.GEMS_TOTAL}", 16, (150, 190, 185), shadow=None)
        gem.blit(t2, t2.get_rect(midleft=(self.s(34) + t1.get_width() - self.s(6), self.s(22))))
        self.blit_c(self.rotated(gem, 0, sc), 612, 41)
        # target card (climb only, like the browser game)
        if game.state == G.CLIMB and len(game.rocks) > game.cur + 1:
            self.add_glow("teal", 724, 42, 190, 0.35)
            scr.blit(self.panel(118, 70, 20, (94, 242, 199, 30), border=TEAL, bw=3), (self.s(665), self.s(7)))
            self.blit_c(self.text("JUMP TO", 12, CREAM, shadow=None), 724, 22)
            self.blit_c(self.text(game.target, 46, TEAL, shadow=(0, 0, 0, 150), sh=3), 724, 52)
        # music / voice buttons
        for i, (icon, on, key, label) in enumerate([(self.note, game.music_on, "1", "1"),
                                                    (self.speaker, game.voice_on, "2", "2")]):
            x = 800 + i * 54
            p = self.panel(46, 46, 14, (255, 255, 255, 30 if on else 12), border=(255, 255, 255, 60), bw=2)
            scr.blit(p, (self.s(x), self.s(18)))
            ic = icon if on else self._dim(icon)
            self.blit_c(ic, x + 23, 41)
            if not on:
                pygame.draw.line(scr, (255, 110, 90), (self.s(x + 10), self.s(54)), (self.s(x + 36), self.s(28)),
                                 max(2, self.s(3)))
            self.blit_c(self.text(label, 11, (200, 190, 220), shadow=None), x + 40, 24)
            self.hot.append((pygame.Rect(self.s(x), self.s(18), self.s(46), self.s(46)), key))
        # level tag
        name = {G.SPACE: "Outer Space!", G.WIN: "The Top!"}.get(game.state, game.level_name())
        self.blit_c(self.text(name, 17, SUN, shadow=(0, 0, 0, 120)), DW / 2, 88)

    def _dim(self, surf):
        key = ("dim", id(surf))
        out = self._rot.get(key)
        if out is None:
            out = surf.copy()
            out.set_alpha(90)
            self._rot[key] = out
        return out

    # ------------------------------------------------------------ banner
    def draw_banner(self, game, now):
        bt = game.tween_t("banner", now)
        if not bt or bt[0] >= 1:
            return
        t = bt[0]
        if t < 0.15:
            a, sc = t / 0.15, lerp(0.6, 1.05, t / 0.15)
        elif t < 0.75:
            a, sc = 1, lerp(1.05, 1.0, min(1, (t - 0.15) / 0.2))
        else:
            k = (t - 0.75) / 0.25
            a, sc = 1 - k, lerp(1, 1.1, k)
        cy = FIELD_TOP + FIELD_H * 0.42
        self.add_glow("orange", DW / 2, cy, 900, 0.55 * a, squash=0.4)
        txt = clean(game.banner)
        surf = self.text(txt, 60, (255, 255, 255), shadow=(179, 38, 10, 255), sh=4, outline=(255, 120, 40))
        surf = self.rotated(surf, 0, sc)
        if a < 1:
            surf = surf.copy()
            surf.set_alpha(int(255 * a))
        self.blit_c(surf, DW / 2, cy)

    # ------------------------------------------------------------ space
    def draw_space(self, game, now):
        scr = self.screen
        scr.blit(self.space_bg, (0, 0))
        for x, y, r, ph in self.stars:
            tw = 0.55 + 0.45 * math.sin(now * 2.1 + ph)
            self.add_glow("white", x, y, r * 5, tw)
        hx = DW * 0.28
        hy = FIELD_TOP + FIELD_H * 0.56 - 0.1 * 130 * (0.5 - 0.5 * math.cos(now * 2 * math.pi / 2.4))
        fl = 1 + 0.35 * (0.5 + 0.5 * math.sin(now * 25))
        self.add_glow("orange", hx, hy + 62, 70, 0.9, squash=1.4 * fl)
        self.add_glow("yellow", hx, hy + 56, 40, 0.9, squash=1.3 * fl)
        self.blit_c(self.space_hero, hx, hy)
        self.hero_pos = (hx + 10, hy - 10)
        if game.ball:
            bx, by = DW * 0.87 - 56, FIELD_TOP + FIELD_H * 0.38
            ang, alpha, sc = 0, 255, 1.0
            tin = game.tween_t("ballin", now)
            if tin and tin[0] < 1:
                k = ease_out(tin[0])
                bx = lerp(DW + 100, bx, k)
                sc = lerp(0.6, 1, k)
            off = game.tween_t("balloff", now)
            if off:
                if off[0] >= 1:
                    bx = None
                else:
                    k = off[0] ** 2
                    bx += 170 * k * 1.1
                    by -= 170 * k * 1.1
                    sc *= 1 - 0.5 * k
                    ang = -40 * k
                    alpha = int(255 * (1 - off[0]))
            if bx is not None:
                if game.ball_frozen:
                    self.add_glow("ice", bx, by, 240 * sc, 0.8)
                    surf = self.ball_ice
                else:
                    p = 0.5 + 0.5 * math.sin(now * 2 * math.pi)
                    self.add_glow("orange", bx, by, (210 + 50 * p) * sc, 0.75 + 0.2 * p)
                    surf = self.ball
                surf = self.rotated(surf, ang, sc)
                if alpha < 255:
                    surf = surf.copy()
                    surf.set_alpha(alpha)
                r = self.blit_c(surf, bx, by)
                if game.accepting:
                    self.hot.append((r, "a"))
                if not game.ball_frozen:
                    self.add_glow("teal", bx, by - 84, 100, 0.6)
                    self.blit_c(self.text("A", 50, TEAL, shadow=(0, 0, 0, 160), sh=3), bx, by - 84)
                th = game.tween_t("throw", now)
                if th and th[0] < 1:
                    self.draw_gem_fly(self.hero_pos, (bx, by), th[0])
        self.draw_meter(game, now)
        # space panel
        if game.prompt:
            self.blit_c(self.text(clean(game.prompt), 32, SUN, shadow=(0, 0, 0, 140), sh=3), DW / 2, DH - 100)
        if game.ball and not game.ball_frozen:
            rect = self.draw_cap(DW / 2 - 60, DH - 76, 120, 58, game.accepting, now)
            self.blit_c(self.text("A", 26, INK, shadow=None), DW / 2, DH - 54)
            self.blit_c(self.text("Throw!", 13, INK, shadow=None), DW / 2, DH - 32)
            self.hot.append((rect, "a"))

    # ------------------------------------------------------------ overlays
    def overlay_bg(self):
        key = ("overlay",)
        surf = self._panels.get(key)
        if surf is None:
            surf = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
            for y in range(self.H):
                t = y / self.H
                pygame.draw.line(surf, (int(lerp(36, 61, t)), int(lerp(17, 31, t)), int(lerp(71, 92, t)), 242),
                                 (0, y), (self.W, y))
            self._panels[key] = surf
        self.screen.blit(surf, (0, 0))

    def play_button(self, label, cy, now):
        w = max(260, self.font(28).size(label)[0] / self.K + 70)
        x = DW / 2 - w / 2
        self.add_glow("teal", DW / 2, cy, w * 1.4, 0.3 + 0.15 * math.sin(now * 3), squash=0.4)
        self.screen.blit(self.panel(w, 64, 22, (31, 158, 125)), (self.s(x), self.s(cy - 32 + 7)))
        self.screen.blit(self.panel(w, 64, 22, (143, 251, 224), TEAL), (self.s(x), self.s(cy - 32)))
        self.blit_c(self.text(label, 28, INK, shadow=None), DW / 2, cy)
        self.hot.append((pygame.Rect(self.s(x), self.s(cy - 32), self.s(w), self.s(71)), "enter"))

    def rich(self, parts, size, width, cy, line_h):
        f = self.font(size)
        words = []
        for txt, col in parts:
            for i, w in enumerate(re.split(r"(\s+)", txt)):
                if w:
                    words.append((w, col))
        lines, cur, cw = [], [], 0
        for w, col in words:
            ww = f.size(w)[0]
            if cw + ww > self.s(width) and cur and not w.isspace():
                lines.append(cur)
                cur, cw = [], 0
            if not cur and w.isspace():
                continue
            cur.append((w, col))
            cw += ww
        if cur:
            lines.append(cur)
        y = cy - (len(lines) - 1) * line_h / 2
        for ln in lines:
            while ln and ln[-1][0].isspace():
                ln = ln[:-1]
            total = sum(f.size(w)[0] for w, _ in ln)
            x = self.W / 2 - total / 2
            for w, col in ln:
                if not w.isspace():
                    surf = self.text(w, size, col, shadow=(0, 0, 0, 110), sh=1)
                    pad = self.s(1) + 2
                    self.screen.blit(surf, (x - pad, self.s(y) - surf.get_height() / 2))
                x += f.size(w)[0]
            y += line_h

    def draw_title(self, game, now):
        self.screen.blit(self.bg, (0, 0))
        self.draw_lava_fx(now)
        self.overlay_bg()
        self.draw_embers(now)
        bob = 4 * math.sin(now * 1.5)
        self.add_glow("orange", DW / 2, 112 + bob, 300, 0.45)
        self.blit_c(self.volcano, DW / 2, 92 + bob)
        self.blit_c(self.text("Volcano Adventure", 56, SUN, shadow=(0, 0, 0, 110), sh=4), DW / 2, 212)
        self.blit_c(self.text("The Floor is Lava!", 26, TEAL, shadow=(0, 0, 0, 110)), DW / 2, 256)
        self.rich(TITLE_RICH, 18, 540, 335, 26)
        self.play_button("Let's climb!  (Enter)", 432, now)
        self.blit_c(self.text("Letters to climb • arrows for the moves • 1 music • 2 voice • Esc quit • No timer, no losing!",
                              13, (210, 200, 230), shadow=None), DW / 2, 505)

    def draw_win(self, game, now):
        if not game.win_text:
            return
        self.overlay_bg()
        bob = 4 * math.sin(now * 1.5)
        self.add_glow("yellow", DW / 2, 120 + bob, 260, 0.35)
        self.blit_c(self.volcano, DW / 2, 108 + bob)
        self.blit_c(self.text("You reached the top!", 54, SUN, shadow=(0, 0, 0, 110), sh=4), DW / 2, 236)
        self.blit_c(self.text("Volcano champion!", 28, TEAL, shadow=(0, 0, 0, 110)), DW / 2, 286)
        self.rich([("You collected all ", CREAM), (f"{game.gems}", SUN),
                   (" ice gems, blasted into space, and froze the lava ball!", CREAM)], 19, 460, 340, 28)
        self.play_button("Climb again!  (Enter)", 430, now)

    def draw_confirm(self):
        dim = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        dim.fill((10, 4, 20, 170))
        self.screen.blit(dim, (0, 0))
        self.screen.blit(self.panel(520, 150, 26, (61, 31, 92), (36, 17, 71), border=SUN, bw=3),
                         (self.s(220), self.s(195)))
        self.blit_c(self.text("Quit the game?", 34, SUN), DW / 2, 240)
        self.blit_c(self.text("Press Esc again to quit, any other key to keep playing", 17, CREAM), DW / 2, 292)

    # ------------------------------------------------------------ confetti
    def burst(self, x, y, n, spread):
        r = self.rng
        for _ in range(n):
            self.particles.append({
                "x": x + (r.random() - .5) * spread, "y": y + (r.random() - .5) * 40,
                "vx": (r.random() - .5) * 7 * 30, "vy": -(r.random() * 9 + 4) * 30,
                "g": (0.28 + r.random() * 0.15) * 900, "life": (60 + r.random() * 40) / 60,
                "s": 3 + r.random() * 3.5, "rot": r.random() * 6, "vr": (r.random() - .5) * 0.4 * 60,
                "c": r.choice(CONFETTI)})

    def draw_particles(self, dt):
        if not self.particles:
            return
        alive = []
        for p in self.particles:
            p["vy"] += p["g"] * dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["rot"] += p["vr"] * dt
            p["life"] -= dt
            if p["life"] <= 0 or p["y"] > DH + 20:
                continue
            alive.append(p)
            c, s_ = math.cos(p["rot"]), math.sin(p["rot"])
            hw, hh = p["s"], p["s"] * 0.6
            pts = [(self.s(p["x"] + dx * c - dy * s_), self.s(p["y"] + dx * s_ + dy * c))
                   for dx, dy in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))]
            pygame.draw.polygon(self.screen, p["c"], pts)
        self.particles = alive

    def click(self, pos):
        for rect, key in reversed(self.hot):
            if rect.collidepoint(pos):
                return key
        return None
