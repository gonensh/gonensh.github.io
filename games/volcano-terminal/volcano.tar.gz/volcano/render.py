"""All drawing for Volcano Adventure. Reads game state; never changes it."""
import curses
import math
import random
import textwrap

import game as G
import sprites

MIN_W, MIN_H = 80, 24
STEP_ROWS = 6

# Emoji render double-width (or not at all on the Pi text console), which
# breaks curses layout. Swap them for single-width symbols.
UNI_FIX = {
    0xFE0F: None, 0x1F48E: "◆", 0x2728: "✦", 0x1F9CA: "*", 0x1F389: "✦",
    0x1F31F: "*", 0x2B05: "←", 0x27A1: "→", 0x2B06: "↑", 0x2B07: "↓",
    0x1F6A3: "", 0x1F40C: "", 0x1F9F0: "", 0x2604: "", 0x1F5E3: "",
}

_ASCII_PAIRS = {
    "◆": "*", "✦": "*", "✧": "+", "←": "<", "→": ">", "↑": "^", "↓": "v",
    "—": "-", "–": "-", "…": "...", "•": "*", "●": "o", "○": "o", "◉": "O",
    "≈": "~", "∼": "-", "█": "#", "▓": "#", "▒": ":", "░": ".", "▄": "_",
    "▀": "\"", "▐": "|", "▌": "|", "─": "-", "│": "|", "┌": "+", "┐": "+",
    "└": "+", "┘": "+", "♪": "music", "⚑": "P", "°": "o", "▽": "v",
    "╱": "/", "╲": "\\", "╯": "/", "╰": "\\", "╹": "'", "▣": "o", "×": "x",
    "▾": "v", "ò": "o", "ó": "o", "’": "'", "·": ".", "★": "*",
    "\U0001F48E": "*", "✨": "*", "\U0001F9CA": "*", "\U0001F389": "*",
    "\U0001F31F": "*", "⬅": "<-", "➡": "->", "⬆": "^",
    "⬇": "v", "\U0001F6A3": "", "\U0001F40C": "", "\U0001F9F0": "",
    "☄": "", "\U0001F5E3": "", "️": "",
}
ASCII_FIX = {ord(k): v for k, v in _ASCII_PAIRS.items()}

# name: (256-colour index, 8-colour fallback, bold in 8-colour mode)
FG = {
    "lava_y": (220, curses.COLOR_YELLOW, True),
    "lava_o": (208, curses.COLOR_YELLOW, False),
    "lava_r": (160, curses.COLOR_RED, False),
    "rock": (244, curses.COLOR_WHITE, False),
    "teal": (43, curses.COLOR_CYAN, True),
    "sky": (52, curses.COLOR_RED, False),
    "gem": (51, curses.COLOR_CYAN, True),
    "cream": (230, curses.COLOR_WHITE, True),
    "slug": (202, curses.COLOR_RED, True),
    "snail": (114, curses.COLOR_GREEN, True),
    "tan": (180, curses.COLOR_YELLOW, False),
    "brown": (94, curses.COLOR_YELLOW, False),
    "orange": (208, curses.COLOR_YELLOW, True),
    "ice": (153, curses.COLOR_CYAN, False),
    "gold": (220, curses.COLOR_YELLOW, True),
    "white": (255, curses.COLOR_WHITE, True),
    "dim": (240, curses.COLOR_WHITE, False),
    "magenta": (213, curses.COLOR_MAGENTA, True),
    "blue": (75, curses.COLOR_BLUE, True),
    "green": (46, curses.COLOR_GREEN, True),
}
# name: (fg 256, bg 256, fg 8, bg 8)
BG = {
    "rock_bg": (16, 244, curses.COLOR_BLACK, curses.COLOR_WHITE),
    "target_bg": (16, 43, curses.COLOR_BLACK, curses.COLOR_CYAN),
    "target_bg2": (16, 51, curses.COLOR_BLACK, curses.COLOR_CYAN),
    "banner": (16, 208, curses.COLOR_BLACK, curses.COLOR_YELLOW),
    "banner2": (16, 160, curses.COLOR_WHITE, curses.COLOR_RED),
}
MONO = {
    "lava_y": curses.A_BOLD, "lava_r": curses.A_DIM, "teal": curses.A_BOLD,
    "gem": curses.A_BOLD, "target_bg": curses.A_REVERSE | curses.A_BOLD,
    "target_bg2": curses.A_REVERSE, "banner": curses.A_REVERSE | curses.A_BOLD,
    "banner2": curses.A_REVERSE, "dim": curses.A_DIM, "sky": curses.A_DIM,
    "gold": curses.A_BOLD, "cream": curses.A_BOLD,
}
MASK_COLORS = {
    "T": "tan", "S": "cream", "G": "teal", "B": "brown", "Y": "gold",
    "O": "orange", "R": "slug", "N": "snail", "W": "white", "I": "ice",
    "K": "gem", "D": "rock", "L": "lava_y",
}
CONFETTI_COLORS = ["gold", "teal", "magenta", "green", "blue", "orange", "white"]

KEY_LABEL = {"left": "←", "right": "→", "hop": "↑", "duck": "↓",
             "row": "SPC", "throw": "SPC", "chest": "A", "zap": "B"}
BUTTONS = {"left": " ← A  Left ", "right": " → D  Right ",
           "hop": " ↑ W  Hop ", "duck": " ↓ S  Duck "}

TITLE_TEXT = ("The whole floor is hot lava! Climb the volcano to collect the "
              "magical ice gems. Your guide calls a letter — press that key to "
              "leap to the glowing rock. When the floor is lava, follow the "
              "moves to run and row your way across!")


class Renderer:
    def __init__(self, scr, ascii_mode=False):
        self.scr = scr
        self.ascii = ascii_mode
        self.spr = sprites.ASCII if ascii_mode else sprites.UNICODE
        self.rock_parts = sprites.ROCK["ascii" if ascii_mode else "unicode"]
        self._init_colors()
        self.last_sig = None
        self.confetti_start = None
        self.confetti = []
        self.resize()

    # ------------------------------------------------------------ setup
    def _init_colors(self):
        self.mode = "mono"
        self.attrs = {}
        if curses.has_colors():
            try:
                curses.start_color()
                if curses.COLORS >= 256:
                    self.mode = "256"
                elif curses.COLORS >= 8:
                    self.mode = "8"
            except curses.error:
                self.mode = "mono"
        if self.mode == "mono":
            return
        n = 1
        for name, (c256, c8, bold) in FG.items():
            fg = c256 if self.mode == "256" else c8
            curses.init_pair(n, fg, curses.COLOR_BLACK)
            a = curses.color_pair(n)
            if self.mode == "8" and bold:
                a |= curses.A_BOLD
            if self.mode == "8" and name == "dim":
                a |= curses.A_DIM
            self.attrs[name] = a
            n += 1
        for name, (f256, b256, f8, b8) in BG.items():
            if self.mode == "256":
                curses.init_pair(n, f256, b256)
            else:
                curses.init_pair(n, f8, b8)
            self.attrs[name] = curses.color_pair(n)
            n += 1

    def attr(self, name):
        if self.mode == "mono":
            return MONO.get(name, curses.A_NORMAL)
        return self.attrs.get(name, curses.A_NORMAL)

    def resize(self):
        self.h, self.w = self.scr.getmaxyx()
        self.small = self.h < MIN_H or self.w < MIN_W
        self.play_top = 3
        self.play_h = max(1, self.h - 8)
        self.play_bot = self.play_top + self.play_h      # exclusive
        self.play_w = self.w - 3
        self.sky_h = 3
        self._lava_cache = {}
        self.clip = (0, self.h, 0, self.w)
        rng = random.Random(self.w * 1000 + self.h)
        self.stars = [(rng.randrange(self.play_h), rng.randrange(self.play_w),
                       rng.choice("·.*+✦"), rng.randrange(9))
                      for _ in range(max(10, self.play_w * self.play_h // 28))]
        self.last_sig = None
        try:
            self.scr.clear()
        except curses.error:
            pass

    # ------------------------------------------------------------ primitives
    def put(self, y, x, s, a=0):
        y0, y1, x0, x1 = self.clip
        if not s or y < y0 or y >= y1:
            return
        if self.ascii:
            s = s.translate(ASCII_FIX)
            if not s.isascii():
                s = "".join(c if ord(c) < 128 else "?" for c in s)
        else:
            s = s.translate(UNI_FIX)
        if x < x0:
            s = s[x0 - x:]
            x = x0
        if x >= x1 or not s:
            return
        s = s[:x1 - x]
        try:
            self.scr.addstr(y, x, s, a)
        except curses.error:
            pass   # writing the bottom-right cell raises; harmless

    def center(self, y, s, a=0, x0=0, width=None):
        width = self.w if width is None else width
        s2 = s.translate(UNI_FIX).strip()
        if self.ascii:
            s2 = s2.translate(ASCII_FIX)
        self.put(y, x0 + max(0, (width - len(s2)) // 2), s2, a)

    def sprite(self, y, x, spr, override=None, extra=0):
        rows, masks = spr
        for r, line in enumerate(rows):
            mask = masks[r]
            i, n = 0, len(line)
            while i < n:
                if line[i] == " ":
                    i += 1
                    continue
                m = mask[i] if i < len(mask) else "S"
                j = i + 1
                while j < n and line[j] != " " and (mask[j] if j < len(mask) else "S") == m:
                    j += 1
                name = override or MASK_COLORS.get(m, "cream")
                self.put(y + r, x + i, line[i:j], self.attr(name) | extra)
                i = j

    def bigbox(self, y, x, label, color="teal"):
        rows = list(self.spr["bigbox"][0])
        inner = label.center(3)[:3]
        rows[1] = rows[1][0] + inner + rows[1][-1]
        self.put(y, x, rows[0], self.attr(color) | curses.A_BOLD)
        self.put(y + 1, x, rows[1][0], self.attr(color) | curses.A_BOLD)
        self.put(y + 1, x + 1, inner, self.attr("white") | curses.A_BOLD)
        self.put(y + 1, x + 4, rows[1][-1], self.attr(color) | curses.A_BOLD)
        self.put(y + 2, x, rows[2], self.attr(color) | curses.A_BOLD)

    # ------------------------------------------------------------ frame
    def frame(self, game, now, force=False):
        tick = int(now / 0.15)
        sig = (game.version, tick)
        if not force and sig == self.last_sig and not game.animating(now):
            return False
        self.last_sig = sig
        self.draw(game, now, tick)
        return True

    def draw(self, game, now, tick):
        self.scr.erase()
        self.clip = (0, self.h, 0, self.w)
        if self.small:
            msg = "Please make the window bigger (80×24)"
            self.put(self.h // 2, max(0, (self.w - len(msg)) // 2), msg,
                     curses.A_BOLD)
        elif game.state == G.TITLE:
            self.draw_title(tick)
        else:
            self.draw_hud(game, now)
            if game.state == G.SPACE:
                self.draw_space(game, now, tick)
            elif game.state == G.WIN:
                self.draw_win(game, now, tick)
            else:
                self.draw_world(game, now, tick)
            self.clip = (0, self.h, 0, self.w)
            self.draw_meter(game)
            self.draw_banner(game, now)
            self.clip = (0, self.h, 0, self.w)
            self.draw_panel(game, now)
        if game.confirm_quit and not self.small:
            self.draw_confirm()
        self.scr.noutrefresh()
        curses.doupdate()

    # ------------------------------------------------------------ title
    def draw_title(self, tick):
        w = self.w
        for y in (1, 2, 3):
            self.put(y, 2, " " * (w - 4), self.attr("banner"))
        title = "V O L C A N O   A D V E N T U R E"
        self.center(2, title, self.attr("banner") | curses.A_BOLD)
        self.center(5, "The Floor is Lava!", self.attr("lava_y") | curses.A_BOLD)
        vol = self.spr["volcano"]
        vx = (w - len(vol[0][0])) // 2
        self.sprite(7, vx, vol)
        # little lava spurts above the crater
        sp = "✦ ◆ ✦" if tick % 4 < 2 else "◆ ✦ ◆"
        self.center(6, sp, self.attr("orange"))
        tw = min(w - 6, 70)
        lines = textwrap.wrap(TITLE_TEXT, tw)
        y = 14
        for ln in lines:
            self.center(y, ln, self.attr("cream"))
            y += 1
        self.center(self.h - 3, "Press Enter to start • Esc to quit • No timer, no losing!",
                    self.attr("teal") | curses.A_BOLD)
        # lava strip at the very bottom
        self.clip = (self.h - 2, self.h, 0, self.w)
        for y in (self.h - 2, self.h - 1):
            self.lava_row(y, 0, self.w, tick)
        self.clip = (0, self.h, 0, self.w)

    # ------------------------------------------------------------ hud
    def draw_hud(self, game, now):
        w = self.w
        bx = w - 19
        # guide (bobs while speaking)
        gy = 0
        tw = game.tween_t("guide", now)
        if tw and tw[0] < 1:
            gy = int(tw[0] * 4) % 2
        self.put(gy, 1, "(^_^)", self.attr("orange") | curses.A_BOLD)
        sw = bx - 9 - 9
        lines = textwrap.wrap(game.speech.translate(UNI_FIX), max(10, sw))[:2]
        for i, ln in enumerate(lines):
            self.put(i, 8, ln,
                     self.attr("cream") | (curses.A_BOLD if i == 0 else 0))
        # gems
        pop = game.tween_t("gempop", now)
        ga = self.attr("gem") | curses.A_BOLD
        if pop and pop[0] < 1:
            ga |= curses.A_REVERSE
        self.put(1, bx - 8, f"◆ {game.gems}/{G.GEMS_TOTAL}", ga)
        # separator with level name
        self.put(2, 0, "─" * (bx - 1), self.attr("dim"))
        name = f" {game.level_name()} "
        if game.state == G.SPACE:
            name = " Outer Space "
        elif game.state == G.WIN:
            name = " The Top! "
        self.put(2, max(0, (bx - len(name)) // 2), name,
                 self.attr("cream") | curses.A_BOLD)
        self.put(2, bx + 6, "─" * (w - bx - 6), self.attr("dim"))
        # target box
        self.bigbox(0, bx, self.box_label(game))
        # toggles
        self.put(0, bx + 7, f"1 ♪ {'on' if game.music_on else 'off'}",
                 self.attr("cream" if game.music_on else "dim"))
        self.put(1, bx + 7, f"2 voice {'on' if game.voice_on else 'off'}",
                 self.attr("cream" if game.voice_on else "dim"))

    def box_label(self, game):
        if game.state == G.CLIMB and game.target and len(game.rocks) > game.cur + 1:
            return game.target
        if game.state == G.INTERLUDE:
            m = game.current_move()
            if m and game.prompt:
                return KEY_LABEL[m]
        if game.state == G.SPACE and game.ball and not game.ball_frozen:
            return "A"
        return ""

    # ------------------------------------------------------------ world
    def lava_row(self, y, x0, width, tick):
        # Lava only changes every 150 ms, so cache each row's colour runs
        # per tick: frames in between reuse them (cheap on a slow Pi).
        ck = (y, width, tick)
        runs = self._lava_cache.get(ck)
        if runs is None:
            if len(self._lava_cache) > 400:
                self._lava_cache.clear()
            chars = "~=-" if self.ascii else "≈~∼"
            cols = ("lava_y", "lava_o", "lava_r")
            sin = math.sin
            a, b = y * 0.9 + tick * 0.55, -y * 0.5 - tick * 0.3
            lv = []
            for x in range(width):
                v = sin(x * 0.42 + a) + sin(x * 0.17 + b)
                lv.append(0 if v > 0.7 else (1 if v > -0.6 else 2))
            runs = []
            x = 0
            while x < width:
                j = x + 1
                while j < width and lv[j] == lv[x]:
                    j += 1
                runs.append((x, chars[(lv[x] + tick) % 3] * (j - x), cols[lv[x]]))
                x = j
            self._lava_cache[ck] = runs
        for rx, s, c in runs:
            self.put(y, x0 + rx, s, self.attr(c))

    def draw_backdrop(self, tick):
        top, pw = self.play_top, self.play_w
        # sky band
        pat1 = ("##::" if self.ascii else "▓▓▒▒")
        pat2 = (":.:." if self.ascii else "▒░▒░")
        row1 = (pat1 * (pw // 4 + 2))[:pw]
        row2 = (pat2 * (pw // 4 + 2))[1:pw + 1]
        self.put(top, 0, row1, self.attr("sky"))
        self.put(top + 1, 0, row2, self.attr("sky"))
        glow = "lava_y" if tick % 6 < 3 else "orange"
        self.put(top + 2, 0, "~" * pw, self.attr(glow) | curses.A_BOLD)
        for y in range(top + self.sky_h, self.play_bot):
            self.lava_row(y, 0, pw, tick)

    def rock_top(self, i, cam):
        base = self.play_top + int(self.play_h * 0.65)
        return base - int(round((i - cam) * STEP_ROWS))

    def draw_rock(self, row, cx, letter, target, tick, shake=0):
        left = int(round(cx - 3.5)) + shake
        top, mid, bot = self.rock_parts
        if target:
            fg = self.attr("teal") | curses.A_BOLD
            bgname = "target_bg" if (tick // 3) % 2 == 0 else "target_bg2"
            bg = self.attr(bgname) | curses.A_BOLD
        else:
            fg = self.attr("rock")
            bg = self.attr("rock_bg") | curses.A_BOLD
        self.put(row, left, top, fg)
        if self.ascii:
            self.put(row + 1, left, mid.format(letter), bg)
        else:
            self.put(row + 1, left, mid.format(letter), bg)
        self.put(row + 2, left, bot, fg)

    def hero_pos(self, game, now):
        """Returns (left x, top y, pose) of the hero in screen coords."""
        cam = float(game.cur)
        cx = G.col_x(game.rocks[game.cur], self.play_w)
        top = self.rock_top(game.cur, cam) - 4
        hop = game.tween_t("hop", now)
        if game.state == G.CLIMB and hop and hop[0] < 1:
            t, frm = hop
            cam = frm + G.ease_out(t)
            x0 = G.col_x(game.rocks[frm], self.play_w)
            y0 = self.rock_top(frm, cam) - 4
            y1 = self.rock_top(game.cur, cam) - 4
            cx = x0 + (cx - x0) * t
            top = int(round(y0 + (y1 - y0) * t - 12 * t * (1 - t)))
        pose = "hero"
        dx = dy = 0
        mv = game.tween_t("move", now)
        if game.state == G.INTERLUDE and mv and mv[0] < 1:
            t, m = mv
            s = math.sin(math.pi * t)
            if m == "left":
                dx, dy = -round(4 * s), -round(s)
            elif m == "right":
                dx, dy = round(4 * s), -round(s)
            elif m == "hop":
                dy = -round(3 * s)
            elif m == "duck":
                pose = "hero_duck"
            elif m == "row":
                dx = -1 if t < 0.5 else 1
        if game.boat:
            pose = "hero_sit"
        return int(round(cx - 2.5)) + dx, top + dy, pose, cam

    def draw_world(self, game, now, tick):
        self.clip = (self.play_top, self.play_bot, 0, self.play_w)
        self.draw_backdrop(tick)
        if not game.rocks:
            return
        hx, hy, pose, cam = self.hero_pos(game, now)
        shake = 0
        sh = game.tween_t("shake", now)
        if sh and sh[0] < 1:
            shake = int(round(2 * math.sin(sh[0] * math.pi * 6) * (1 - sh[0])))
        for i, letter in enumerate(game.rocks):
            row = self.rock_top(i, cam)
            if row > self.play_bot or row + 3 < self.play_top:
                continue
            if game.boat and i == game.cur:
                continue
            is_target = game.state == G.CLIMB and i == game.cur + 1
            cx = G.col_x(letter, self.play_w)
            self.draw_rock(row, cx, letter, is_target, tick,
                           shake if is_target else 0)
            if is_target:
                cy = row - 1 - (1 if tick % 6 < 3 else 0)
                self.put(cy, int(cx), "◆",
                         self.attr("gem") | curses.A_BOLD)
        # boat
        if game.boat:
            bob = 1 if math.sin(now * 3.5) > 0.3 else 0
            brow = self.rock_top(game.cur, cam) + bob
            bcx = G.col_x(game.rocks[game.cur], self.play_w)
            self.sprite(brow, int(round(bcx - 5.5)), self.spr["boat"])
            hy = brow - 3
        # snail
        if game.snail:
            sn = game.tween_t("snail", now)
            t = G.ease_out(sn[0]) if sn else 1
            sx = int(-8 + 10 * t)
            self.sprite(self.play_bot - 2, sx, self.spr["snail"])
        # slug fight objects
        orow = self.rock_top(game.cur, cam) - 3
        ox = None
        if game.obj:
            ox = self.obj_x(game, now)
            if ox is not None:
                frozen = game.obj_frozen
                if game.obj == "slug":
                    self.sprite(orow, ox, self.spr["slug"],
                                override="ice" if frozen else None)
                else:
                    spr = self.spr["chest_open" if game.chest_open else "chest"]
                    self.sprite(orow, ox, spr)
                    sp = game.tween_t("sparkle", now)
                    if sp and sp[0] < 1:
                        r = random.Random(int(now * 8))
                        for _ in range(6):
                            self.put(orow - 1 + r.randrange(4),
                                     ox - 2 + r.randrange(13),
                                     r.choice("✦✧*+"),
                                     self.attr(r.choice(["gold", "white", "gem"])) | curses.A_BOLD)
                if game.obj_letter:
                    self.bigbox(orow - 4, ox + 2, game.obj_letter)
        # hero
        self.sprite(hy + (1 if pose == "hero_duck" else 0), hx, self.spr[pose])
        # thrown gem
        th = game.tween_t("throw", now)
        if th and th[0] < 1 and game.obj and ox is not None:
            tx = ox + 4
            t = th[0]
            gx = int(round(hx + 4 + (tx - hx - 4) * t))
            gy = int(round(hy + 1 + (orow + 1 - hy - 1) * t))
            self.put(gy, gx, "◆", self.attr("gem") | curses.A_BOLD)

    def obj_x(self, game, now):
        """Slug/chest x. Normally on the right; if the hero stands on a
        right-hand rock, use the left side so they never overlap."""
        hero_cx = G.col_x(game.rocks[game.cur], self.play_w)
        right = hero_cx < self.play_w - 30
        home = self.play_w - 16 if right else 4
        edge = self.play_w + 2 if right else -12
        sign = 1 if right else -1
        x = home
        tin = game.tween_t("objin", now)
        if tin and tin[0] < 1:
            x = int(round(edge + (home - edge) * G.ease_out(tin[0])))
        off = game.tween_t("objoff", now)
        if game.obj_frozen and off:
            if off[0] >= 1:
                return None
            x = home + sign * int(round(20 * off[0]))
        return x

    # ------------------------------------------------------------ space
    def draw_space(self, game, now, tick):
        self.clip = (self.play_top, self.play_bot, 0, self.play_w)
        top = self.play_top
        for i, (sy, sx, ch, ph) in enumerate(self.stars):
            bright = (tick + ph) % 9 < 6
            self.put(top + sy, sx, ch if bright else "·",
                     self.attr("white" if bright else "dim"))
        mid = top + self.play_h // 2
        bob = 1 if math.sin(now * 2.2) > 0 else 0
        hx = int(self.play_w * 0.28)
        hy = mid - 3 + bob
        self.sprite(hy, hx, self.spr["hero"])
        frows, fmask = self.spr["flame"]
        fl = (frows, fmask if tick % 2 == 0 else [fmask[0].replace("O", "X").replace("L", "O").replace("X", "L")])
        self.sprite(hy + 4, hx + 1, fl)
        if game.ball:
            bx, by = self.ball_pos(game, now)
            if bx is not None:
                ov = "ice" if game.ball_frozen else None
                spr = self.spr["ball"]
                if not game.ball_frozen and tick % 4 < 2:
                    spr = (spr[0], [m.replace("O", "x").replace("L", "O").replace("x", "L")
                                    for m in spr[1]])
                self.sprite(by, bx, spr, override=ov, extra=curses.A_BOLD)
                if not game.ball_frozen:
                    self.bigbox(by - 4, bx, "A")
            th = game.tween_t("throw", now)
            if th and th[0] < 1:
                t = th[0]
                tx, ty = (bx if bx is not None else self.play_w), by
                gx = int(round(hx + 4 + (tx + 2 - hx - 4) * t))
                gy = int(round(hy + 1 + (ty + 1 - hy - 1) * t))
                self.put(gy, gx, "◆", self.attr("gem") | curses.A_BOLD)

    def ball_pos(self, game, now):
        home_x = int(self.play_w * 0.72)
        home_y = self.play_top + self.play_h // 2 - 1
        x, y = home_x, home_y
        tin = game.tween_t("ballin", now)
        if tin and tin[0] < 1:
            x = int(round(self.play_w + 2 - (self.play_w + 2 - home_x) * G.ease_out(tin[0])))
        off = game.tween_t("balloff", now)
        if off:
            if off[0] >= 1:
                return None, y
            x = home_x + int(round(off[0] * self.play_w * 0.4))
            y = home_y - int(round(off[0] * self.play_h * 0.7))
        return x, y

    # ------------------------------------------------------------ win
    def draw_win(self, game, now, tick):
        self.clip = (self.play_top, self.play_bot, 0, self.play_w)
        tw = game.tweens.get("confetti")
        start = tw[0] if tw else now
        if self.confetti_start != start:
            self.confetti_start = start
            r = random.Random(int(start * 1000))
            self.confetti = [(r.uniform(-1, 1) * self.play_w * 0.45,
                              r.uniform(-1.2, 0.2) * self.play_h * 0.9,
                              r.choice("*+✦•o"), r.choice(CONFETTI_COLORS),
                              r.uniform(0.6, 1.4))
                             for _ in range(90)]
        t = now - start
        mid = self.play_top + self.play_h // 2
        quiet = (mid - 3, mid + 6) if game.win_text else None
        cx = self.play_w / 2
        cy = self.play_top + self.play_h * 0.55
        for vx, vy, ch, col, sp in self.confetti:
            if t < 3:
                x = cx + vx * min(t, 1.2)
                y = cy + vy * min(t, 1.2) + 4 * max(0, t - 0.4) ** 2
            else:   # gentle endless fall
                x = cx + vx * 1.2
                y = self.play_top + ((vy + (t - 3) * 3 * sp) % self.play_h)
            if quiet and quiet[0] <= int(y) <= quiet[1]:
                continue   # keep the win text readable
            self.put(int(y), int(x), ch, self.attr(col) | curses.A_BOLD)
        if game.win_text:
            self.center(mid - 3, "You reached the top!",
                        self.attr("gold") | curses.A_BOLD, 0, self.play_w)
            self.center(mid - 1, "Volcano champion! 🎉",
                        self.attr("teal") | curses.A_BOLD, 0, self.play_w)
            line = ("You collected all 6 ice gems, blasted into space, "
                    "and froze the lava ball! 🌟")
            for i, ln in enumerate(textwrap.wrap(line.translate(UNI_FIX), self.play_w - 6)):
                self.center(mid + 1 + i, ln, self.attr("cream"), 0, self.play_w)
            self.sprite(mid + 3, self.play_w // 2 - 2, self.spr["hero"])

    # ------------------------------------------------------------ overlays
    def draw_meter(self, game):
        x = self.w - 2
        top, bot = self.play_top, self.play_bot
        self.put(top, x, "⚑", self.attr("gold") | curses.A_BOLD)
        n = bot - top - 1
        filled = int(round(n * game.cur / G.TOTAL))
        for i in range(n):
            y = bot - 1 - i
            if i < filled:
                self.put(y, x, "▐█" if not self.ascii else "|#", self.attr("teal"))
            else:
                self.put(y, x, "▐░" if not self.ascii else "|.", self.attr("dim"))

    def draw_banner(self, game, now):
        bt = game.tween_t("banner", now)
        if not bt or bt[0] >= 1:
            return
        mid = self.play_top + self.play_h // 2 - 1
        name = "banner" if int(now * 5) % 2 == 0 else "banner2"
        a = self.attr(name)
        for y in (mid - 1, mid, mid + 1):
            self.put(y, 0, " " * self.play_w, a)
        self.center(mid, game.banner, a | curses.A_BOLD, 0, self.play_w)

    def draw_confirm(self):
        msg = "Quit? Esc again to quit, any other key to keep playing"
        bw = len(msg) + 4
        x = (self.w - bw) // 2
        y = self.h // 2 - 2
        a = self.attr("banner") | curses.A_BOLD
        for i in range(5):
            self.put(y + i, x, " " * bw, a)
        self.put(y + 2, x + 2, msg, a)

    # ------------------------------------------------------------ panel
    def draw_panel(self, game, now):
        h, w = self.h, self.w
        self.put(h - 5, 0, "─" * w, self.attr("dim"))
        self.center(h - 1, "1 music  2 voice  0 restart  Esc quit  •  No timer, no losing!",
                    self.attr("dim"))
        y = h - 4
        if game.state == G.CLIMB:
            self.panel_keys(game, y)
        elif game.state == G.INTERLUDE:
            self.panel_moves(game, y)
        elif game.state == G.SPACE:
            if game.prompt:
                self.center(y, game.prompt, self.attr("gold") | curses.A_BOLD)
            if game.ball and not game.ball_frozen:
                self.button(y + 2, [(" A  Freeze! ", True)])
        elif game.state == G.WIN and game.win_text:
            self.center(y + 1, "Press Enter to climb again",
                        self.attr("teal") | curses.A_BOLD)

    def panel_keys(self, game, y0):
        letters = game.level_letters()
        has_target = len(game.rocks) > game.cur + 1
        unit = 5
        x0 = (self.w - 51) // 2
        dot = "." if self.ascii else "·"
        for letter, (r, c) in G.KEY_POS.items():
            x = x0 + int(c * unit)
            if letter in letters:
                if has_target and letter == game.target:
                    a = self.attr("target_bg") | curses.A_BOLD
                    if self.mode == "mono":
                        a = curses.A_REVERSE | curses.A_BOLD
                else:
                    a = self.attr("rock_bg")
                self.put(y0 + r, x, f" {letter} ", a)
            else:
                self.put(y0 + r, x, f" {dot} ", self.attr("dim"))

    def panel_moves(self, game, y0):
        if not game.prompt:
            self.center(y0 + 1, "Get ready...", self.attr("cream") | curses.A_BOLD)
            return
        self.center(y0, game.prompt, self.attr("gold") | curses.A_BOLD)
        dots = []
        for i in range(len(game.moves)):
            if i < game.done:
                dots.append(("●", "teal"))
            elif i == game.step:
                dots.append(("◉", "gold"))
            else:
                dots.append(("○", "dim"))
        x = (self.w - (len(dots) * 2 - 1)) // 2
        for i, (ch, col) in enumerate(dots):
            self.put(y0 + 1, x + i * 2, ch, self.attr(col) | curses.A_BOLD)
        m = game.current_move()
        if m in G.RUN_MOVES:
            self.button(y0 + 2, [(BUTTONS[k], k == m) for k in G.RUN_MOVES])
        elif m == "row":
            self.button(y0 + 2, [(" Space  ROW! ", True)])
        elif m == "throw":
            self.button(y0 + 2, [(" Space  Throw! ", True)])
        elif m == "chest":
            self.button(y0 + 2, [(" A ", True)])
        elif m == "zap":
            self.button(y0 + 2, [(" B ", True)])

    def button(self, y, items):
        total = sum(len(t) for t, _ in items) + 2 * (len(items) - 1)
        x = (self.w - total) // 2
        for text, hot in items:
            if hot:
                a = self.attr("target_bg") | curses.A_BOLD
                if self.mode == "mono":
                    a = curses.A_REVERSE | curses.A_BOLD
            else:
                a = self.attr("dim")
            self.put(y, x, text, a)
            x += len(text) + 2
