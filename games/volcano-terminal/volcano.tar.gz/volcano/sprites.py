"""Sprite art for Volcano Adventure. All original.

Each sprite is (rows, masks). A mask character picks the colour of the
sprite character at the same position; a space in a sprite row is
transparent. Mask legend (see render.MASK_COLORS):
  T tan  S cream/skin  G teal  B brown  Y gold  O orange  R slug red
  N snail green  W white  I ice  K gem teal  D rock grey  L lava yellow
"""


def _auto(rows, cmap, default="D"):
    masks = ["".join(cmap.get(ch, default) if ch != " " else " " for ch in r)
             for r in rows]
    return rows, masks


UNICODE = {
    "hero": ([" ▄°°▄", "(^▽^)", "╱█▓█╲", " ╯ ╰ "],
             [" TSST", "SSSSS", "SGGGS", " G G "]),
    "hero_duck": ([" ▄°°▄", "(^▽^)", "╰█▓█╯"],
                  [" TSST", "SSSSS", "SGGGS"]),
    "hero_sit": ([" ▄°°▄", "(^▽^)", "╱█▓█╲"],
                 [" TSST", "SSSSS", "SGGGS"]),
    "boat": ([" ▄▄▄▄▄▄▄▄▄ ", "╱▀▀▀▀▀▀▀▀▀╲"],
             [" BBBBBBBBB ", "TBBBBBBBBBT"]),
    "snail": ([" ▄▄  ╹╹", "(@)▄▄█▀"],
              [" OO  NN", "OOONNNN"]),
    "slug": (["  ╲  ╱   ", " (ò_ó)▄▄▄", " ▀▀▀▀▀▀▀▀▀"],
             ["  R  R   ", " RRRRRRRR", " RRRRRRRRR"]),
    "chest": ([" ▄▄▄▄▄▄▄ ", " █▀▀▣▀▀█ ", " ███████ "],
              [" BBBBBBB ", " BBBYBBB ", " BBBBBBB "]),
    "chest_open": ([" ✦  ✧  ✦ ", " ▄▀▀▀▀▀▄ ", " █▄▄Y▄▄█ "],
                   [" Y  W  Y ", " BBBBBBB ", " BBBYBBB "]),
    "ball": ([" ●●● ", "●●●●●", " ●●● "],
             [" OOO ", "OLLLO", " OOO "]),
    "flame": (["▾▾▾"], ["OLO"]),
    "bigbox": (["┌───┐", "│ ? │", "└───┘"], ["GGGGG", "GGWGG", "GGGGG"]),
    "volcano": _auto(["     ≈≈≈≈     ",
                      "    ▄█▓▓█▄    ",
                      "   ▄██▓███▄   ",
                      "  ▄████▓███▄  ",
                      " ▄██████▓███▄ ",
                      "▄████████████▄"], {"≈": "L", "▓": "O"}),
}
UNICODE["chest_open"] = ([" ✦  ✧  ✦ ", " ▄▀▀▀▀▀▄ ", " █▄▄▄▄▄█ "],
                         [" Y  W  Y ", " BBBBBBB ", " BBBBBBB "])

ASCII = {
    "hero": ([" _oo_", "(^v^)", "/|#|\\", " / \\ "],
             [" TSST", "SSSSS", "SGGGS", " G G "]),
    "hero_duck": ([" _oo_", "(^v^)", "\\|#|/"],
                  [" TSST", "SSSSS", "SGGGS"]),
    "hero_sit": ([" _oo_", "(^v^)", "/|#|\\"],
                 [" TSST", "SSSSS", "SGGGS"]),
    "boat": ([" _________ ", "/\\_______/\\"],
             [" BBBBBBBBB ", "TBBBBBBBBBT"]),
    "snail": ([" _   oo", "(@)__/'"],
              [" O   NN", "OOONNNN"]),
    "slug": (["  \\  /   ", " (o_o)___", " `~~~~~~~'"],
             ["  R  R   ", " RRRRRRRR", " RRRRRRRRR"]),
    "chest": ([" _______ ", " |==o==| ", " |_____| "],
              [" BBBBBBB ", " BBBYBBB ", " BBBBBBB "]),
    "chest_open": ([" *  +  * ", " /-----\\ ", " |_____| "],
                   [" Y  W  Y ", " BBBBBBB ", " BBBBBBB "]),
    "ball": ([" ooo ", "oOOOo", " ooo "],
             [" OOO ", "OLLLO", " OOO "]),
    "flame": (["vvv"], ["OLO"]),
    "bigbox": (["+---+", "| ? |", "+---+"], ["GGGGG", "GGWGG", "GGGGG"]),
    "volcano": _auto(["     ~~~~     ",
                      "    /#**#\\    ",
                      "   /##*###\\   ",
                      "  /####*###\\  ",
                      " /######*###\\ ",
                      "/############\\"], {"~": "L", "*": "O"}),
}

# Rock pieces (7 wide x 3 tall); the middle row is drawn on a background colour.
ROCK = {
    "unicode": (" ▄▄▄▄▄ ", "   {}   ", " ▀▀▀▀▀ "),
    "ascii": (" .---. ", "|  {}  |", " '---' "),
}
