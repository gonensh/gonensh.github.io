"""Tests for the game rules, the terminal keyboard and the sound synth.

    python3 -m unittest test_game
"""
import unittest

import audio
import game as G
from keys import Keyboard


class FakeOut:
    def __init__(self):
        self.data = ""

    def write(self, s):
        self.data += s

    def flush(self):
        pass


def fresh(level=0):
    g = G.Game(rand=lambda: 0.5)
    g.load_level(level)
    g.state = G.PLAY
    return g


def hold(g, frames, **keys):
    inp = {"left": False, "right": False, "jump": False, "sprint": False, "throw": False}
    inp.update(keys)
    for _ in range(frames):
        g.inp = dict(inp)
        g.step()


class TestMatchesBrowserGame(unittest.TestCase):
    # Where the autopilot ends up after 3000 steps from each level. These
    # numbers were checked against the browser game's own code (dg.html),
    # run with the same key presses: they match to the last digit.
    GOLDEN = {
        0: ("play", 1, 2119.46, 406, 20, 2, 6),
        1: ("dead", 1, 3525.56, 692.519, 20, 2, 6),
        2: ("play", 2, 635.84, 406.58, 9, 1, 8),
        3: ("play", 0, 4167.14, 406, 6, 3, 5),
    }
    # the same, starting with a power-up (the autopilot flaps and throws fireballs)
    GOLDEN_POWER = {
        (0, "fire"): ("play", 1, 1919.86, 406.58, 25, 1, 5),
        (1, "wings"): ("play", 2, 1304.48, 277.24, 9, 1, 8),
        (2, "wings"): ("play", 3, 4658.112, 406.58, 6, 3, 5),
        (3, "fire"): ("play", 0, 4671.86, 406, 10, 3, 4),
    }

    def test_golden_runs(self):
        cases = [((lv, None), w) for lv, w in self.GOLDEN.items()]
        cases += list(self.GOLDEN_POWER.items())
        for (level, power), want in cases:
            g = fresh(level)
            if power:
                g.p.big = True
                g.size_player()
                g.p.power = power
            bot = G.Bot(g)
            for _ in range(3000):
                g.inp = bot.inputs()
                g.step()
            p = g.p
            got = (g.state, g.li, round(p.x, 3), round(p.y, 3), g.stars, g.hearts, len(g.enemies))
            self.assertEqual(got, want, "level %d %s" % (level + 1, power))


class TestRules(unittest.TestCase):
    def test_levels(self):
        g = G.Game()
        self.assertEqual([lv.name for lv in g.levels],
                         ["Sunny Hills", "Cloud Hopper", "Volcano Rumble", "Frozen Peak"])
        for lv in g.levels:
            self.assertEqual(len(lv.grid), G.ROWS)
            self.assertTrue(all(len(r) == lv.width for r in lv.grid))
        self.assertTrue(g.levels[3].has_boss)

    def test_title_then_play(self):
        g = G.Game()
        self.assertEqual(g.state, G.TITLE)
        hold(g, 25)
        g.key("enter")
        self.assertEqual(g.state, G.PLAY)

    def test_walk_and_stand(self):
        g = fresh()
        hold(g, 30)
        self.assertEqual(g.player_anim(), "idle")
        x0 = g.p.x
        hold(g, 30, right=True)
        self.assertGreater(g.p.x, x0 + 60)
        self.assertEqual(g.p.face, 1)

    def test_jump_height(self):
        g = fresh()
        hold(g, 30)
        y0 = g.p.y
        top = y0
        g.inp = {"left": False, "right": False, "jump": True, "sprint": False, "throw": False}
        for _ in range(40):
            g.step()
            top = min(top, g.p.y)
        self.assertLess(top, y0 - 150)       # a full jump is about 4.5 tiles

    def test_short_hop_when_released(self):
        g = fresh()
        hold(g, 30)
        y0 = g.p.y
        hold(g, 4, jump=True)
        top = g.p.y
        for _ in range(30):
            hold(g, 1)
            top = min(top, g.p.y)
        self.assertGreater(top, y0 - 100)

    def test_collect_star(self):
        g = fresh()
        g.p.x, g.p.y = 6 * G.TILE, 10 * G.TILE - g.p.h + 10
        hold(g, 2)
        self.assertGreaterEqual(g.stars, 1)
        self.assertIn(("sound", "star"), g.events)

    def test_stomp_blob(self):
        g = fresh()
        blob = next(e for e in g.enemies if e.type == "blob")
        g.p.x, g.p.y = blob.x, blob.y - 60
        g.p.vy = 5
        for _ in range(20):
            hold(g, 1)
            if blob.dead:
                break
        self.assertTrue(blob.dead)
        self.assertEqual(g.hearts, 3)

    def test_touch_blob_hurts(self):
        g = fresh()
        hold(g, 20)
        blob = next(e for e in g.enemies if e.type == "blob")
        g.p.x, g.p.y = blob.x, blob.y + blob.h - g.p.h
        blob.vx = 0
        hold(g, 2)
        self.assertEqual(g.state, G.DEAD)
        self.assertEqual(g.hearts, 2)

    def test_power_up_and_shrink(self):
        g = fresh()
        g.p.big = True
        g.size_player()
        g.hurt()
        self.assertFalse(g.p.big)
        self.assertEqual(g.state, G.PLAY)
        self.assertEqual(g.hearts, 3)

    def test_respawn_and_game_over(self):
        g = fresh()
        g.die()
        hold(g, 75)
        self.assertEqual(g.state, G.PLAY)
        self.assertEqual(g.hearts, 2)
        g.die(); hold(g, 75)
        g.die(); hold(g, 75)
        self.assertEqual(g.state, G.GAMEOVER)
        hold(g, 25)
        g.key("space")
        self.assertEqual((g.state, g.li, g.hearts), (G.PLAY, 0, 3))

    def test_question_block(self):
        g = fresh()
        g.hit_block(10, 7)
        self.assertEqual(g.tile(10, 7), "u")
        self.assertEqual(g.stars, 1)
        g.hit_block(12, 7)                       # the power-up block
        self.assertEqual(len(g.items), 1)

    def test_big_breaks_bricks(self):
        g = fresh()
        g.hit_block(9, 7)
        self.assertEqual(g.tile(9, 7), "b")
        g.p.big = True
        g.hit_block(9, 7)
        self.assertEqual(g.tile(9, 7), " ")

    def test_boss_fight_opens_the_wall(self):
        g = fresh(3)
        boss = g.boss()
        self.assertEqual(g.tile(120, 5), "=")
        g.p.x, g.p.y = 106 * G.TILE, 11 * G.TILE - g.p.h
        g.cam = g.clamp_cam(g.p.x - 300)
        for _ in range(2000):
            g.p.boss_hp = 5                      # stay safe while testing
            g.p.invuln = 10
            if boss.dead:
                break
            # face the boss and throw
            hold(g, 1, right=g.p.x + 100 < boss.x, left=g.p.x > boss.x + 100,
                 throw=g.tick % 21 == 0)
            if boss.x - g.p.x < 140:
                g.p.x = boss.x - 200
        self.assertTrue(boss.dead)
        self.assertEqual(g.tile(120, 5), " ")

    def test_level_clear_moves_on(self):
        g = fresh()
        fc, fr = g.level.flag_pos
        g.p.x, g.p.y = fc * G.TILE, fr * G.TILE
        hold(g, 1)
        self.assertEqual(g.state, G.CLEARED)
        hold(g, 160)
        self.assertEqual((g.state, g.li), (G.PLAY, 1))

    def test_wings_block_and_flying(self):
        g = fresh()
        g.hit_block(13, 7)
        self.assertEqual(g.items[0].type, "wings")
        it = g.items[0]
        g.p.x, g.p.y = it.x, it.y
        hold(g, 1)
        self.assertEqual(g.p.power, "wings")
        self.assertTrue(g.p.big)
        # in the air, each jump press flaps upward
        g.p.x, g.p.y, g.p.vy = 20 * G.TILE, 120, 5
        hold(g, 10)                           # past the "coyote" moment
        hold(g, 1, jump=True)
        self.assertLess(g.p.vy, -6)
        self.assertIn(("sound", "flap"), g.events)
        # holding jump while falling glides
        hold(g, 40, jump=True)
        self.assertLessEqual(g.p.vy, G.GLIDE_MAX)

    def test_fire_hat_fireballs(self):
        g = fresh()
        g.hit_block(58, 7)
        self.assertEqual(g.items[0].type, "fire")
        g.p.big = True
        g.size_player()
        g.p.power = "fire"
        blob = next(e for e in g.enemies if e.type == "blob")
        g.p.x, g.p.y = blob.x - 150, blob.y + blob.h - g.p.h
        g.p.face = 1
        blob.vx = 0
        hold(g, 1, throw=True)
        self.assertEqual(len(g.fireballs), 1)
        for _ in range(60):
            hold(g, 1)
            if blob.dead:
                break
        self.assertTrue(blob.dead)
        self.assertEqual(g.hearts, 3)

    def test_fireballs_hurt_the_ice_king(self):
        g = fresh(3)
        boss = g.boss()
        g.p.big = True
        g.size_player()
        g.p.power = "fire"
        g.p.x, g.p.y = boss.x - 200, 11 * G.TILE - g.p.h
        g.cam = g.clamp_cam(g.p.x - 200)
        hp = boss.hp
        for i in range(120):
            g.p.invuln = 10
            hold(g, 1, throw=i % 15 == 0)
        self.assertLess(boss.hp, hp)

    def test_knocked_back_when_hit(self):
        g = fresh()
        hold(g, 20)
        g.p.big = True
        g.size_player()
        g.p.power = "wings"
        blob = next(e for e in g.enemies if e.type == "blob")
        blob.vx = 0
        g.p.x, g.p.y = blob.x - g.p.w + 4, blob.y + blob.h - g.p.h
        hold(g, 1)
        self.assertIsNone(g.p.power)          # the power-up took the hit
        self.assertTrue(g.p.big)
        self.assertLess(g.p.vx, -5)           # thrown away from the blob...
        self.assertLess(g.p.vy, -5)           # ...and up
        self.assertIn(("sound", "punch"), g.events)
        self.assertTrue(any(p[2] == "POW!" for p in g.pops))
        # can't steer back into it straight away
        hold(g, 10, right=True)
        self.assertLess(g.p.vx, 0)

    def test_knocked_out_flies_off(self):
        g = fresh()
        hold(g, 20)
        blob = next(e for e in g.enemies if e.type == "blob")
        blob.vx = 0
        g.p.x, g.p.y = blob.x + blob.w - 4, blob.y + blob.h - g.p.h
        x = g.p.x
        hold(g, 1)
        self.assertEqual(g.state, G.DEAD)
        hold(g, 30)
        self.assertGreater(g.p.x, x + 60)

    def test_ice_is_slippery(self):
        def slide(level):
            g = fresh(level)
            g.enemies = []
            g.p.x = 3 * G.TILE
            hold(g, 20)
            hold(g, 90, right=True)
            x = g.p.x
            hold(g, 120)
            return g.p.x - x
        self.assertLess(slide(0), 20)
        self.assertGreater(slide(3), 120)

    def test_confirm_quit(self):
        g = fresh()
        g.key("esc")
        self.assertTrue(g.confirm_quit)
        x = g.p.x
        hold(g, 20, right=True)
        self.assertEqual(g.p.x, x)             # paused while asking
        g.key("n")
        self.assertFalse(g.confirm_quit)
        g.key("esc")
        g.key("y")
        self.assertTrue(g.quit)

    def test_music_toggle(self):
        g = fresh()
        self.assertTrue(g.music_wanted)
        g.key("m")
        self.assertFalse(g.music_wanted)
        self.assertIn(("music", False), g.events)


class TestKeyboard(unittest.TestCase):
    def test_legacy_hold(self):
        kb = Keyboard(FakeOut())
        kb.feed(b"\x1b[C", 0.0)
        self.assertTrue(kb.state(0.2)["right"])
        self.assertFalse(kb.state(0.5)["right"])          # released after a tap
        # auto-repeat keeps it held
        kb.feed(b"\x1b[C", 1.0)
        for t in (1.45, 1.48, 1.51, 1.54, 1.57):
            kb.feed(b"\x1b[C", t)
        self.assertTrue(kb.state(1.65)["right"])
        self.assertFalse(kb.state(1.75)["right"])

    def test_legacy_opposite_cancels(self):
        kb = Keyboard(FakeOut())
        kb.feed(b"d", 0.0)
        kb.feed(b"a", 0.1)
        st = kb.state(0.15)
        self.assertTrue(st["left"])
        self.assertFalse(st["right"])

    def test_legacy_jump_and_sprint(self):
        kb = Keyboard(FakeOut())
        kb.feed(b" ", 0.0)
        self.assertTrue(kb.state(0.3)["jump"])
        self.assertFalse(kb.state(0.4)["jump"])
        kb.feed(b"\x1b[1;2C", 1.0)            # Shift + Right
        st = kb.state(1.1)
        self.assertTrue(st["right"] and st["sprint"])
        kb.feed(b"D", 2.0)                    # capital D = Shift + D
        self.assertTrue(kb.state(2.1)["sprint"])

    def test_legacy_quick_retap_is_a_new_press(self):
        kb = Keyboard(FakeOut())
        kb.feed(b" ", 0.0)
        self.assertTrue(kb.state(0.05)["jump"])
        kb.feed(b" ", 0.15)                   # tapped again (flap!)
        self.assertFalse(kb.state(0.16)["jump"])
        self.assertTrue(kb.state(0.17)["jump"])
        for t in (0.20, 0.23, 0.26):          # auto-repeat doesn't re-press
            kb.feed(b" ", t)
            self.assertTrue(kb.state(t + 0.001)["jump"])

    def test_lone_escape(self):
        kb = Keyboard(FakeOut())
        kb.feed(b"\x1b", 0.0)
        self.assertEqual(kb.take_presses(), [])
        kb.feed(b"", 0.1)
        self.assertEqual(kb.take_presses(), [("esc", False)])

    def test_kitty_protocol(self):
        out = FakeOut()
        kb = Keyboard(out)
        kb.probe()
        self.assertIn("\x1b[?u", out.data)
        kb.feed(b"\x1b[?0u\x1b[?62;22c", 0.0)
        self.assertTrue(kb.kitty)
        self.assertIn("\x1b[>11u", out.data)
        kb.feed(b"\x1b[1;1:1C", 0.0)          # right pressed
        self.assertTrue(kb.state(5.0)["right"])  # held as long as it's down
        kb.feed(b"\x1b[1;1:3C", 5.0)          # right released
        self.assertFalse(kb.state(5.01)["right"])
        kb.feed(b"\x1b[57441u", 6.0)          # shift down
        self.assertTrue(kb.state(6.5)["sprint"])
        kb.feed(b"\x1b[57441;2:3u", 7.0)
        self.assertFalse(kb.state(7.1)["sprint"])
        kb.feed(b"\x1b[32u", 8.0)             # space
        self.assertTrue(kb.state(8.5)["jump"])
        kb.feed(b"\x1b[99;5u", 9.0)           # Ctrl+C
        self.assertIn(("ctrl-c", False), kb.take_presses())
        kb.close()
        self.assertTrue(out.data.endswith("\x1b[<u"))


class TestAudio(unittest.TestCase):
    def test_synth(self):
        music = audio.render_music()
        self.assertAlmostEqual(len(music) / 2 / audio.RATE, 32 * audio.MUSIC_STEP, places=2)
        for name in audio.SFX:
            self.assertGreater(len(audio.render_sfx(name)), 1000, name)


if __name__ == "__main__":
    unittest.main()
