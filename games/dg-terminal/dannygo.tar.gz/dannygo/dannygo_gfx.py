#!/usr/bin/env python3
"""Danny Go! Jump Adventure - graphics edition (pygame).

    python3 dannygo_gfx.py [--window] [--res 540|720|1080] [--fps N]
                           [--no-music] [--level N] [--autoplay]

Same game rules as the terminal edition (game.py); this file adds a
window, pictures, keyboard + gamepad input and pygame sound.
Needs pygame 2 (sudo apt install python3-pygame).
"""
import argparse
import os
import sys
import threading
import time

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "1")

import pygame  # noqa: E402

import audio as A  # noqa: E402
import game as G  # noqa: E402
from gfx import DH, DW, Renderer  # noqa: E402


class MixerAudio:
    """Music and effects through pygame.mixer (no child processes)."""

    def __init__(self, music_on):
        self.music_on = music_on
        self.sounds = {}
        self._raw = {}
        self.channel = None
        self.paused = False
        pygame.mixer.set_num_channels(12)
        threading.Thread(target=self._synth, daemon=True).start()

    def _synth(self):
        try:
            self._raw["music"] = A.render_music()
            for name in A.SFX:
                self._raw[name] = A.render_sfx(name)
        except Exception:
            pass

    def handle(self, event):
        kind, val = event
        if kind == "sound":
            if self.music_on and val in self.sounds:
                self.sounds[val].play()
        elif kind == "music":
            self.music_on = val

    def tick(self, want_music):
        for name in list(self._raw):
            try:
                self.sounds[name] = pygame.mixer.Sound(buffer=self._raw.pop(name))
            except Exception:
                pass
        if want_music and "music" in self.sounds:
            if self.channel is None or not self.channel.get_busy():
                self.channel = self.sounds["music"].play(loops=-1)
            elif self.paused:
                self.channel.unpause()
            self.paused = False
        elif self.channel is not None and not self.paused:
            self.channel.pause()
            self.paused = True

    def close(self):
        try:
            pygame.mixer.stop()
        except Exception:
            pass


def make_audio(music_on):
    try:
        pygame.mixer.pre_init(A.RATE, -16, 1, 512)
        pygame.mixer.init()
        if pygame.mixer.get_init():
            return MixerAudio(music_on)
    except Exception:
        pass
    return A.Audio(music_on)        # no mixer: try aplay & co, or stay silent


LEFT = {pygame.K_LEFT, pygame.K_a}
RIGHT = {pygame.K_RIGHT, pygame.K_d}
JUMP = {pygame.K_UP, pygame.K_w, pygame.K_SPACE, pygame.K_z, pygame.K_LALT, pygame.K_RALT}
SPRINT = {pygame.K_LCTRL, pygame.K_RCTRL, pygame.K_LSHIFT, pygame.K_RSHIFT}
THROW = {pygame.K_x}


def pi_model():
    try:
        with open("/proc/device-tree/model") as f:
            return f.read()
    except OSError:
        return ""


def default_res(screen_h):
    m = pi_model()
    small = "Zero" in m or "Raspberry Pi 3" in m or "Raspberry Pi 2" in m or "Model A" in m
    res = 540 if small else 720
    return min(res, max(360, screen_h))


class Input:
    """Keys and gamepads held down right now."""

    def __init__(self):
        self.keys = set()
        self.pads = {}
        self.pad_state = {"left": False, "right": False, "jump": False,
                          "sprint": False, "throw": False}

    def add_pad(self, index):
        try:
            js = pygame.joystick.Joystick(index)
            js.init()
            self.pads[js.get_instance_id()] = js
        except pygame.error:
            pass

    def poll_pads(self):
        st = {"left": False, "right": False, "jump": False, "sprint": False, "throw": False}
        for js in self.pads.values():
            try:
                if js.get_numaxes() >= 1:
                    ax = js.get_axis(0)
                    st["left"] |= ax < -0.45
                    st["right"] |= ax > 0.45
                for h in range(js.get_numhats()):
                    hx, hy = js.get_hat(h)
                    st["left"] |= hx < 0
                    st["right"] |= hx > 0
                    st["jump"] |= hy > 0
                nb = js.get_numbuttons()
                b = [js.get_button(i) for i in range(nb)]
                st["jump"] |= any(b[i] for i in (0, 1) if i < nb)
                st["throw"] |= any(b[i] for i in (2, 3) if i < nb)
                st["sprint"] |= any(b[i] for i in (4, 5) if i < nb)
            except pygame.error:
                pass
        self.pad_state = st

    def state(self):
        k = self.keys
        p = self.pad_state
        return {"left": bool(k & LEFT) or p["left"],
                "right": bool(k & RIGHT) or p["right"],
                "jump": bool(k & JUMP) or p["jump"],
                "sprint": bool(k & SPRINT) or p["sprint"],
                "throw": bool(k & THROW) or p["throw"]}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Danny Go! Jump Adventure - graphics edition")
    ap.add_argument("--window", action="store_true", help="run in a window instead of full screen")
    ap.add_argument("--res", type=int, default=None,
                    help="drawing height in pixels: 540 (Pi Zero 2 / Pi 3), 720 (default), 1080")
    ap.add_argument("--fps", type=int, default=30, help="frames drawn per second (default 30)")
    ap.add_argument("--no-music", action="store_true", help="start with sound off")
    ap.add_argument("--level", type=int, default=1, help="start on this level (1-4)")
    ap.add_argument("--autoplay", action="store_true", help="the game plays itself, then exits")
    ap.add_argument("--seconds", type=float, default=0, help="with --autoplay: stop after this long")
    ap.add_argument("--screenshot", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args(argv)

    try:
        pygame.display.init()
    except pygame.error as e:
        print("Can't open a graphics screen here (%s)." % e, file=sys.stderr)
        return 3            # the launcher then starts the text version
    pygame.font.init()
    info = pygame.display.Info()
    screen_h = info.current_h if info.current_h > 0 else 720
    res = args.res or default_res(screen_h)
    K = res / DH
    size = (int(round(DW * K)), int(round(DH * K)))
    flags = pygame.SCALED
    if not args.window:
        flags |= pygame.FULLSCREEN
    try:
        screen = pygame.display.set_mode(size, flags)
    except pygame.error:
        try:
            screen = pygame.display.set_mode(size)
        except pygame.error as e:
            print("Can't open a graphics screen here (%s)." % e, file=sys.stderr)
            return 3
    pygame.display.set_caption("Danny Go! Jump Adventure")
    pygame.mouse.set_visible(args.window)
    try:
        pygame.joystick.init()
    except pygame.error:
        pass

    # quick "loading" frame: scaling the pictures takes a moment on a Pi
    screen.fill((27, 16, 48))
    pygame.display.flip()

    audio = make_audio(not args.no_music)
    renderer = Renderer(screen, K)
    game = G.Game(music_on=not args.no_music)
    if args.level > 1:
        game.load_level(max(0, min(len(game.levels) - 1, args.level - 1)))
        game.state = G.PLAY
    inp = Input()
    for i in range(pygame.joystick.get_count() if pygame.joystick.get_init() else 0):
        inp.add_pad(i)
    bot = G.Bot(game) if args.autoplay else None

    clock = pygame.time.Clock()
    last = time.monotonic()
    started = last
    acc = 0.0
    victory_since = None
    frames = 0
    try:
        while not game.quit:
            menu = game.state in (G.TITLE, G.GAMEOVER, G.VICTORY)
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    game.quit = True
                elif ev.type == pygame.KEYDOWN:
                    inp.keys.add(ev.key)
                    if ev.key == pygame.K_ESCAPE:
                        game.key("esc")
                    elif ev.key in (pygame.K_m, pygame.K_1):
                        game.key("m")
                    elif game.confirm_quit:
                        game.key({pygame.K_y: "y", pygame.K_n: "n"}.get(ev.key, "x"))
                    elif menu:
                        game.key("enter")
                elif ev.type == pygame.KEYUP:
                    inp.keys.discard(ev.key)
                elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    if game.confirm_quit:
                        game.key("n")
                    elif menu:
                        game.key("enter")
                elif ev.type == pygame.JOYDEVICEADDED:
                    inp.add_pad(ev.device_index)
                elif ev.type == pygame.JOYDEVICEREMOVED:
                    inp.pads.pop(ev.instance_id, None)
                elif ev.type == pygame.JOYBUTTONDOWN and menu and not game.confirm_quit:
                    game.key("enter")
                elif ev.type == pygame.WINDOWFOCUSLOST:
                    inp.keys.clear()
            if inp.pads:
                inp.poll_pads()

            now = time.monotonic()
            acc += min(0.1, now - last)
            last = now
            steps = 0
            while acc >= G.STEP and steps < 5:
                game.inp = bot.inputs() if bot else inp.state()
                game.step()
                acc -= G.STEP
                steps += 1

            for e in game.pop_events():
                audio.handle(e)
            audio.tick(game.music_wanted)
            renderer.draw(game)
            pygame.display.flip()
            frames += 1
            if args.screenshot and frames == 20:
                pygame.image.save(screen, args.screenshot)
                break

            if bot:
                if game.state == G.VICTORY:
                    victory_since = victory_since or now
                    if now - victory_since > 3:
                        break
                if args.seconds and now - started > args.seconds:
                    break
            clock.tick(args.fps)
    except KeyboardInterrupt:
        pass
    finally:
        audio.close()
        pygame.quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())
