"""Keyboard for the terminal edition.

A platformer needs to know which keys are held down, but most terminals
only report key *presses*. So:

* Terminals that speak the kitty keyboard protocol (kitty, foot, WezTerm,
  Ghostty, recent Alacritty/iTerm2...) are asked for press / repeat /
  release events, and movement works exactly like the web game.
* Everywhere else a press counts as "held" for a moment, and the
  keyboard's auto-repeat keeps it held while the key stays down.
"""
import sys
import time

# legacy hold timings (seconds)
FIRST_HOLD = 0.40     # covers the pause before the keyboard starts repeating
REPEAT_HOLD = 0.12    # each auto-repeat keeps the key held this much longer
JUMP_HOLD = 0.32      # a tap is a full-height jump
THROW_HOLD = 0.10
REPEAT_WINDOW = 0.8   # presses of the same key closer than this are auto-repeat

KITTY_FUNC = {57441: "shift", 57447: "shift", 57442: "ctrl", 57448: "ctrl",
              57443: "alt", 57449: "alt"}
CSI_FINAL = {"A": "up", "B": "down", "C": "right", "D": "left", "H": "home", "F": "end"}
TILDE = {2: "insert", 3: "delete", 5: "pgup", 6: "pgdn"}

ACTIONS = {
    "left": "left", "a": "left",
    "right": "right", "d": "right",
    "up": "jump", "w": "jump", "space": "jump", "z": "jump", "alt": "jump",
    "x": "throw",
    "shift": "sprint", "ctrl": "sprint",
}


def _name(code):
    if code == 13 or code == 10:
        return "enter"
    if code == 27:
        return "esc"
    if code == 32:
        return "space"
    if code == 9:
        return "tab"
    if code in (127, 8):
        return "backspace"
    if code in KITTY_FUNC:
        return KITTY_FUNC[code]
    if 33 <= code < 127:
        return chr(code).lower()
    return None


class Keyboard:
    def __init__(self, out=None):
        self.out = out or sys.stdout
        self.buf = b""
        self.esc_at = None
        self.kitty = False
        self.last_press = {}
        self.retap = False     # jump tapped again while still "held" (wings flaps)
        self.down = {}         # key -> hold-until time (legacy) or float('inf') (kitty)
        self.mods_shift = 0.0
        self.presses = []      # (key, shift) pressed since last read

    # ------------------------------------------------ setup / teardown
    def probe(self):
        """Ask the terminal whether it supports the kitty protocol."""
        self._send("\x1b[?u\x1b[c")

    def close(self):
        if self.kitty:
            self._send("\x1b[<u")
            self.kitty = False

    def _send(self, s):
        try:
            self.out.write(s)
            self.out.flush()
        except Exception:
            pass

    # ------------------------------------------------ input bytes
    def feed(self, data, now=None):
        now = time.monotonic() if now is None else now
        self.buf += data
        self._parse(now)

    def _parse(self, now):
        b = self.buf
        i = 0
        n = len(b)
        while i < n:
            c = b[i]
            if c == 0x1b:
                if i + 1 >= n:
                    # lone ESC so far: wait a moment for the rest of a sequence
                    if self.esc_at is None:
                        self.esc_at = now
                    if now - self.esc_at >= 0.06:
                        self._press("esc", now)
                        self.esc_at = None
                        i += 1
                        continue
                    break
                nxt = b[i + 1]
                if nxt == ord("["):
                    j = i + 2
                    while j < n and not (0x40 <= b[j] <= 0x7e):
                        j += 1
                    if j >= n:
                        break               # incomplete
                    self._csi(b[i + 2:j].decode("latin-1"), chr(b[j]), now)
                    i = j + 1
                elif nxt == ord("O"):
                    if i + 2 >= n:
                        break
                    k = CSI_FINAL.get(chr(b[i + 2]))
                    if k:
                        self._press(k, now)
                    i += 3
                elif nxt == 0x1b:
                    self._press("esc", now)
                    i += 1
                else:
                    # Alt+key
                    self._press(_name(nxt) or "?", now)
                    i += 2
                self.esc_at = None
                continue
            if c == 3:
                self._press("ctrl-c", now)
            elif c < 32 and c not in (9, 10, 13, 27):
                pass
            else:
                k = _name(c)
                if k:
                    shift = 65 <= c <= 90           # capital letter = Shift held
                    self._press(k, now, shift=shift)
            i += 1
        self.buf = b[i:]

    def _csi(self, params, final, now):
        if params.startswith("?"):
            if final == "u":                       # kitty protocol supported
                if not self.kitty:
                    self.kitty = True
                    self.down.clear()
                    self._send("\x1b[>11u")      # disambiguate | event types | all keys
            return                                 # DA reply etc.
        if params.startswith((">", "=", "<")):
            return
        fields = params.split(";")
        # "code[:alt];mods[:event];text"
        try:
            code = int(fields[0].split(":")[0]) if fields[0] else 1
        except ValueError:
            code = 1
        mods, event = 1, 1
        if len(fields) > 1 and fields[1]:
            mp = fields[1].split(":")
            try:
                mods = int(mp[0]) if mp[0] else 1
                event = int(mp[1]) if len(mp) > 1 and mp[1] else 1
            except ValueError:
                pass
        shift = bool((mods - 1) & 1)
        ctrl = bool((mods - 1) & 4)
        if final == "u":
            key = _name(code)
            if key == "c" and ctrl:
                key = "ctrl-c"
        elif final == "~":
            key = TILDE.get(code)
        else:
            key = CSI_FINAL.get(final)
        if not key:
            return
        if event == 3:
            self._release(key)
        elif event == 2:
            self._repeat(key, now, shift)
        else:
            self._press(key, now, shift=shift)

    # ------------------------------------------------ key state
    def _press(self, key, now, shift=False):
        self.presses.append((key, shift))
        act = ACTIONS.get(key)
        if self.kitty:
            self.down[key] = float("inf")
            return
        if shift and act in ("left", "right"):
            self.mods_shift = now + FIRST_HOLD
        if act == "left":
            self.down.pop("right", None)
            self.down.pop("d", None)
        elif act == "right":
            self.down.pop("left", None)
            self.down.pop("a", None)
        if act == "jump":
            hold = JUMP_HOLD
            prev = self.last_press.get(key)
            # a quick second tap (too slow for auto-repeat, too soon for the
            # hold to end) still has to count as a new press: let go briefly
            if prev is not None and self.down.get(key, 0) > now and 0.06 < now - prev < 0.24:
                self.retap = True
            self.last_press[key] = now
        elif act == "throw":
            hold = THROW_HOLD
        else:
            # a press soon after the last one is the keyboard's auto-repeat:
            # it only extends the hold a little; a fresh press holds longer
            prev = self.last_press.get(key)
            hold = REPEAT_HOLD if prev is not None and now - prev < REPEAT_WINDOW else FIRST_HOLD
            self.last_press[key] = now
        self.down[key] = max(self.down.get(key, 0) if hold != REPEAT_HOLD else 0, now + hold)

    def _repeat(self, key, now, shift):
        if self.kitty:
            self.down[key] = float("inf")
        else:
            self._press(key, now, shift)

    def _release(self, key):
        self.down.pop(key, None)

    def stop(self):
        """Down arrow / S in legacy mode: stop walking now."""
        for k in ("left", "right", "a", "d"):
            self.down.pop(k, None)

    def take_presses(self):
        p, self.presses = self.presses, []
        return p

    def state(self, now=None):
        now = time.monotonic() if now is None else now
        st = {"left": False, "right": False, "jump": False, "sprint": False, "throw": False}
        for key, until in list(self.down.items()):
            if until <= now:
                del self.down[key]
                continue
            act = ACTIONS.get(key)
            if act:
                st[act] = True
        if not self.kitty and self.mods_shift > now:
            st["sprint"] = True
        if self.retap:
            self.retap = False
            st["jump"] = False
        return st
