"""Danny Go! Jump Adventure - game rules and state.

A faithful port of the browser game (games/dg.html). No drawing, no sound:
the graphics and terminal editions read this state and draw it, and turn
`events` into sounds. The world runs at a fixed 60 steps per second.
"""
import math
import random

TILE, COLS, ROWS = 40, 20, 13
VW, VH = COLS * TILE, ROWS * TILE          # 800 x 520
STEP = 1.0 / 60

# ---------------- physics (same numbers as the browser game)
GRAV, MAXFALL = 0.58, 15
ACC, FRIC = 0.42, 0.42
RUN_S, RUN_B = 3.3, 3.75
SPRINT_MULT = 1.55
JUMP_V, JUMP_CUT = -14.5, 0.42
STOMP_V = -10
COYOTE, BUFFER = 8, 8
ICE_ACC, ICE_FRIC = 0.35, 0.07                # Frozen Peak: much less grip, long slides
FLAP_V, GLIDE_MAX = -7.6, 2.4                 # wings: each jump press in the air flaps
KNOCK_VX, KNOCK_VY, KNOCK_T = 7.5, -7.5, 24   # the "power punch" when an enemy hits you
FIRE_V, FIRE_BOUNCE, FIRE_MAX = 6.5, -5.6, 3  # fire hat fireballs

# ---------------- tiles
SOLID = "=b?!uncWF"


def is_solid(ch):
    return ch in SOLID


def is_semi(ch):
    return ch == "-"


def is_hazard(ch):
    return ch == "^" or ch == "~"


TITLE, PLAY, CLEARED, DEAD, GAMEOVER, VICTORY = (
    "title", "play", "cleared", "dead", "gameover", "victory")


# ============================================================ levels

class Level:
    def __init__(self, name, theme, width):
        self.name, self.theme, self.width = name, theme, width
        self.grid = [[" "] * width for _ in range(ROWS)]
        self.movers = []
        self.start_pos = (2, 9)
        self.flag_pos = (width - 8, 10)
        self.checkpoints = []
        self.spawns = []
        self.has_boss = False
        self.boss_wall = None
        self.live = None
        self.flag_down = 0.0

    # --- builder API (mirrors buildLevel in the browser game)
    def set(self, c, r, ch):
        if 0 <= r < ROWS and 0 <= c < self.width:
            self.grid[r][c] = ch

    def ground(self, c0, c1, top):
        for c in range(c0, c1 + 1):
            for r in range(top, ROWS):
                self.set(c, r, "=")

    def plank(self, c0, c1, r):
        for c in range(c0, c1 + 1):
            self.set(c, r, "-")

    def cloud(self, c0, c1, r):
        for c in range(c0, c1 + 1):
            self.set(c, r, "c")

    def brick(self, c0, c1, r):
        for c in range(c0, c1 + 1):
            self.set(c, r, "b")

    def q(self, c, r):
        self.set(c, r, "?")

    def snack(self, c, r):
        self.set(c, r, "!")

    def wings(self, c, r):
        self.set(c, r, "W")

    def fire(self, c, r):
        self.set(c, r, "F")

    def stump(self, c, rtop):
        for r in range(rtop, ROWS):
            self.set(c, r, "n")
            self.set(c + 1, r, "n")

    def stars(self, c0, c1, r):
        for c in range(c0, c1 + 1):
            self.set(c, r, "o")

    def lava(self, c0, c1, top):
        for c in range(c0, c1 + 1):
            for r in range(top, ROWS):
                self.set(c, r, "^" if r == top else "~")

    def stairs(self, c0, steps, d, base):
        for i in range(steps):
            c = c0 + i if d > 0 else c0 - i
            for r in range(base - i, ROWS):
                self.set(c, r, "=")

    def blob(self, c, r):
        self.spawns.append(("blob", c, r))

    def fly(self, c, r):
        self.spawns.append(("fly", c, r))

    def boss(self, c, r):
        self.spawns.append(("iceking", c, r))
        self.has_boss = True

    def wall(self, c0, c1, r0, r1):
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                self.set(c, r, "=")
        self.boss_wall = (c0, c1, r0, r1)

    def mover(self, c, r, length, axis, dist, speed):
        self.movers.append(dict(x0=c * TILE, y0=r * TILE, x=c * TILE, y=r * TILE,
                                w=length * TILE, h=18, axis=axis, dist=dist * TILE,
                                speed=speed, phase=0.0, dx=0.0, dy=0.0))

    def start(self, c, r):
        self.start_pos = (c, r)

    def cp(self, c, r):
        self.checkpoints.append({"c": c, "r": r, "hit": False})

    def flag(self, c, r):
        self.flag_pos = (c, r)


def _sunny_hills():
    g = Level("Sunny Hills", "grass", 132)
    g.start(2, 9)
    g.ground(0, 22, 11)
    g.stars(6, 8, 10)
    g.blob(16, 10)
    g.brick(9, 9, 7); g.q(10, 7); g.snack(12, 7); g.wings(13, 7)
    g.stars(9, 13, 4)
    g.ground(26, 46, 11)
    g.blob(30, 10); g.blob(39, 10)
    g.stump(34, 9)
    g.plank(40, 44, 7); g.stars(40, 44, 6)
    g.ground(50, 74, 11)
    g.cp(52, 10)
    g.q(56, 7); g.brick(57, 57, 7); g.fire(58, 7); g.q(59, 7)
    g.blob(63, 10)
    g.fly(66, 5)
    g.cloud(68, 72, 7); g.stars(68, 72, 6)
    g.ground(78, 104, 11)
    g.blob(82, 10)
    g.brick(86, 86, 7); g.snack(87, 7); g.brick(88, 88, 7); g.stars(86, 88, 5)
    g.stump(92, 9)
    g.blob(96, 10)
    g.stairs(100, 4, 1, 10)
    g.ground(108, 131, 11)
    g.stars(110, 113, 10)
    g.blob(115, 10)
    g.flag(122, 10)
    return g


def _cloud_hopper():
    g = Level("Cloud Hopper", "sky", 138)
    g.start(2, 9)
    g.ground(0, 14, 11)
    g.stars(4, 6, 10)
    g.blob(10, 10)
    g.wings(8, 7); g.brick(9, 9, 7)
    g.plank(18, 22, 9); g.stars(18, 22, 8)
    g.cloud(26, 29, 8); g.fly(27, 5)
    g.plank(33, 37, 7); g.stars(33, 37, 6)
    g.ground(41, 58, 11)
    g.cp(43, 10)
    g.snack(46, 7); g.brick(47, 48, 7)
    g.blob(51, 10); g.blob(55, 10)
    g.mover(60, 9, 3, "h", 3, 1.0)
    g.cloud(67, 71, 9); g.stars(67, 71, 8)
    g.fly(74, 6)
    g.cloud(75, 78, 8); g.stars(75, 78, 7)
    g.mover(82, 9, 3, "v", 3, 1.0)
    g.ground(88, 112, 11)
    g.cp(90, 10)
    g.blob(99, 10)
    g.brick(102, 102, 7); g.q(103, 7); g.brick(104, 104, 7); g.stars(102, 104, 5)
    g.fly(107, 5)
    g.stairs(109, 4, 1, 10)
    g.ground(116, 137, 11)
    g.stars(118, 121, 10)
    g.blob(124, 10)
    g.flag(129, 10)
    return g


def _volcano_rumble():
    g = Level("Volcano Rumble", "volcano", 140)
    g.start(2, 9)
    g.ground(0, 16, 11)
    g.stars(5, 7, 10)
    g.blob(11, 10)
    g.q(9, 7); g.snack(13, 7)
    g.lava(17, 19, 12)
    g.ground(20, 38, 11)
    g.blob(25, 10); g.blob(32, 10)
    g.plank(27, 31, 7); g.stars(27, 31, 6)
    g.stump(35, 9)
    g.lava(39, 43, 12)
    g.mover(39, 9, 3, "h", 4, 1.4)
    g.ground(44, 62, 11)
    g.cp(46, 10)
    g.brick(50, 50, 7); g.q(51, 7); g.wings(52, 7); g.brick(53, 53, 7); g.stars(50, 53, 5)
    g.blob(57, 10)
    g.cp(60, 10)
    g.fly(61, 5)
    g.lava(63, 74, 12)
    g.cloud(64, 66, 9)
    g.cloud(69, 71, 8)
    g.stars(64, 66, 8); g.stars(69, 71, 7)
    g.cloud(73, 75, 8); g.stars(73, 75, 7)
    g.ground(78, 98, 11)
    g.blob(82, 10); g.blob(90, 10)
    g.fly(86, 5)
    g.snack(88, 7); g.brick(87, 87, 7); g.brick(89, 89, 7)
    g.stump(94, 9)
    g.lava(99, 101, 12)
    g.ground(102, 139, 11)
    g.stairs(106, 5, 1, 10)
    g.blob(114, 10)
    g.stars(116, 119, 10)
    g.stairs(124, 4, -1, 10)
    g.flag(131, 10)
    return g


def _frozen_peak():
    g = Level("Frozen Peak", "ice", 128)
    g.start(2, 9)
    g.ground(0, 20, 11)
    g.stars(4, 6, 10)
    g.blob(10, 10)
    g.brick(7, 7, 7); g.q(8, 7); g.snack(9, 7)
    g.plank(12, 16, 7); g.stars(12, 16, 6)
    g.ground(24, 46, 11)
    g.cp(26, 10)
    g.fly(30, 5)
    g.blob(36, 10)
    g.brick(40, 40, 7); g.fire(41, 7); g.stars(38, 43, 6)
    g.ground(50, 74, 11)
    g.cp(52, 10)
    g.mover(58, 9, 3, "h", 3, 1.0)
    g.blob(64, 10)
    g.stairs(68, 4, 1, 10)
    g.stars(70, 73, 9)
    g.ground(78, 100, 11)
    g.cp(80, 10)
    g.fly(85, 5)
    g.blob(90, 10)
    g.brick(92, 93, 7); g.snack(92, 7); g.q(93, 7)
    # boss arena, sealed by a wall of ice until the Ice King is beaten
    g.ground(101, 127, 11)
    g.cp(103, 10)
    g.boss(112, 9)
    g.wall(120, 121, 0, 10)
    g.flag(124, 10)
    return g


def make_levels():
    return [_sunny_hills(), _cloud_hopper(), _volcano_rumble(), _frozen_peak()]


# ============================================================ bodies

class Body:
    """Anything that moves: the player, enemies, items. Plain attributes."""

    def __init__(self, **kw):
        self.x = self.y = self.vx = self.vy = 0.0
        self.w = self.h = 0
        self.on_ground = False
        self.hit_wall = False
        self.bonk = None
        self.dead = 0
        self.face = -1
        self.__dict__.update(kw)


def overlap(a, b):
    return a.x < b.x + b.w and a.x + a.w > b.x and a.y < b.y + b.h and a.y + a.h > b.y


class Box:
    __slots__ = ("x", "y", "w", "h")

    def __init__(self, x, y, w, h):
        self.x, self.y, self.w, self.h = x, y, w, h


def floor(v):
    return math.floor(v)


# ============================================================ the game

class Game:
    def __init__(self, seed=None, music_on=True, rand=None):
        self.rng = random.Random(seed)
        self.rand = rand or self.rng.random
        self.levels = make_levels()
        self.events = []
        self.music_on = music_on
        self.quit = False
        self.confirm_quit = False
        self.state = TITLE
        self.li = 0
        self.level = self.levels[0]
        self.cam = 0.0
        self.tick = 0
        self.screen_t = 0
        self.shake = 0
        self.hearts = 3
        self.stars = 0
        self.total_stars = 0
        self.enemies, self.items, self.parts = [], [], []
        self.pops, self.bumps, self.movers, self.snowballs = [], [], [], []
        self.fireballs = []
        self.respawn = (0, 0)
        self.p = Body(w=26, h=34, big=False, face=1, run=0.0, coyote=0, buffer=0,
                      invuln=0, standing=None, dead=False, dead_t=0, dance_t=0,
                      throw_cd=0, boss_hp=5,
                      power=None, knock_t=0, flap_t=0, flapping=False)   # power: None|wings|fire
        # what the player is pressing right now (set by the front end)
        self.inp = {"left": False, "right": False, "jump": False,
                    "sprint": False, "throw": False}
        self.jump_prev = False
        self.load_level(0)
        self.state = TITLE

    # ------------------------------------------------ helpers
    def emit(self, kind, val=None):
        self.events.append((kind, val))

    def sfx(self, name):
        self.emit("sound", name)

    def pop_events(self):
        ev, self.events = self.events, []
        return ev

    @property
    def music_wanted(self):
        return self.music_on and self.state == PLAY and not self.confirm_quit

    def toggle_music(self):
        self.music_on = not self.music_on
        self.emit("music", self.music_on)

    def tile(self, c, r):
        if r < 0 or r >= ROWS or c < 0 or c >= self.level.width:
            return " "
        return self.level.live[r][c]

    def set_tile(self, c, r, ch):
        if 0 <= r < ROWS and 0 <= c < self.level.width:
            self.level.live[r][c] = ch

    def clamp_cam(self, x):
        return max(0, min(self.level.width * TILE - VW, x))

    def boss(self):
        for e in self.enemies:
            if e.type == "iceking":
                return e
        return None

    # ------------------------------------------------ loading
    def load_level(self, i, keep_stars=False):
        self.li = i
        lv = self.level = self.levels[i]
        lv.live = [row[:] for row in lv.grid]
        self.movers = [Body(**m) for m in lv.movers]
        self.enemies = [self.make_enemy(*s) for s in lv.spawns]
        self.items, self.parts, self.pops, self.bumps, self.snowballs = [], [], [], [], []
        self.fireballs = []
        if not keep_stars:
            self.stars = 0
        self.respawn = (lv.start_pos[0] * TILE, lv.start_pos[1] * TILE)
        for cp in lv.checkpoints:
            cp["hit"] = False
        lv.flag_down = 0.0
        self.reset_player(True)
        self.cam = self.clamp_cam(self.p.x - VW / 2)

    def reset_player(self, full):
        p = self.p
        p.x, p.y = self.respawn
        p.vx = p.vy = 0
        p.face = 1
        p.dead = False
        p.dead_t = p.dance_t = 0
        p.invuln = 0 if full else 90
        p.standing = None
        p.boss_hp = 5
        p.throw_cd = 0
        p.power = None
        p.knock_t = p.flap_t = 0
        p.flapping = False
        self.snowballs = []
        self.fireballs = []
        if full:
            p.big = False
            self.size_player()

    def size_player(self):
        p = self.p
        bottom = p.y + p.h
        p.w = 30 if p.big else 26
        p.h = 52 if p.big else 34
        p.y = bottom - p.h

    def make_enemy(self, kind, c, r):
        if kind == "fly":
            return Body(type="fly", x=c * TILE + 6, y=r * TILE + 6, w=28, h=24,
                        base_y=r * TILE + 6, vx=-1.05, t=self.rand() * 6, face=-1)
        if kind == "iceking":
            return Body(type="iceking", x=c * TILE, y=r * TILE, w=70, h=80,
                        base_x=c * TILE, range=90, phase=self.rand() * 6, face=-1,
                        hp=5, hit_flash=0, throw_cd=110)
        return Body(type="blob", x=c * TILE + 5, y=r * TILE + 6, w=30, h=28,
                    vx=-1.0, vy=0, face=-1, wob=self.rand() * 6)

    # ------------------------------------------------ collision
    def move_body(self, b, semi_ok):
        tile = self.tile
        b.x += b.vx
        b.hit_wall = False
        c0, c1 = floor(b.x / TILE), floor((b.x + b.w - 1) / TILE)
        r0, r1 = floor(b.y / TILE), floor((b.y + b.h - 1) / TILE)
        r = r0
        while r <= r1:
            c = c0
            while c <= c1:
                if is_solid(tile(c, r)):
                    if b.vx > 0:
                        b.x = c * TILE - b.w
                    elif b.vx < 0:
                        b.x = (c + 1) * TILE
                    b.vx = 0
                    b.hit_wall = True
                    c0, c1 = floor(b.x / TILE), floor((b.x + b.w - 1) / TILE)
                c += 1
            r += 1
        if b.x < 0:
            b.x, b.vx, b.hit_wall = 0, 0, True
        max_x = self.level.width * TILE - b.w
        if b.x > max_x:
            b.x, b.vx, b.hit_wall = max_x, 0, True

        prev_bottom = b.y + b.h
        b.on_ground = False
        b.bonk = None
        b.y += b.vy
        r0, r1 = floor(b.y / TILE), floor((b.y + b.h - 1) / TILE)
        c0, c1 = floor(b.x / TILE), floor((b.x + b.w - 1) / TILE)
        c = c0
        while c <= c1:
            r = r0
            while r <= r1:
                ch = tile(c, r)
                hit = is_solid(ch) or (semi_ok and is_semi(ch) and b.vy > 0
                                       and prev_bottom <= r * TILE + 3)
                if hit:
                    if b.vy > 0:
                        b.y = r * TILE - b.h
                        b.vy = 0
                        b.on_ground = True
                    elif b.vy < 0:
                        b.y = (r + 1) * TILE
                        b.vy = 0
                        b.bonk = (c, r)
                    r0, r1 = floor(b.y / TILE), floor((b.y + b.h - 1) / TILE)
                r += 1
            c += 1

    def touches_hazard(self, b):
        c0, c1 = floor((b.x + 4) / TILE), floor((b.x + b.w - 5) / TILE)
        r0, r1 = floor((b.y + 4) / TILE), floor((b.y + b.h - 3) / TILE)
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                if is_hazard(self.tile(c, r)):
                    return True
        return False

    # ------------------------------------------------ effects
    def puff(self, x, y, color, n, spread=4):
        R = self.rand
        for _ in range(n):
            self.parts.append([x, y, (R() - .5) * spread, -R() * 4 - 1,
                               26 + R() * 16, 2 + R() * 4, color])

    def pop(self, x, y, text):
        self.pops.append([x, y, text, 50])

    # ------------------------------------------------ keys from the front ends
    def key(self, name):
        """Menu keys. Movement goes through self.inp."""
        if name is None:
            return
        if self.confirm_quit:
            if name in ("y", "enter"):
                self.quit = True
            elif name in ("n", "esc", "x", "space"):
                self.confirm_quit = False
                self.emit("music", self.music_on)
            return
        if name == "esc":
            self.confirm_quit = True
            return
        if name in ("m", "1"):
            self.toggle_music()
            return
        if self.state in (TITLE, GAMEOVER, VICTORY):
            self.advance()

    def advance(self):
        if self.screen_t <= 20:
            return
        if self.state == TITLE or self.state == VICTORY:
            self.total_stars = 0
            self.hearts = 3
            self.load_level(0)
        else:
            self.hearts = 3
            self.load_level(self.li)
        self.state = PLAY
        self.screen_t = 0
        self.emit("start")

    # ------------------------------------------------ one 1/60 s step
    def step(self):
        if self.confirm_quit:
            return
        inp = self.inp
        self.tick += 1
        if self.shake > 0:
            self.shake -= 1

        if self.state in (TITLE, GAMEOVER, VICTORY):
            self.screen_t += 1
            if inp["jump"] and not self.jump_prev:
                self.advance()
            if self.state == VICTORY and self.tick % 5 == 0:
                R = self.rand
                self.parts.append([self.cam + R() * VW, -10, (R() - .5) * 2, 1 + R() * 2,
                                   80, 3 + R() * 4,
                                   ("#ffd23f", "#ff5fa2", "#4be3a0", "#41a3ff")[floor(R() * 4)]])
            if self.state == VICTORY:
                self.update_particles()
            self.jump_prev = inp["jump"]
            return

        if self.state == CLEARED:
            self.screen_t += 1
            lv = self.level
            lv.flag_down = min(1.0, lv.flag_down + 0.03)
            self.p.dance_t += 1
            self.update_particles()
            if self.screen_t > 150:
                self.total_stars += self.stars
                if self.li + 1 < len(self.levels):
                    self.load_level(self.li + 1)
                    self.state = PLAY
                    self.screen_t = 0
                else:
                    self.state = VICTORY
                    self.screen_t = 0
            self.jump_prev = inp["jump"]
            return

        if self.state == DEAD:
            p = self.p
            p.dead_t += 1
            p.vy = min(MAXFALL, p.vy + GRAV)
            p.y += p.vy
            p.x += p.vx                 # knocked flying by the punch
            self.update_particles()
            if p.dead_t > 70:
                if self.hearts <= 0:
                    self.state = GAMEOVER
                    self.screen_t = 0
                    self.sfx("over")
                else:
                    self.reset_player(False)
                    self.state = PLAY
                    self.cam = self.clamp_cam(p.x - VW / 2)
            self.jump_prev = inp["jump"]
            return

        self.update_player()
        self.p.run += abs(self.p.vx) * 0.25        # drives the running animation
        self.update_movers()
        self.update_enemies()
        self.update_snowballs()
        self.update_fireballs()
        self.update_items()
        self.update_particles()

        p = self.p
        want = p.x + p.w / 2 - VW / 2 + p.face * 60
        self.cam += (self.clamp_cam(want) - self.cam) * 0.11
        self.cam = self.clamp_cam(self.cam)
        self.jump_prev = inp["jump"]

    # ------------------------------------------------ player
    def update_player(self):
        p, inp, lv = self.p, self.inp, self.level
        if p.invuln > 0:
            p.invuln -= 1
        if p.throw_cd > 0:
            p.throw_cd -= 1
        if inp["throw"] and p.throw_cd <= 0:
            if p.power == "fire":
                if len(self.fireballs) < FIRE_MAX:
                    self.throw_fireball()
                    p.throw_cd = 14
            elif lv.has_boss:
                self.throw_player_snowball()
                p.throw_cd = 20

        if p.standing is not None:
            p.x += p.standing.dx
            p.y += p.standing.dy
        p.standing = None

        slick = lv.theme == "ice"
        sprinting = inp["sprint"]
        acc = (ACC * 1.3 if sprinting else ACC) * (ICE_ACC if slick else 1)
        fric = FRIC * ICE_FRIC if slick else FRIC
        max_run = (RUN_B if p.big else RUN_S) * (SPRINT_MULT if sprinting else 1)
        if p.knock_t > 0:
            # reeling from a hit: no steering for a moment, just slow down
            p.knock_t -= 1
            p.vx *= (0.97 if slick else 0.86) if p.on_ground else 0.985
        else:
            if inp["left"] and not inp["right"]:
                p.vx -= acc
                p.face = -1
            elif inp["right"] and not inp["left"]:
                p.vx += acc
                p.face = 1
            else:
                if p.vx > fric:
                    p.vx -= fric
                elif p.vx < -fric:
                    p.vx += fric
                else:
                    p.vx = 0
            p.vx = max(-max_run, min(max_run, p.vx))
        # ice spray while skidding
        if (slick and p.on_ground and abs(p.vx) > 1.5 and self.tick % 4 == 0
                and not (inp["right"] and p.vx > 0) and not (inp["left"] and p.vx < 0)):
            self.puff(p.x + p.w / 2, p.y + p.h - 2, "#ffffff", 2, 2)

        if inp["jump"] and not self.jump_prev:
            p.buffer = BUFFER
        if p.buffer > 0:
            p.buffer -= 1
        if p.coyote > 0:
            p.coyote -= 1
        if p.buffer > 0 and p.coyote > 0:
            p.vy = JUMP_V
            p.buffer = p.coyote = 0
            p.on_ground = False
            p.flapping = False
            self.sfx("jump")
        elif (p.power == "wings" and inp["jump"] and not self.jump_prev and p.coyote <= 0
              and p.knock_t <= 0):
            # wings: every jump press in the air is another flap
            p.vy = min(p.vy, FLAP_V)
            p.buffer = 0
            p.flapping = True
            p.flap_t = 14
            self.sfx("flap")
            self.puff(p.x + p.w / 2, p.y + p.h * 0.45, "#ffffff", 3, 3)
        if p.flap_t > 0:
            p.flap_t -= 1
        if p.vy >= 0:
            p.flapping = False
        if not inp["jump"] and p.vy < -4 and not p.flapping and p.knock_t <= 0:
            p.vy *= JUMP_CUT

        p.vy = min(MAXFALL, p.vy + GRAV)
        if p.power == "wings" and inp["jump"] and p.vy > GLIDE_MAX:
            p.vy = GLIDE_MAX                       # hold jump to glide
        self.move_body(p, True)
        if p.on_ground:
            p.coyote = COYOTE
        if p.bonk:
            self.hit_block(*p.bonk)

        for m in self.movers:
            if overlap(p, m):
                from_top = (p.y + p.h) - m.y
                if p.vy >= 0 and from_top < 22:
                    p.y = m.y - p.h
                    p.vy = 0
                    p.on_ground = True
                    p.coyote = COYOTE
                    p.standing = m

        c0, c1 = floor(p.x / TILE), floor((p.x + p.w - 1) / TILE)
        r0, r1 = floor(p.y / TILE), floor((p.y + p.h - 1) / TILE)
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                if self.tile(c, r) == "o":
                    self.set_tile(c, r, " ")
                    self.stars += 1
                    self.sfx("star")
                    self.puff(c * TILE + 20, r * TILE + 20, "#ffd23f", 7, 4)

        for cp in lv.checkpoints:
            if not cp["hit"] and abs(p.x - cp["c"] * TILE) < 40 and abs(p.y - cp["r"] * TILE) < 90:
                cp["hit"] = True
                self.respawn = (cp["c"] * TILE, (cp["r"] - 1) * TILE)
                self.sfx("cp")
                self.pop(cp["c"] * TILE, cp["r"] * TILE - 10, "CHECKPOINT!")
                self.puff(cp["c"] * TILE + 20, cp["r"] * TILE + 10, "#4be3a0", 14, 5)

        fc, fr = lv.flag_pos
        if self.state == PLAY and p.x + p.w > fc * TILE + 6 and p.y < (fr + 1) * TILE:
            self.state = CLEARED
            self.screen_t = 0
            self.sfx("win")
            p.vx = p.vy = 0
            self.puff(fc * TILE + 20, fr * TILE, "#ffd23f", 26, 7)

        if self.touches_hazard(p) or p.y > VH + 200:
            self.die()

    def hit_block(self, c, r):
        ch = self.tile(c, r)
        if ch in "?!WF":
            self.set_tile(c, r, "u")
            self.bumps.append([c, r, 14])
            if ch == "?":
                self.stars += 1
                self.sfx("star")
                self.pop(c * TILE, r * TILE - 6, "+1")
                self.puff(c * TILE + 20, r * TILE - 4, "#ffd23f", 9, 4)
            else:
                kind = {"!": "snack", "W": "wings", "F": "fire"}[ch]
                self.items.append(Body(type=kind, x=c * TILE + 6, y=r * TILE - 28,
                                       w=28, h=28, vx=0 if kind == "fire" else 1.3,
                                       vy=-3, born=0))
                self.sfx("grow")
        elif ch == "b":
            if self.p.big:
                self.set_tile(c, r, " ")
                self.sfx("brk")
                self.shake = 8
                self.puff(c * TILE + 20, r * TILE + 20, "brick", 14, 6)
            else:
                self.sfx("bonk")
                self.bumps.append([c, r, 12])
        elif is_solid(ch):
            self.sfx("bonk")

    def update_movers(self):
        for m in self.movers:
            px, py = m.x, m.y
            m.phase += 0.018 * m.speed
            off = math.sin(m.phase) * m.dist
            m.x = m.x0 + off if m.axis == "h" else m.x0
            m.y = m.y0 + off if m.axis == "v" else m.y0
            m.dx = m.x - px
            m.dy = m.y - py

    def update_enemies(self):
        p = self.p
        i = len(self.enemies) - 1
        while i >= 0:
            e = self.enemies[i]
            i -= 1
            if e.dead:
                e.dead += 1
                if e.dead > 26:
                    self.enemies.remove(e)
                continue
            if e.x < self.cam - 200 or e.x > self.cam + VW + 300:
                continue

            if e.type == "blob":
                e.wob += 0.15
                e.vy = min(MAXFALL, e.vy + GRAV)
                self.move_body(e, False)
                if e.hit_wall:
                    e.vx = -e.vx
                if e.on_ground:
                    ahead = floor((e.x + (e.w + 4 if e.vx > 0 else -4)) / TILE)
                    below = floor((e.y + e.h + 6) / TILE)
                    t = self.tile(ahead, below)
                    if not is_solid(t) and not is_semi(t):
                        e.vx = -e.vx
                e.face = 1 if e.vx > 0 else -1
                if self.touches_hazard(e) or e.y > VH + 200:
                    self.enemies.remove(e)
                    continue
            elif e.type == "fly":
                e.t += 0.06
                e.x += e.vx
                e.y = e.base_y + math.sin(e.t) * 46
                e.face = 1 if e.vx > 0 else -1
                c = floor((e.x + (e.w if e.vx > 0 else 0)) / TILE)
                r = floor((e.y + e.h / 2) / TILE)
                if is_solid(self.tile(c, r)) or e.x < 0 or e.x > self.level.width * TILE - e.w:
                    e.vx = -e.vx
            elif e.type == "iceking":
                e.phase += 0.02
                e.x = e.base_x + math.sin(e.phase) * e.range
                e.face = -1 if p.x < e.x else 1
                if e.hit_flash > 0:
                    e.hit_flash -= 1
                e.throw_cd -= 1
                if e.throw_cd <= 0:
                    self.throw_boss_snowball(e)
                    e.throw_cd = 95 + self.rand() * 45

            if e.type != "iceking" and not p.dead and self.state == PLAY and overlap(p, e):
                stomping = p.vy > 1 and (p.y + p.h) - e.y < 24
                if stomping:
                    e.dead = 1
                    p.vy = STOMP_V
                    p.coyote = 0
                    self.sfx("stomp")
                    self.shake = 5
                    self.stars += 1
                    self.pop(e.x, e.y - 8, "+1")
                    self.puff(e.x + e.w / 2, e.y + e.h / 2,
                              "#ff9d4d" if e.type == "fly" else "#a06bff", 12, 5)
                elif p.invuln <= 0:
                    self.hurt(e.x + e.w / 2)

    # ------------------------------------------------ snowballs
    def throw_player_snowball(self):
        p = self.p
        self.snowballs.append(Body(owner="player", r=8,
                                   x=p.x + (p.w + 4 if p.face > 0 else -12),
                                   y=p.y + p.h * 0.4, vx=8 * p.face, vy=0, g=0))
        self.sfx("throw")

    def throw_boss_snowball(self, e):
        p = self.p
        x, y = e.x + e.w / 2, e.y + e.h * 0.25
        tx, ty = p.x + p.w / 2, p.y + p.h / 2
        dx = tx - x
        t = max(30, min(70, abs(dx) / 5.2))
        g = 0.3
        self.snowballs.append(Body(owner="boss", r=10, x=x, y=y, vx=dx / t,
                                   vy=((ty - y) - 0.5 * g * t * t) / t, g=g))
        self.sfx("bossthrow")

    def update_snowballs(self):
        p = self.p
        for s in list(reversed(self.snowballs)):
            s.vy += s.g
            s.x += s.vx
            s.y += s.vy
            c, r = floor(s.x / TILE), floor(s.y / TILE)
            if (is_solid(self.tile(c, r)) or s.y > VH + 100 or s.x < self.cam - 100
                    or s.x > self.cam + VW + 100):
                self.puff(s.x, s.y, "#ffffff", 6, 3)
                self.snowballs.remove(s)
                continue
            box = Box(s.x - s.r, s.y - s.r, s.r * 2, s.r * 2)
            if s.owner == "player":
                boss = next((e for e in self.enemies if e.type == "iceking" and not e.dead), None)
                if boss and overlap(box, boss):
                    boss.hp -= 1
                    boss.hit_flash = 12
                    self.shake = 4
                    self.sfx("stomp")
                    self.puff(boss.x + boss.w / 2, boss.y + boss.h / 2, "#eaffff", 10, 5)
                    self.snowballs.remove(s)
                    if boss.hp <= 0:
                        self.defeat_boss(boss)
            elif (self.state == PLAY and not p.dead and p.invuln <= 0 and overlap(box, p)):
                self.snowballs.remove(s)
                self.boss_hit_player(1 if s.vx >= 0 else -1)

    def boss_hit_player(self, direction):
        p = self.p
        p.invuln = 80
        self.shake = 8
        self.sfx("hurt")
        self.puff(p.x + p.w / 2, p.y + p.h / 2, "#bfe9ff", 12, 5)
        p.boss_hp = max(0, p.boss_hp - 1)
        self.pop(p.x, p.y - 10, "-1")
        if p.boss_hp <= 0:
            self.die(direction)
        else:
            self.knock_back(direction)

    def defeat_boss(self, e):
        e.dead = 1
        self.sfx("win")
        self.shake = 14
        self.pop(e.x + e.w / 2, e.y - 12, "BOSS DEFEATED!")
        self.puff(e.x + e.w / 2, e.y + e.h / 2, "#ffffff", 26, 7)
        w = self.level.boss_wall
        if w:
            c0, c1, r0, r1 = w
            for c in range(c0, c1 + 1):
                for r in range(r0, r1 + 1):
                    self.set_tile(c, r, " ")

    # ------------------------------------------------ items & effects
    def update_items(self):
        p = self.p
        for it in list(reversed(self.items)):
            it.born += 1
            if it.born < 22:
                it.y -= 1.3
            else:
                it.vy = min(1.2 if it.type == "wings" else MAXFALL, it.vy + GRAV)
                self.move_body(it, False)
                if it.hit_wall:
                    it.vx = -it.vx
            if it.y > VH + 200:
                self.items.remove(it)
                continue
            if self.state == PLAY and overlap(p, it):
                self.items.remove(it)
                if not p.big:
                    p.big = True
                    self.size_player()
                self.stars += 3
                if it.type in ("wings", "fire"):
                    p.power = it.type
                self.sfx("grow")
                self.pop(p.x, p.y - 10, {"wings": "WINGS! JUMP IN THE AIR TO FLY",
                                         "fire": "FIRE HAT! PRESS X FOR FIREBALLS"}
                         .get(it.type, "POWER UP!"))
                self.puff(p.x + p.w / 2, p.y + p.h / 2,
                          {"wings": "#bfe9ff", "fire": "#ff9d4d"}.get(it.type, "#ff5fa2"), 18, 6)

    def update_particles(self):
        keep = []
        for q in self.parts:
            q[0] += q[2]
            q[1] += q[3]
            q[3] += 0.22
            q[4] -= 1
            if q[4] > 0:
                keep.append(q)
        self.parts = keep
        for s in self.pops:
            s[1] -= 0.7
            s[3] -= 1
        self.pops = [s for s in self.pops if s[3] > 0]
        for b in self.bumps:
            b[2] -= 1
        self.bumps = [b for b in self.bumps if b[2] > 0]

    def hurt(self, from_x=None):
        """from_x: where the hit came from, so Danny flies away from it"""
        p = self.p
        if from_x is None:
            d = -p.face
        else:
            d = -1 if p.x + p.w / 2 < from_x else 1
        if p.power:
            # a power-up soaks up the hit (Danny stays big)
            p.power = None
            p.invuln = 100
            self.sfx("hurt")
            self.knock_back(d)
        elif p.big:
            p.big = False
            self.size_player()
            p.invuln = 100
            self.sfx("hurt")
            self.shake = 8
            self.puff(p.x + p.w / 2, p.y + p.h / 2, "#ffffff", 14, 6)
            self.knock_back(d)
        else:
            self.die(d)

    def knock_back(self, d):
        """The enemy "power-punches" Danny: up and away, no steering for a moment."""
        p = self.p
        p.vx = d * KNOCK_VX
        p.vy = KNOCK_VY
        p.knock_t = KNOCK_T
        p.on_ground = False
        p.coyote = p.buffer = 0
        p.standing = None
        p.flapping = False
        self.shake = 12
        self.sfx("punch")
        self.punch_fx(d)

    def punch_fx(self, d):
        p = self.p
        hx, hy = p.x + p.w / 2 - d * p.w * 0.6, p.y + p.h * 0.45
        self.puff(hx, hy, "#ffd23f", 10, 7)
        self.puff(hx, hy, "#ffffff", 6, 5)
        self.pop(hx, p.y - 26, "POW!")

    def die(self, d=0):
        if self.state != PLAY:
            return
        self.hearts -= 1
        self.state = DEAD
        p = self.p
        p.dead = True
        p.dead_t = 0
        p.vy = -9
        p.vx = d * 4.5 if d else 0
        p.power = None
        p.knock_t = 0
        self.sfx("hurt")
        self.shake = 10
        if d:
            self.sfx("punch")
            self.punch_fx(d)
        self.puff(p.x + p.w / 2, p.y + p.h / 2, "#ffffff", 16, 6)

    # ------------------------------------------------ fireballs
    def throw_fireball(self):
        p = self.p
        self.fireballs.append(Body(x=p.x + (p.w + 2 if p.face > 0 else -2), y=p.y + p.h * 0.45,
                                   vx=FIRE_V * p.face, vy=1.5, r=7, life=160, spin=0.0))
        self.sfx("fire")

    def update_fireballs(self):
        tile = self.tile
        for f in list(reversed(self.fireballs)):
            f.life -= 1
            f.spin += 0.35
            f.vy = min(9, f.vy + 0.5)
            f.x += f.vx
            sign = (f.vx > 0) - (f.vx < 0)
            burst = is_solid(tile(floor((f.x + sign * f.r) / TILE), floor(f.y / TILE)))
            f.y += f.vy
            if not burst:
                c = floor(f.x / TILE)
                if f.vy > 0:
                    r = floor((f.y + f.r) / TILE)
                    t = tile(c, r)
                    if is_solid(t) or is_semi(t):
                        f.y = r * TILE - f.r
                        f.vy = FIRE_BOUNCE
                elif is_solid(tile(c, floor((f.y - f.r) / TILE))):
                    f.vy = 1
            if (burst or f.life <= 0 or f.y > VH + 50 or f.x < self.cam - 60
                    or f.x > self.cam + VW + 60):
                if burst:
                    self.puff(f.x, f.y, "#ff9d4d", 6, 3)
                self.fireballs.remove(f)
                continue
            box = Box(f.x - f.r, f.y - f.r, f.r * 2, f.r * 2)
            for e in self.enemies:
                if e.dead or not overlap(box, e):
                    continue
                if e.type == "iceking":
                    e.hp -= 1
                    e.hit_flash = 12
                    self.shake = 4
                    self.sfx("stomp")
                    self.puff(e.x + e.w / 2, e.y + e.h / 2, "#ff9d4d", 10, 5)
                    if e.hp <= 0:
                        self.defeat_boss(e)
                else:
                    e.dead = 1
                    self.stars += 1
                    self.sfx("stomp")
                    self.pop(e.x, e.y - 8, "+1")
                    self.puff(e.x + e.w / 2, e.y + e.h / 2, "#ff9d4d", 12, 5)
                self.fireballs.remove(f)
                break

    # ------------------------------------------------ for drawing
    def player_anim(self):
        p = self.p
        if self.state == CLEARED:
            return "dance"
        # on flat ground on_ground flickers every other step (as in the web
        # game); a fresh coyote counter means we were just standing
        if self.state == DEAD or not (p.on_ground or p.coyote >= COYOTE - 1):
            return "jump"
        if abs(p.vx) > 0.4:
            return "run"
        return "idle"

    def wing_lift(self):
        """Angle of Danny's wings (radians, tip up), or None without wings."""
        p = self.p
        if p.power != "wings":
            return None
        if p.flap_t > 0:
            return 0.35 + math.sin((14 - p.flap_t) / 14 * math.pi * 2 + math.pi / 2) * 0.6
        if p.on_ground or p.coyote >= COYOTE - 1:
            return 0.15 + math.sin(self.tick * 0.06) * 0.08
        if self.inp["jump"] and p.vy > 0:
            return 0.8
        return 0.4 + math.sin(self.tick * 0.2) * 0.1

    def player_visible(self):
        p = self.p
        return not (p.invuln > 0 and (self.tick // 4) % 2 == 0 and self.state == PLAY)


# ============================================================ autopilot

class Bot:
    """Plays the game for smoke tests and demos: runs right, jumps over
    gaps, walls and enemies, throws snowballs at the boss."""

    def __init__(self, game):
        self.g = game
        self.hold = 0
        self.sprint = 0

    def inputs(self):
        g, p = self.g, self.g.p
        inp = {"left": False, "right": True, "jump": False, "sprint": False, "throw": False}
        if g.state in (TITLE, GAMEOVER, VICTORY):
            inp["right"] = False
            inp["jump"] = g.tick % 30 < 15
            return inp
        if g.state != PLAY:
            return inp
        if self.sprint > 0:
            self.sprint -= 1
            inp["sprint"] = True
        if self.hold > 0:
            self.hold -= 1
            inp["jump"] = True
            return inp
        boss = g.boss()
        if boss and not boss.dead and boss.x - p.x < 500:
            inp["throw"] = g.tick % 24 == 0
            inp["right"] = boss.x - p.x > 260
            inp["left"] = boss.x - p.x < 180
        if p.power == "fire":
            for e in g.enemies:
                if not e.dead and 0 < (e.x - p.x) * p.face < 320 and abs(e.y - p.y) < 80:
                    inp["throw"] = g.tick % 16 == 0
        c = floor((p.x + p.w / 2) / TILE)
        if not p.on_ground:
            # air brake: come down on the last bit of ground before a pit
            def pit(col):
                ts = [g.tile(col, r) for r in range(max(0, floor(p.y / TILE)), ROWS)]
                return not any(is_solid(t) or is_semi(t) for t in ts) or any(map(is_hazard, ts))
            if p.vy > 0 and self.sprint == 0 and not pit(c) and pit(c + 1):
                inp["right"] = False
            if p.power == "wings" and p.vy > 1 and pit(c):
                inp["jump"] = g.tick % 12 < 4          # flap over the gap
            return inp
        front = floor((p.x + p.w + 6) / TILE)
        foot = floor((p.y + p.h + 2) / TILE)
        mid = floor((p.y + p.h - 4) / TILE)
        danger = 0
        t_floor = g.tile(front, foot)
        if not (is_solid(t_floor) or is_semi(t_floor)):
            # a pit (nothing below, or lava) rather than a step down?
            below = [g.tile(front, r) for r in range(foot, ROWS)]
            if not any(is_solid(t) or is_semi(t) for t in below) or any(map(is_hazard, below)):
                danger = 22
            else:
                # a step down with a pit right after it: leap over both
                for dc in (1, 2):
                    col = [g.tile(front + dc, r) for r in range(foot, ROWS)]
                    if not any(is_solid(t) for t in col) or any(map(is_hazard, col)):
                        danger = 22
                        self.sprint = 40
        for dc in (1, 2):
            if is_solid(g.tile(c + dc, mid)) or is_solid(g.tile(c + dc, mid - 1)):
                danger = max(danger, 22 if is_solid(g.tile(c + dc, mid - 2)) else 9)
        for e in g.enemies:
            if not e.dead and e.type != "iceking" and 0 < e.x - p.x < 110 and abs(e.y - p.y) < 90:
                danger = 22
        for m in g.movers:
            if abs(m.x - p.x) < 200 and not is_solid(g.tile(c + 1, foot)):
                # wait for the moving platform to come close
                if abs((m.x + m.w / 2) - (p.x + p.w / 2)) > 150 and m.axis == "h":
                    inp["right"] = False
                    return inp
        if danger:
            self.hold = danger
            inp["jump"] = True
        return inp
