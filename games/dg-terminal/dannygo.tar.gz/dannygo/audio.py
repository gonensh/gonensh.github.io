"""Sound for Danny Go! Jump Adventure: the browser game's chiptune music and
effects, synthesized into WAV data at start-up (no sound files needed).

The terminal edition plays them with pw-play / paplay / aplay; the graphics
edition plays the same data through pygame's mixer. Everything is optional:
with no player the game is silent. Nothing here may crash the game.
"""
import math
import os
import shutil
import struct
import subprocess
import tempfile
import threading
import wave

RATE = 22050

# (freq, start s, dur s, wave, volume, slide-to freq) - copied from the web game
SFX = {
    "jump": [(420, 0, 0.14, "square", 0.12, 760)],
    "star": [(1050, 0, 0.07, "square", 0.11, 0), (1570, 0.06, 0.11, "square", 0.11, 0)],
    "stomp": [(300, 0, 0.10, "sawtooth", 0.12, 90)],
    "bonk": [(160, 0, 0.08, "square", 0.10, 100)],
    "brk": [(240, 0, 0.14, "sawtooth", 0.11, 70)],
    "throw": [(900, 0, 0.07, "triangle", 0.10, 600)],
    "bossthrow": [(220, 0, 0.16, "sawtooth", 0.12, 140)],
}


def _seq(notes, gap):
    return [(f, i * gap, d, "square", 0.14, 0) for i, (f, d) in enumerate(notes)]


SFX["grow"] = _seq([(523, .12), (659, .12), (784, .12), (1046, .12)], 0.06)
SFX["hurt"] = _seq([(440, .12), (330, .12), (220, .12)], 0.08)
SFX["cp"] = _seq([(784, .12), (1046, .12)], 0.09)
SFX["win"] = _seq([(523, .12), (659, .12), (784, .12), (1046, .12), (784, .12),
                   (1046, .12), (1318, .4)], 0.12)
SFX["over"] = _seq([(392, .12), (330, .12), (262, .12), (196, .4)], 0.16)

MEL = [523, 0, 659, 0, 784, 0, 659, 0, 587, 0, 698, 0, 880, 0, 698, 0,
       523, 0, 659, 0, 784, 0, 1046, 0, 880, 0, 784, 0, 659, 0, 587, 0]
BASS = [131, 0, 0, 0, 131, 0, 0, 0, 147, 0, 0, 0, 147, 0, 0, 0,
        131, 0, 0, 0, 131, 0, 0, 0, 165, 0, 0, 0, 196, 0, 0, 0]
MUSIC_STEP = 0.132
LOOP_REPEATS = 4            # ~17 s per music file for the external players
VOLUME = 3.0                # the browser's levels are quiet; lift them a bit

PLAYERS = [("pw-play", []), ("paplay", []), ("aplay", ["-q"])]


# ------------------------------------------------------------ synthesis

def _add_tone(buf, freq, start, dur, kind, vol, slide=0):
    """Like the web game's tone(): instant attack, exponential fade to
    0.0008 over `dur`, optional exponential pitch slide."""
    i0 = int(start * RATE)
    n = int((dur + 0.02) * RATE)
    if len(buf) < i0 + n:
        buf.extend([0.0] * (i0 + n - len(buf)))
    nd = max(1, int(dur * RATE))
    fall = (0.0008 / vol) ** (1.0 / nd) if vol > 0 else 0
    fmul = (slide / freq) ** (1.0 / nd) if slide else 1.0
    env = vol * VOLUME
    f = freq
    ph = 0.0
    sin, two_pi = math.sin, 2 * math.pi
    for j in range(n):
        ph += f / RATE
        if ph >= 1.0:
            ph -= int(ph)
        if kind == "square":
            s = 1.0 if ph < 0.5 else -1.0
        elif kind == "triangle":
            s = 4.0 * abs(ph - 0.5) - 1.0
        elif kind == "sawtooth":
            s = 2.0 * ph - 1.0
        else:
            s = sin(two_pi * ph)
        buf[i0 + j] += s * env
        if j < nd:
            env *= fall
            f *= fmul


def _to_bytes(buf):
    ints = [int(32767 * (1.0 if v > 1 else (-1.0 if v < -1 else v))) for v in buf]
    return struct.pack("<%dh" % len(ints), *ints)


def write_wav(path, frames):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(frames)


def render_sfx(name):
    buf = []
    for f, start, dur, kind, vol, slide in SFX[name]:
        _add_tone(buf, f, start, dur, kind, vol, slide)
    return _to_bytes(buf)


def render_music(repeats=1):
    n = int(round(len(MEL) * MUSIC_STEP * RATE))
    buf = [0.0] * n
    for i, (m, b) in enumerate(zip(MEL, BASS)):
        if m:
            _add_tone(buf, m, i * MUSIC_STEP, 0.1, "square", 0.045)
        if b:
            _add_tone(buf, b, i * MUSIC_STEP, 0.16, "triangle", 0.07)
    # wrap the tail of the last note back to the start so the loop is seamless
    for i in range(n, len(buf)):
        buf[i - n] += buf[i]
    return _to_bytes(buf[:n]) * repeats


# ------------------------------------------------------------ audio engine

class Audio:
    """Plays sounds with an external command-line player (terminal edition)."""

    def __init__(self, music_on=True, enabled=True):
        self.music_on = music_on
        self.player = None
        self.files = {}
        self.procs = []
        self.music_proc = None
        self.tmp = None
        self._closed = False
        if not enabled:
            return
        for name, extra in PLAYERS:
            path = shutil.which(name)
            if path:
                self.player = [path] + extra
                break
        if self.player:
            self.tmp = tempfile.mkdtemp(prefix="dannygo-audio-")
            threading.Thread(target=self._synth, daemon=True).start()

    def _synth(self):
        try:
            path = os.path.join(self.tmp, "music.wav")
            write_wav(path, render_music(LOOP_REPEATS))
            self.files["music"] = path
            for name in SFX:
                if self._closed:
                    return
                path = os.path.join(self.tmp, name + ".wav")
                write_wav(path, render_sfx(name))
                self.files[name] = path
        except Exception:
            pass

    def _spawn(self, cmd):
        try:
            p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            return None
        self.procs.append(p)
        return p

    @staticmethod
    def _kill(p):
        if p is None:
            return
        try:
            if p.poll() is None:
                p.kill()
            p.wait(timeout=0.5)
        except Exception:
            pass

    def handle(self, event):
        kind, val = event
        if kind == "sound":
            self.play(val)
        elif kind == "music":
            self.music_on = val

    def play(self, name):
        if self.music_on and self.player and name in self.files:
            self._spawn(self.player + [self.files[name]])

    def tick(self, want_music):
        """Call every frame: keeps the music looping while a level is played."""
        if want_music and self.player and "music" in self.files:
            if self.music_proc is None or self.music_proc.poll() is not None:
                self.music_proc = self._spawn(self.player + [self.files["music"]])
        elif self.music_proc is not None:
            self._kill(self.music_proc)
            self.music_proc = None
        if self.procs:
            self.procs = [p for p in self.procs if p.poll() is None]

    def close(self):
        self._closed = True
        for p in list(self.procs):
            self._kill(p)
        self.procs = []
        self.music_proc = None
        if self.tmp:
            shutil.rmtree(self.tmp, ignore_errors=True)
            self.tmp = None
