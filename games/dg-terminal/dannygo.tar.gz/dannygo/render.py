"""Terminal drawing for Danny Go! Jump Adventure. Reads game state; never
changes it.

The world is drawn into a grid of cells. One tile (40 x 40 game pixels)
is 4 columns x 2 rows, so a column is 10 game pixels wide and a row is 20
tall; an 80 x 24 terminal shows the same 20 tiles across as the web game.
"""
import curses
import math

import game as G

MIN_W, MIN_H = 80, 24
PX_X, PX_Y = 10, 20           # game pixels per terminal column / row

THEMES = {
    "grass": dict(sky1="#4fc3ff", sky2="#c9f0ff", hillA="#63b85a", hillB="#4a9c46",
                  dirt="#b06a3a", dirtDk="#8a4f2a", top="#5ec94f", brick="#d1703f",
                  brickDk="#a5522b", cloud="#ffffff", haze="#ffe9a8"),
    "sky": dict(sky1="#7f8cff", sky2="#d9e4ff", hillA="#8fa7e8", hillB="#6f88cf",
                dirt="#9a86d8", dirtDk="#7a67b5", top="#b9a6ff", brick="#c88ce0",
                brickDk="#a165bd", cloud="#ffffff", haze="#ffffff"),
    "volcano": dict(sky1="#ff8a3d", sky2="#ffd9a0", hillA="#6b3550", hillB="#4d2540",
                    dirt="#5a3346", dirtDk="#3e2233", top="#8a4a5e", brick="#8f4a3a",
                    brickDk="#6b3128", cloud="#ffcf9b", haze="#ffb15c"),
    "ice": dict(sky1="#bfe9ff", sky2="#eef8ff", hillA="#d3ecff", hillB="#a9d9f5",
                dirt="#eaf6ff", dirtDk="#c3e3f7", top="#ffffff", brick="#8fd6ff",
                brickDk="#5bb3e0", cloud="#ffffff", haze="#ffffff"),
}
INK = "#2b1a45"
SKIN = "#f6b877"
HAIR = "#4a2c18"
SHIRT = "#41a3ff"
SHOE = "#ff4d6d"
GOLD = "#ffd23f"

# Glyphs that may be missing from a font, with ASCII stand-ins (--ascii)
ASCII = {
    "▀": "\"", "▄": "_", "█": "#", "▌": "[", "▐": "]", "─": "-", "│": "|", "┬": "-",
    "┴": "-", "≡": "=", "≈": "~", "°": "o", "·": ".", "ö": "o", "×": "x", "♥": "<",
    "♡": ".", "◆": "*", "◇": ".", "●": "o", "▲": "^", "►": ">", "★": "*", "☆": "+",
    "▶": ">", "◀": "<", "•": "*", "♪": "m", "←": "<", "→": ">", "↑": "^",
    "ʚ": "{", "ɞ": "}", "✹": "*", "✸": "*",
}
ASCII_FIX = {ord(k): v for k, v in ASCII.items()}
# The Linux text console font has blocks and lines but few symbols
CONSOLE = {"★": "*", "☆": "+", "●": "o", "◆": "*", "◇": ".", "♡": ".", "▶": ">",
           "◀": "<", "≈": "~", "≡": "=", "ʚ": "{", "ɞ": "}", "✹": "*", "✸": "*"}
CONSOLE_FIX = {ord(k): v for k, v in CONSOLE.items()}

BLOCK_FONT = {
    "D": ["███▄ ", "█  ▀█", "█   █", "█  ▄█", "███▀ "],
    "A": [" ▄█▄ ", "█▀ ▀█", "█████", "█   █", "█   █"],
    "N": ["█▄  █", "██▄ █", "█ ▀██", "█  ▀█", "█   █"],
    "Y": ["█   █", "▀█ █▀", " ▀█▀ ", "  █  ", "  █  "],
    "G": ["▄███▄", "█▀   ", "█ ▀██", "█▄  █", "▀███▀"],
    "O": ["▄███▄", "█▀ ▀█", "█   █", "█▄ ▄█", "▀███▀"],
    "!": ["██", "██", "██", "  ", "██"],
    " ": ["  ", "  ", "  ", "  ", "  "],
}


# ------------------------------------------------------------ colours

def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    a, b = hex_rgb(a), hex_rgb(b)
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


_CUBE = [0, 95, 135, 175, 215, 255]
def _lab(rgb):
    def lin(c):
        c /= 255.0
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in rgb)
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t):
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


_PALETTE = [(i, _lab((_CUBE[(i - 16) // 36], _CUBE[(i - 16) // 6 % 6], _CUBE[(i - 16) % 6])))
            for i in range(16, 232)] + [(232 + j, _lab((8 + 10 * j,) * 3)) for j in range(24)]


def xterm256(h):
    """Nearest xterm-256 colour, compared in Lab so hues stay true."""
    L, A, B = _lab(hex_rgb(h))
    best, bd = 16, 1e9
    for i, (pl, pa, pb) in _PALETTE:
        d = 0.5 * (pl - L) ** 2 + (pa - A) ** 2 + (pb - B) ** 2
        if d < bd:
            best, bd = i, d
    return best


_BASIC = [(0, 0, 0), (205, 0, 0), (0, 205, 0), (205, 205, 0), (0, 0, 238),
          (205, 0, 205), (0, 205, 205), (229, 229, 229)]


def basic8(h):
    rgb = hex_rgb(h)
    return min(range(8), key=lambda i: sum((a - b) ** 2 for a, b in zip(_BASIC[i], rgb)))


class Colors:
    def __init__(self):
        self.mode = "mono"
        self.pairs = {}
        self.next = 1
        try:
            if curses.has_colors():
                curses.start_color()
                try:
                    curses.use_default_colors()
                except curses.error:
                    pass
                self.mode = "256" if curses.COLORS >= 256 else "8"
        except curses.error:
            pass
        self.conv = {}

    def color(self, h):
        c = self.conv.get(h)
        if c is None:
            if self.mode == "256":
                c = 235 if h == INK else xterm256(h)     # keep the panels dark
            else:
                c = basic8(h)
            self.conv[h] = c
        return c

    def attr(self, fg, bg):
        key = (fg, bg)
        a = self.pairs.get(key)
        if a is not None:
            return a
        if self.mode == "mono":
            a = curses.A_NORMAL
        else:
            f, b = self.color(fg), self.color(bg)
            pk = (f, b)
            a = self.pairs.get(pk)
            if a is None:
                if self.next < curses.COLOR_PAIRS:
                    try:
                        curses.init_pair(self.next, f, b)
                        a = curses.color_pair(self.next)
                        self.next += 1
                    except curses.error:
                        a = curses.A_NORMAL
                else:
                    a = curses.A_NORMAL
                if self.mode == "8" and f == 7 and b != 7:
                    a |= curses.A_BOLD
                self.pairs[pk] = a
        self.pairs[key] = a
        return a


# ------------------------------------------------------------ renderer

class Renderer:
    def __init__(self, scr, ascii_mode=False, console=False):
        self.scr = scr
        self.ascii = ascii_mode
        self.console = console
        self.colors = Colors()
        self.resize()

    def resize(self):
        self.h, self.w = self.scr.getmaxyx()
        self.small = self.h < MIN_H or self.w < MIN_W
        # all 13 tile rows fit from 27 lines up; otherwise the top row
        # (open sky) is dropped and the status line sits on it
        self.full = self.h >= 27
        self.map_top = 1 + (self.h - 27) // 2 if self.full else 0
        self.skip_px = 0 if self.full else G.TILE
        self.map_bottom = self.map_top + (G.VH - self.skip_px) // PX_Y   # exclusive
        try:
            self.scr.clear()
        except curses.error:
            pass

    # ------------------------------------------------ cell buffer
    def clear(self, bg):
        self.clip0, self.clip1 = 0, self.h
        self.ch = [[" "] * self.w for _ in range(self.h)]
        self.fg = [[bg] * self.w for _ in range(self.h)]
        self.bg = [[bg] * self.w for _ in range(self.h)]
        self.bold = [[False] * self.w for _ in range(self.h)]

    def cell(self, y, x, ch, fg=None, bg=None, bold=False):
        if self.clip0 <= y < self.clip1 and 0 <= x < self.w:
            if ch is not None:
                self.ch[y][x] = ch
            if fg is not None:
                self.fg[y][x] = fg
            if bg is not None:
                self.bg[y][x] = bg
            self.bold[y][x] = bold

    def write(self, y, x, s, fg, bg=None, bold=False):
        for i, c in enumerate(s):
            if c != "\0":
                self.cell(y, x + i, c, fg, bg, bold)

    def center(self, y, s, fg, bg=None, bold=False):
        self.write(y, (self.w - len(s)) // 2, s, fg, bg, bold)

    def flush(self):
        scr = self.scr
        scr.erase()
        tr = ASCII_FIX if self.ascii else (CONSOLE_FIX if self.console else None)
        for y in range(self.h):
            row_c, row_f, row_b, row_bold = self.ch[y], self.fg[y], self.bg[y], self.bold[y]
            x = 0
            w = self.w if y < self.h - 1 else self.w - 1     # bottom-right cell can't be written
            while x < w:
                f, b, bo = row_f[x], row_b[x], row_bold[x]
                j = x + 1
                while j < w and row_f[j] == f and row_b[j] == b and row_bold[j] == bo:
                    j += 1
                s = "".join(row_c[x:j])
                if tr:
                    s = s.translate(tr)
                if self.ascii and not s.isascii():
                    s = "".join(c if ord(c) < 128 else "?" for c in s)
                a = self.colors.attr(f, b)
                if bo:
                    a |= curses.A_BOLD
                try:
                    scr.addstr(y, x, s, a)
                except curses.error:
                    pass
                x = j
        scr.noutrefresh()
        curses.doupdate()

    # ------------------------------------------------ coordinates
    def sx(self, px):
        """game x (already minus camera) -> column"""
        return int(math.floor(px / PX_X))

    def sy(self, py):
        return int(math.floor((py - self.skip_px) / PX_Y)) + self.map_top

    def view_cam(self, g):
        view = self.w * PX_X
        lw = g.level.width * G.TILE
        cam = g.cam + G.VW / 2 - view / 2
        cam = max(0, min(lw - view, cam)) if lw > view else (lw - view) / 2
        return round(cam / PX_X) * PX_X       # whole columns: no shimmer

    # ------------------------------------------------ frame
    def frame(self, g):
        if self.small:
            self.clear("#1b1030")
            msg = "Please make the window bigger (at least 80 x 24)"
            self.center(self.h // 2, msg[:self.w], "#ffffff", bold=True)
            self.flush()
            return
        if g.state == G.TITLE:
            self.draw_title(g)
        else:
            self.draw_world(g)
            self.draw_hud(g)
            if g.state == G.CLEARED:
                self.box(["LEVEL CLEAR!", "",
                          "%s - %d stars" % (g.level.name, g.stars)], "#4be3a0")
            elif g.state == G.GAMEOVER:
                lines = ["OOPS!", "", "Let's try that level again."]
                if math.sin(g.tick * 0.09) > -0.3:
                    lines += ["", "Press SPACE to try again"]
                else:
                    lines += ["", ""]
                self.box(lines, "#ff8fa8")
            elif g.state == G.VICTORY:
                self.draw_victory(g)
        if g.confirm_quit:
            self.box(["Leave the game?", "", "Y = yes, quit    N = keep playing"], GOLD)
        self.flush()

    # ------------------------------------------------ world
    def draw_world(self, g):
        T = THEMES[g.level.theme]
        cam = self.view_cam(g)
        self.cam = cam
        self.T = T
        self.clear("#1b1030")
        # sky gradient
        for y in range(self.map_top, min(self.h, self.map_bottom)):
            py = (y - self.map_top) * PX_Y + self.skip_px
            col = mix(T["sky1"], T["sky2"], min(1, py / G.VH))
            for x in range(self.w):
                self.bg[y][x] = col
                self.fg[y][x] = col
        self.clip0, self.clip1 = self.map_top, min(self.h, self.map_bottom)
        self.draw_backdrop(g, T, cam)
        self.draw_tiles(g, T, cam)
        self.draw_flag(g, cam)
        for cp in g.level.checkpoints:
            self.draw_pennant(cp["c"] * G.TILE - cam, cp["r"] * G.TILE, 86,
                              "#4be3a0" if cp["hit"] else "#c8c8c8", g.tick if cp["hit"] else 0)
        for m in g.movers:
            y = self.sy(m.y + 4)
            x0 = self.sx(m.x - cam)
            for i in range(int(m.w / PX_X)):
                self.cell(y, x0 + i, "▀", "#ffb02e", None, True)
        for it in g.items:
            if it.type == "wings":
                up = math.sin(g.tick * 0.25) > 0
                self.sprite(it.x - cam + it.w / 2, it.y + it.h, [list("ʚɞ" if up else "≈≈")],
                            [[("#ffffff", None)] * 2])
            elif it.type == "fire":
                self.sprite(it.x - cam + it.w / 2, it.y + it.h, [["▄", "█", "▄"]],
                            [[("#ff3b3b", None), ("#ff3b3b", None), ("#ff3b3b", None)]])
                self.cell(self.sy(it.y + it.h - 1), self.sx(it.x - cam + it.w / 2), "▲", GOLD,
                          "#ff3b3b", True)
            else:
                self.sprite(it.x - cam + it.w / 2, it.y + it.h, [["▐", "ö", "▌"]],
                            [[("#ff5fa2", None), ("#ffffff", "#ff5fa2"), ("#ff5fa2", None)]])
        self.draw_enemies(g, cam)
        for s in g.snowballs:
            self.cell(self.sy(s.y), self.sx(s.x - cam), "●",
                      "#bfe9ff" if s.owner == "boss" else "#ffffff", None, True)
        for f in g.fireballs:
            self.cell(self.sy(f.y), self.sx(f.x - cam), "✹" if int(f.spin) % 2 else "✸",
                      "#ff7a1f", None, True)
        self.draw_player(g, cam)
        for q in g.parts:
            col = T["brick"] if q[6] == "brick" else q[6]
            if q[4] > 6:
                self.cell(self.sy(q[1]), self.sx(q[0] - cam), "•" if q[5] > 4 else "·", col, None, True)
        for s in g.pops:
            text = s[2]
            x = self.sx(s[0] - cam) - len(text) // 2
            self.write(self.sy(s[1]), x, text, "#ffffff", INK, True)

    def draw_backdrop(self, g, T, cam):
        H, W = self.h, self.w
        tick = g.tick
        # parallax hills: two layers of bumps, half-block tops
        off1 = math.fmod(-(cam * 0.22), 420)
        off2 = math.fmod(-(cam * 0.42), 380)

        def far(x):
            u = (x - off1) % 420
            if u < 220:
                t = u / 220
                return 2 * t * (1 - t) * 215
            t = (u - 220) / 200
            return 2 * t * (1 - t) * 160

        def near(x):
            u = (x - off2) % 380
            if u < 190:
                t = u / 190
                return 2 * t * (1 - t) * 150
            t = (u - 190) / 190
            return 2 * t * (1 - t) * 110

        for layer, color in ((far, T["hillB"]), (near, T["hillA"])):
            for x in range(W):
                h = layer(x * PX_X + 5)
                top = G.VH - h
                for y in range(self.map_top, min(H, self.map_bottom)):
                    py0 = (y - self.map_top) * PX_Y + self.skip_px
                    if py0 >= top:
                        self.bg[y][x] = color
                        self.fg[y][x] = color
                        self.ch[y][x] = " "
                    elif py0 + PX_Y / 2 >= top:
                        self.ch[y][x] = "▄"
                        self.fg[y][x] = color
        # clouds
        off3 = math.fmod(-(cam * 0.55), 680)
        for i in range(-1, 3):
            for bx, by in ((off3 + i * 680, 70), (off3 + i * 680 + 340, 125)):
                x0 = self.sx(bx - 30)
                y0 = self.sy(by - 30)
                self.write(y0, x0, "\0\0▄▄██▄\0\0", T["cloud"])
                self.write(y0 + 1, x0, "▄██████▄▄", T["cloud"])
                self.write(y0 + 2, x0, "▀▀▀▀▀▀▀▀▀", T["cloud"])
        if g.level.theme == "ice":
            for i in range(24):
                sxp = ((i * 137 + cam * 0.3 + tick * 0.6) % (W * PX_X + 40)) - 20
                syp = (i * 97 + tick * 1.3) % G.VH
                self.cell(self.sy(syp), self.sx(sxp), "·", "#ffffff", None, True)

    def draw_tiles(self, g, T, cam):
        lv = g.level
        live = lv.live
        tick = g.tick
        bumps = {(b[0], b[1]): b[2] for b in g.bumps}
        c0 = max(0, int(cam // G.TILE))
        c1 = min(lv.width - 1, int((cam + self.w * PX_X) // G.TILE))
        for c in range(c0, c1 + 1):
            x = self.sx(c * G.TILE - cam)
            for r in range(G.ROWS):
                ch = live[r][c]
                if ch == " ":
                    continue
                y = self.sy(r * G.TILE)
                if (c, r) in bumps:
                    y -= 1
                self.draw_tile(ch, x, y, c, r, T, tick, live)

    def draw_tile(self, ch, x, y, c, r, T, tick, live):
        cell = self.cell
        if ch == "=":
            top = r == 0 or live[r - 1][c] not in G.SOLID
            for i in range(4):
                if top:
                    cell(y, x + i, "▀", T["top"], T["dirt"])
                else:
                    cell(y, x + i, " ", T["dirt"], T["dirt"])
                cell(y + 1, x + i, " ", T["dirtDk"], T["dirt"])
            if (c * 7 + r * 5) % 3 == 0:
                cell(y + 1, x + 1 + ((c * 7) % 14) // 7, "·", T["dirtDk"], T["dirt"])
        elif ch == "b":
            self.write(y, x, "──┬─", T["brickDk"], T["brick"])
            self.write(y + 1, x, "─┴──", T["brickDk"], T["brick"])
        elif ch in "?!":
            glow = 0.5 + math.sin(tick * 0.11 + c) * 0.5
            base = "#ffc21c" if ch == "?" else "#ff5fa2"
            bg = mix(base, "#ffffff", glow * 0.35)
            mark = "??" if ch == "?" else "★★"
            self.write(y, x, " " + mark + " ", "#ffffff", bg, True)
            self.write(y + 1, x, "▄▄▄▄", "#7a4a00" if ch == "?" else "#a8326a", bg)
        elif ch in "WF":
            glow = 0.5 + math.sin(tick * 0.11 + c) * 0.5
            base = "#2f8fd8" if ch == "W" else "#ff7a3d"
            bg = mix(base, "#ffffff", glow * 0.35)
            if ch == "W":
                self.write(y, x, " ʚɞ ", "#ffffff", bg, True)
            else:
                self.write(y, x, " ▲▲ ", "#ffd23f", bg, True)
            self.write(y + 1, x, "▄▄▄▄", "#1f5f8a" if ch == "W" else "#7a2a00", bg)
        elif ch == "u":
            self.write(y, x, "    ", "#9c7c52", "#9c7c52")
            self.write(y + 1, x, "▄▄▄▄", "#6b5233", "#9c7c52")
        elif ch == "n":
            self.write(y, x, "≡≡≡≡", "#7f4f2c", "#a2683c")
            self.write(y + 1, x, "≡≡≡≡", "#7f4f2c", "#a2683c")
        elif ch == "c":
            self.write(y, x, "▄▄▄▄", "#ffffff")
            self.write(y + 1, x, "▀▀▀▀", "#ffffff")
        elif ch == "-":
            self.write(y, x, "▀▀▀▀", "#c98f4e", None, True)
        elif ch == "^":
            ph = int(tick * 0.08 + c * 0.7) % 2
            wave = "≈~≈~" if ph else "~≈~≈"
            self.write(y, x, wave, "#ffd24a", "#ff5a1f", True)
            self.write(y + 1, x, "    ", "#ffb02e", "#ffb02e")
            if (c + tick // 20) % 3 == 0:
                cell(y + 1, x + 1, "°", "#fff3b0", "#ffb02e")
        elif ch == "~":
            self.write(y, x, "    ", "#e0431a", "#e0431a")
            self.write(y + 1, x, "    ", "#e0431a", "#e0431a")
            if math.sin(tick * 0.06 + c) > 0.3:
                cell(y, x + 1, "°", "#ffa028", "#e0431a")
        elif ch == "o":
            bob = math.sin(tick * 0.1 + c * 0.5)
            yy = y if bob > -0.3 else y + 1
            spin = math.cos(tick * 0.05 + c * 0.4)
            star = "★" if abs(spin) > 0.4 else "☆"
            cell(yy, x + 1, star, GOLD, None, True)
            cell(yy, x + 2, star, GOLD, None, True)

    def draw_flag(self, g, cam):
        fc, fr = g.level.flag_pos
        x = fc * G.TILE - cam
        base = (fr + 1) * G.TILE
        if x < -120 or x > self.w * PX_X + 120:
            return
        col = self.sx(x + 16)
        top = self.sy(base - 260)
        for y in range(top, self.sy(base - 1)):
            self.cell(y, col, "│", "#8a5c2c", None, True)
        self.write(self.sy(base - 1), col - 1, "▄█▄", GOLD)
        fy = base - 250 + g.level.flag_down * 210
        y = self.sy(fy)
        self.write(y, col + 1, "███▄", "#ff4d6d")
        self.write(y + 1, col + 1, "█▀▀", "#ff4d6d")
        self.cell(y, col + 2, "★", GOLD, "#ff4d6d", True)

    def draw_pennant(self, x, y, height, color, tick):
        col = self.sx(x + 18)
        y0 = self.sy(y - 46)
        y1 = self.sy(y + 40)
        for yy in range(y0, y1):
            self.cell(yy, col, "│", "#6b4a2a", None, True)
        wave = math.sin(tick * 0.12) > 0 if tick else True
        self.write(y0, col + 1, "██▄" if wave else "█▄▄", color)
        self.write(y0 + 1, col + 1, "█▀" if wave else "▀▀", color)

    def sprite(self, cx, bottom, rows, colors, flip=False):
        """Draw rows of glyphs centred on game x `cx`, standing on `bottom`."""
        self.sprite_at(self.sx(cx), self.sy(bottom - 1), rows, colors, flip)

    def sprite_at(self, xc, ybottom, rows, colors, flip=False):
        n = len(rows)
        w = len(rows[0])
        x0 = xc - w // 2
        y0 = ybottom - n + 1
        for r in range(n):
            row, cols = rows[r], colors[r]
            if flip:
                row = [MIRROR.get(ch, ch) for ch in reversed(row)]
                cols = list(reversed(cols))
            for i, ch in enumerate(row):
                if ch == " ":
                    continue
                fg, bg = cols[i]
                self.cell(y0 + r, x0 + i, ch, fg, bg, True)

    def draw_enemies(self, g, cam):
        tick = g.tick
        for e in g.enemies:
            x = e.x - cam + e.w / 2
            if x < -80 or x > self.w * PX_X + 80:
                continue
            if e.dead:
                if e.dead < 18:
                    col = {"blob": "#a06bff", "fly": "#ff9d4d"}.get(e.type, "#c68a52")
                    self.sprite(x, e.y + e.h, [["▄", "▄", "▄"]], [[(col, None)] * 3])
                continue
            if e.type == "blob":
                P = "#a06bff"
                top = ["▄", "ö", "▄"] if math.sin(e.wob) > -0.5 else ["▄", "ö", "▄"]
                self.sprite(x, e.y + e.h, [top, ["▀", "▀", "▀"]],
                            [[(P, None), ("#ffffff", P), (P, None)],
                             [("#6e3fd1", None)] * 3])
            elif e.type == "fly":
                up = math.sin(tick * 0.35) > 0
                wing = "▀" if up else "▄"
                O = "#ff9d4d"
                self.sprite(x, e.y + e.h - 2, [[wing, "ö", wing]],
                            [[("#ffd7a8", None), (INK, O), ("#ffd7a8", None)]])
            else:
                robe = "#ffffff" if e.hit_flash > 0 else "#cdeeff"
                B = "#c68a52"
                rows = [[" ", " ", "▲", "▲", "▲", " ", " "],
                        [" ", "▐", "ö", "▄", "ö", "▌", " "],
                        ["o", "█", "█", "█", "█", "█", "o"],
                        [" ", "█", "█", "█", "█", "█", " "]]
                cols = [[(GOLD, None)] * 7,
                        [(B, None), (B, None), (INK, B), ("#e8c9a0", B), (INK, B), (B, None), (B, None)],
                        [("#f0b98a", None)] + [(robe, None)] * 5 + [("#f0b98a", None)],
                        [(robe, None)] * 7]
                self.sprite(x, e.y + e.h, rows, cols, flip=e.face < 0)

    def draw_player(self, g, cam):
        p = g.p
        if not g.player_visible():
            return
        anim = g.player_anim()
        phase = 0
        if anim == "run":
            phase = math.sin(p.run * 4 * 0.42) > 0
        elif anim == "dance":
            phase = math.sin(g.tick * 0.3) > 0
        rows, cols = danny_rows(p.big, anim, phase, hat=p.power == "fire")
        lift = g.wing_lift()
        if lift is not None:
            # wings poke out on both sides of the shirt
            up = lift > 0.35
            wing = ("ʚ", "ɞ") if up else ("≈", "≈")
            rows = [list(r) for r in rows]
            cols = [list(c) for c in cols]
            body = 1 if p.power != "fire" else 2
            rows = [[" "] + r + [" "] for r in rows]
            cols = [[(None, None)] + c + [(None, None)] for c in cols]
            rows[body][0], rows[body][-1] = wing
            cols[body][0] = cols[body][-1] = ("#ffffff", None)
        self.sprite(p.x + p.w / 2 - cam, p.y + p.h, rows, cols, flip=p.face < 0)

    # ------------------------------------------------ HUD & screens
    def draw_hud(self, g):
        self.clip0, self.clip1 = 0, self.h
        W = self.w
        P = INK
        for x in range(W):
            self.cell(0, x, " ", "#ffffff", P)
        if self.ascii:
            s = " LIVES %d" % g.hearts
        else:
            s = " " + "♥" * g.hearts + "♡" * (3 - g.hearts)
        self.write(0, 0, s, "#ff4d6d", P, True)
        self.write(0, len(s) + 2, "★", GOLD, P, True)
        self.write(0, len(s) + 3, "×%d" % g.stars, "#ffffff", P, True)
        x = len(s) + 10
        lv = g.level
        if lv.has_boss:
            hp = g.p.boss_hp
            self.write(0, x, "◆" * hp + "◇" * (5 - hp), "#8fe0ff", P, True)
            boss = g.boss()
            bhp = boss.hp if (boss and not boss.dead) else 0
            if bhp > 0:
                txt = "ICE KING " + "◆" * bhp + "◇" * (5 - bhp)
                self.write(0, (W - len(txt)) // 2, txt, "#eaffff", P, True)
                if abs(boss.x - g.p.x) < 640:
                    hint = " X = throw a snowball! "
                    self.write(1, (W - len(hint)) // 2, hint, "#ffffff", P, True)
        if g.p.power == "wings":
            self.write(0, x + (13 if lv.has_boss else 0), "ʚɞ wings", "#ffffff", P, True)
        elif g.p.power == "fire":
            self.write(0, x + (13 if lv.has_boss else 0), "▲ fire hat", "#ff7a3d", P, True)
        right = "LEVEL %d · %s " % (g.li + 1, lv.name)
        self.write(0, W - len(right), right, "#ffe9a8", P, True)
        if not g.music_on:
            self.write(0, W - len(right) - 4, "♪×", "#c8c8c8", P)

    def box(self, lines, color):
        width = max(len(s) for s in lines) + 8
        x0 = (self.w - width) // 2
        y0 = (self.h - len(lines)) // 2 - 1
        for i in range(len(lines) + 2):
            for x in range(width):
                self.cell(y0 + i, x0 + x, " ", "#ffffff", INK)
        for i, s in enumerate(lines):
            self.write(y0 + 1 + i, x0 + (width - len(s)) // 2, s,
                       color if i == 0 else "#ffffff", INK, True)

    def draw_victory(self, g):
        for q in g.parts:
            self.cell(self.sy(q[1]), self.sx(q[0] - self.cam), "•", q[6], None, True)
        lines = ["YOU DID IT!", "", "%d stars collected" % g.total_stars, ""]
        lines.append("Press SPACE to play again" if math.sin(g.tick * 0.09) > -0.3 else "")
        self.box(lines, GOLD)

    def draw_title(self, g):
        T = THEMES["grass"]
        tick = g.tick
        self.clear(T["sky1"])
        H, W = self.h, self.w
        for y in range(H):
            col = mix(T["sky1"], T["sky2"], y / H)
            for x in range(W):
                self.bg[y][x] = col
                self.fg[y][x] = col
        # hills and ground
        for x in range(W):
            u = x / W
            h = 2 * u * (1 - u) * 9 if u < 0.52 else 2 * ((u - .52) / .48) * (1 - (u - .52) / .48) * 7
            for y in range(H - 3 - int(h), H):
                self.cell(y, x, " ", T["hillB"], T["hillB"])
        for x in range(W):
            self.cell(H - 3, x, "▀", T["top"], T["hillA"])
            self.cell(H - 2, x, " ", T["hillA"], T["hillA"])
            self.cell(H - 1, x, " ", T["hillA"], T["hillA"])
        # drifting clouds
        for i in range(5):
            x0 = int(((tick * 0.04 + i * 19) % (W + 12)) - 10)
            y0 = 1 + (i % 3) * 2
            self.write(y0, x0, "\0▄██▄▄\0", "#ffffff")
            self.write(y0 + 1, x0, "▀▀▀▀▀▀▀", "#ffffff")
        # big title
        word = "DANNY GO!"
        glyphs = [BLOCK_FONT[ch] for ch in word]
        tw = sum(len(gl[0]) + 1 for gl in glyphs) - 1
        x = (W - tw) // 2
        y0 = 2 if H < 28 else 3
        bob = 1 if math.sin(tick * 0.05) > 0.6 else 0
        for gl in glyphs:
            for r, line in enumerate(gl):
                for i, ch in enumerate(line):
                    if ch != " ":
                        self.cell(y0 + r + bob, x + i, ch, GOLD, None, True)
            x += len(gl[0]) + 1
        self.center(y0 + 6, " J U M P   A D V E N T U R E ", "#ffffff", INK, True)
        rows, cols = danny_rows(True, "idle", 0)
        self.sprite_at(W // 2, y0 + 10, rows, cols)
        y = y0 + 12
        if math.sin(tick * 0.09) > -0.3:
            self.center(y, "  Press SPACE to start  ", "#ffffff", INK, True)
        help_lines = [" ← →  move    ↑ or Space  jump    Shift + ← →  run fast ",
                      " X  throw fireballs or snowballs     M  music     Esc  quit ",
                      " Blue block: wings, jump in the air to fly!  Orange: fire hat! "]
        width = max(len(s) for s in help_lines)
        for i, s in enumerate(help_lines):
            self.center(y + 2 + i, s.center(width), "#ffe9a8" if i == 2 else "#ffffff",
                        INK, True)


MIRROR = {"/": "\\", "\\": "/", "(": ")", ")": "(", "▌": "▐", "▐": "▌", "<": ">", ">": "<",
          "ʚ": "ɞ", "ɞ": "ʚ"}


def danny_rows(big, anim, phase, hat=False):
    """Danny as glyphs (facing right): (fire hat), head, shirt, legs (when big)."""
    S, H, B = SKIN, HAIR, SHIRT
    head = (["(", "ö", ")"], [(H, None), (INK, S), (H, None)])
    if anim == "jump":
        body = (["\\", "█", "/"], [(S, None), (B, None), (S, None)])
        legs = (["/", " ", "\\"], [(SHOE, None)] * 3)
    elif anim == "run":
        body = (["/", "█", "\\"] if phase else ["(", "█", "\\"], [(S, None), (B, None), (S, None)])
        legs = (["/", " ", "\\"] if phase else [" ", "▌", " "], [(SHOE, None)] * 3)
    elif anim == "dance":
        body = (["\\", "█", "/"] if phase else ["/", "█", "/"], [(S, None), (B, None), (S, None)])
        legs = (["▐", " ", "▌"] if phase else ["/", " ", "▌"], [(SHOE, None)] * 3)
    else:
        body = (["/", "█", "\\"], [(S, None), (B, None), (S, None)])
        legs = (["▐", " ", "▌"], [(SHOE, None)] * 3)
    parts = [head, body] + ([legs] if big else [])
    if hat:
        parts.insert(0, (["▄", "▲", "▄"], [("#ff3b3b", None), (GOLD, "#ff3b3b"), ("#ff3b3b", None)]))
        parts[1] = (["(", "ö", ")"], [("#ff3b3b", None), (INK, S), ("#ff3b3b", None)])
    return [p[0] for p in parts], [p[1] for p in parts]
