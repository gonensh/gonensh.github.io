#!/usr/bin/env python3
"""Rebuild assets/sheet.png + assets/sheet.json from the browser game.

    python3 tools/make_assets.py path/to/dg.html

The pictures are drawn by the browser game's own canvas code (Danny, the
tiles, enemies, flags...), run in headless Chrome, so the Linux edition
looks just like the web one. Needs google-chrome (or chromium) and Pillow.
"""
import base64
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCALE = 2          # sprites are stored at 2x and scaled down to fit the screen

WANTED = ["rr", "fillRR", "starPath", "text", "drawDanny", "drawTile",
          "drawCheckpoints", "drawMovers", "drawItems", "drawSnowballs",
          "drawEnemies"]


def extract_function(src, name):
    m = re.search(r"\nfunction %s\(" % re.escape(name), src)
    if not m:
        raise SystemExit("can't find function %s in the game" % name)
    i = src.index("{", m.end())
    depth = 0
    for j in range(i, len(src)):
        if src[j] == "{":
            depth += 1
        elif src[j] == "}":
            depth -= 1
            if depth == 0:
                return src[m.start() + 1:j + 1]
    raise SystemExit("unbalanced braces in " + name)


def extract_const(src, name):
    m = re.search(r"\nconst %s = " % re.escape(name), src)
    i = src.index("{", m.end())
    depth = 0
    for j in range(i, len(src)):
        if src[j] == "{":
            depth += 1
        elif src[j] == "}":
            depth -= 1
            if depth == 0:
                return src[m.start() + 1:j + 1] + ";"
    raise SystemExit("unbalanced braces in " + name)


PAGE = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>@font-face{font-family:'Fredoka';src:url('font.ttf');font-weight:100 900}</style>
</head><body><pre id="out">pending</pre><script>
'use strict';
const TILE = 40, COLS = 20, ROWS = 13, VW = 800, VH = 520;
const HIGH_CONTRAST = false;
const SOLID = '=b?!unc';
const isSolid = ch => SOLID.indexOf(ch) >= 0;
const panelBg = a => `rgba(43,26,69,${a})`;
%(consts)s
const themeOf = name => THEMES[name];
let ctx = null, cam = 0, tick = 0, theme = THEMES.grass, state = 'play';
let enemies = [], items = [], movers = [], snowballs = [], bumps = [];
let level = { meta:{checkpoints:[]}, theme:'grass', width:200 };
let tileAbove = ' ';
function tile(c, r){ return tileAbove; }
%(funcs)s

const S = %(scale)d, OUT = {};
function cell(name, w, h, ax, ay, draw){
  const cv = document.createElement('canvas');
  cv.width = Math.ceil(w*S); cv.height = Math.ceil(h*S);
  ctx = cv.getContext('2d');
  ctx.scale(S, S);
  draw();
  OUT[name] = { ax, ay, png: cv.toDataURL('image/png') };
}
const TAU = Math.PI*2;

function build(){
  // ---------- Danny
  const sizes = { s:[26,34], b:[30,52], t:[40,54] };
  for(const k in sizes){
    const [w,h] = sizes[k];
    const D = (name, anim, t) => cell(`danny_${k}_${name}`, 100, 110, 50, 100,
      () => drawDanny(50 - w/2, 100 - h, w, h, 1, anim, t));
    D('idle', 'idle', 0);
    D('jump', 'jump', 0);
    for(let i=0;i<8;i++) D('run'+i, 'run', i/8 * TAU/0.42);
    for(let i=0;i<8;i++) D('dance'+i, 'dance', i/8 * TAU/0.3);
  }

  // ---------- tiles (cell has a 16px margin; anchor = tile top-left)
  const T = (name, ch, setup) => cell('tile_'+name, 72, 72, 16, 16, () => {
    if(setup) setup(); drawTile(ch, 16, 16, 0, 0);
  });
  for(const th in THEMES){
    T(th+'_ground_top', '=', () => { theme = THEMES[th]; tileAbove = ' '; });
    T(th+'_ground', '=', () => { theme = THEMES[th]; tileAbove = '='; });
    T(th+'_brick', 'b', () => { theme = THEMES[th]; });
  }
  theme = THEMES.grass;
  T('stump', 'n'); T('used', 'u'); T('cloud', 'c'); T('plank', '-');
  for(let i=0;i<8;i++){
    const ph = i/8*TAU;
    T('q'+i, '?', () => { tick = ph/0.11; });
    T('snack'+i, '!', () => { tick = ph/0.11; });
    T('lavatop'+i, '^', () => { tick = ph/0.08; });
    T('lava'+i, '~', () => { tick = ph/0.06; });
  }
  for(let i=0;i<12;i++) T('star'+i, 'o', () => { tick = i/12*TAU/0.05; });

  // ---------- enemies (anchor = centre-bottom, centre for flies)
  for(const f of [-1, 1]){
    const F = f < 0 ? 'L' : 'R';
    for(let i=0;i<8;i++){
      cell(`blob_${F}${i}`, 60, 60, 30, 50, () => {
        enemies = [{type:'blob', x:15, y:22, w:30, h:28, face:f, wob:i/8*TAU, dead:0}];
        drawEnemies();
      });
      cell(`fly_${F}${i}`, 70, 50, 35, 25, () => {
        tick = i/8*TAU/0.35;
        enemies = [{type:'fly', x:21, y:13, w:28, h:24, face:f, dead:0}];
        drawEnemies();
      });
    }
  }
  for(const flash of [0, 1]){
    cell('king_' + (flash ? 'flash' : 'normal'), 140, 150, 70, 130, () => {
      enemies = [{type:'iceking', x:35, y:50, w:70, h:80, face:1, hitFlash:flash ? 5 : 0, dead:0}];
      drawEnemies();
    });
  }
  const deadBase = (name, w, h, color) => cell('dead_'+name, w+8, h+8, 4, 4,
    () => fillRR(4, 4, w, h, 12, color, '#2b1a45'));
  deadBase('blob', 30, 28, '#a06bff');
  deadBase('fly', 28, 24, '#ff9d4d');
  deadBase('iceking', 70, 80, '#c68a52');

  // ---------- level objects
  cell('cp_off', 70, 100, 4, 50, () => {
    ctx.translate(4, 50);
    level = {meta:{checkpoints:[{c:0, r:0, hit:false}]}};
    drawCheckpoints();
  });
  for(let i=0;i<8;i++) cell('cp_on'+i, 70, 100, 4, 50, () => {
    ctx.translate(4, 50); tick = i/8*TAU/0.12;
    level = {meta:{checkpoints:[{c:0, r:0, hit:true}]}};
    drawCheckpoints();
  });
  // flag: pole + base (anchor = tile left x, base y), pennant separately
  cell('flag_pole', 44, 266, 2, 263, () => {
    const x = 2, base = 263;
    ctx.fillStyle = '#8a5c2c'; ctx.fillRect(x+16, base-260, 8, 260);
    fillRR(x+2, base-24, 36, 24, 6, '#ffd23f', '#2b1a45');
  });
  for(let i=0;i<6;i++) cell('flag_pen'+i, 84, 40, 0, 4, () => {
    const x = -24, fy = 4;
    ctx.fillStyle = '#ff4d6d';
    ctx.beginPath();
    ctx.moveTo(x+24, fy); ctx.lineTo(x+74, fy+16); ctx.lineTo(x+24, fy+32);
    ctx.closePath(); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = '#2b1a45'; ctx.stroke();
    starPath(x+40, fy+16, 8, 3.6, i/6 * TAU/5);
    ctx.fillStyle = '#ffd23f'; ctx.fill();
  });
  cell('mover', 132, 34, 6, 6, () => {
    movers = [{x:6, y:6, w:120, h:18}]; drawMovers();
  });
  cell('snack', 40, 40, 6, 6, () => {
    items = [{x:6, y:6, w:28, h:28}]; drawItems();
  });
  cell('ball_player', 26, 26, 13, 13, () => {
    snowballs = [{owner:'player', x:13, y:13, r:8}]; drawSnowballs();
  });
  cell('ball_boss', 30, 30, 15, 15, () => {
    snowballs = [{owner:'boss', x:15, y:15, r:10}]; drawSnowballs();
  });

  // ---------- HUD bits
  for(const on of [1, 0]){
    cell('heart_' + (on ? 'on' : 'off'), 30, 24, 15, 13, () => {
      const hx = 15, hy = 13;
      ctx.fillStyle = on ? '#ff4d6d' : 'rgba(255,255,255,.22)';
      ctx.beginPath();
      ctx.moveTo(hx, hy+7);
      ctx.bezierCurveTo(hx-13, hy-3, hx-6, hy-13, hx, hy-6);
      ctx.bezierCurveTo(hx+6, hy-13, hx+13, hy-3, hx, hy+7);
      ctx.fill();
    });
    cell('dia_' + (on ? 'on' : 'off'), 14, 16, 7, 8, () => {
      const hx = 7, hy = 8;
      ctx.fillStyle = on ? '#8fe0ff' : 'rgba(255,255,255,.22)';
      ctx.beginPath();
      ctx.moveTo(hx, hy-6); ctx.lineTo(hx+5, hy); ctx.lineTo(hx, hy+6); ctx.lineTo(hx-5, hy);
      ctx.closePath(); ctx.fill();
    });
    cell('bossdia_' + (on ? 'on' : 'off'), 20, 20, 10, 10, () => {
      ctx.translate(10, 10); ctx.rotate(Math.PI/4);
      ctx.fillStyle = on ? '#eaffff' : 'rgba(255,255,255,.22)';
      ctx.strokeStyle = '#1c3a52'; ctx.lineWidth = 1.5;
      ctx.fillRect(-5,-5,10,10); ctx.strokeRect(-5,-5,10,10);
    });
  }
  for(let i=0;i<6;i++) cell('hud_star'+i, 26, 26, 13, 13, () => {
    starPath(13, 13, 11, 5, i/6 * TAU/5);
    ctx.fillStyle = '#ffd23f'; ctx.fill();
  });

  // ---------- backgrounds (anchor 0,0)
  for(const th in THEMES){
    const t = THEMES[th];
    cell('bg_sky_'+th, VW, VH, 0, 0, () => {
      const g = ctx.createLinearGradient(0,0,0,VH);
      g.addColorStop(0, t.sky1); g.addColorStop(1, t.sky2);
      ctx.fillStyle = g; ctx.fillRect(0,0,VW,VH);
      ctx.globalAlpha = 0.85; ctx.fillStyle = t.haze;
      ctx.beginPath(); ctx.arc(660, 90, 46, 0, 7); ctx.fill();
      ctx.globalAlpha = 0.22;
      ctx.beginPath(); ctx.arc(660, 90, 78, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    });
    cell('bg_far_'+th, 420, 220, 0, 0, () => {
      ctx.translate(0, 220 - VH);
      ctx.fillStyle = t.hillB; ctx.beginPath(); ctx.moveTo(0, VH);
      ctx.quadraticCurveTo(110, VH-215, 220, VH);
      ctx.quadraticCurveTo(320, VH-160, 420, VH);
      ctx.closePath(); ctx.fill();
    });
    cell('bg_near_'+th, 380, 160, 0, 0, () => {
      ctx.translate(0, 160 - VH);
      ctx.fillStyle = t.hillA; ctx.beginPath(); ctx.moveTo(0, VH);
      ctx.quadraticCurveTo(95, VH-150, 190, VH);
      ctx.quadraticCurveTo(285, VH-110, 380, VH);
      ctx.closePath(); ctx.fill();
    });
    cell('bg_cloud_'+th, 120, 76, 30, 46, () => {
      ctx.fillStyle = t.cloud; ctx.globalAlpha = 0.9;
      const bx = 30, by = 46;
      ctx.beginPath();
      ctx.arc(bx, by, 26, 0, 7); ctx.arc(bx+28, by-12, 32, 0, 7);
      ctx.arc(bx+62, by, 24, 0, 7); ctx.fill();
    });
  }
  // title screen
  cell('bg_title', VW, VH, 0, 0, () => {
    const T = THEMES.grass;
    const g = ctx.createLinearGradient(0,0,0,VH);
    g.addColorStop(0, T.sky1); g.addColorStop(1, T.sky2);
    ctx.fillStyle = g; ctx.fillRect(0,0,VW,VH);
    ctx.fillStyle = T.hillB;
    ctx.beginPath(); ctx.moveTo(0,VH);
    ctx.quadraticCurveTo(200, VH-230, 420, VH);
    ctx.quadraticCurveTo(620, VH-180, 800, VH); ctx.closePath(); ctx.fill();
    ctx.fillStyle = T.hillA; ctx.fillRect(0, VH-62, VW, 62);
    ctx.fillStyle = T.top; ctx.fillRect(0, VH-62, VW, 14);
  });
  cell('title_cloud', 110, 80, 26, 50, () => {
    ctx.fillStyle = '#fff'; ctx.globalAlpha = .85;
    const bx = 26, by = 50;
    ctx.beginPath(); ctx.arc(bx, by, 22, 0, 7); ctx.arc(bx+24, by-12, 27, 0, 7);
    ctx.arc(bx+52, by, 20, 0, 7); ctx.fill();
  });
}

document.fonts.load("700 22px Fredoka").then(() => {
  build();
  document.getElementById('out').textContent = JSON.stringify(OUT);
}).catch(e => { document.getElementById('out').textContent = 'ERROR ' + e; });
</script></body></html>
"""


def find_chrome():
    for name in ("google-chrome", "chromium", "chromium-browser", "google-chrome-stable"):
        p = shutil.which(name)
        if p:
            return p
    raise SystemExit("needs google-chrome or chromium")


def main():
    src_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "..", "dg.html")
    html = open(src_path, encoding="utf-8").read()
    js = html[html.rindex("<script>") + 8:]
    funcs = []
    for name in WANTED:
        f = extract_function(js, name)
        if name == "drawTile":
            # keep the random-looking pebble and the star bob out of the
            # pictures: the game adds them while drawing
            f = re.sub(r"\n\s*ctx\.fillStyle = 'rgba\(0,0,0,\.10\)';\n\s*ctx\.fillRect\([^\n]*\n", "\n", f)
            f = f.replace("const bobY = Math.sin(tick*0.1 + c*0.5)*3;", "const bobY = 0;")
        funcs.append(f)
    consts = extract_const(js, "THEMES")
    page = PAGE % {"consts": consts, "funcs": "\n".join(funcs), "scale": SCALE}

    tmp = tempfile.mkdtemp(prefix="dg-assets-")
    try:
        with open(os.path.join(tmp, "atlas.html"), "w", encoding="utf-8") as f:
            f.write(page)
        shutil.copy(os.path.join(ROOT, "assets", "FredokaOne-Regular.ttf"),
                    os.path.join(tmp, "font.ttf"))
        out = subprocess.run(
            [find_chrome(), "--headless=new", "--no-sandbox", "--disable-gpu",
             "--allow-file-access-from-files", "--virtual-time-budget=20000",
             "--dump-dom", "file://" + os.path.join(tmp, "atlas.html")],
            capture_output=True, text=True, timeout=180).stdout
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    m = re.search(r'<pre id="out">(.*?)</pre>', out, re.S)
    if not m or not m.group(1).startswith("{"):
        raise SystemExit("drawing failed: " + (m.group(1)[:300] if m else out[:300]))
    data = json.loads(m.group(1).replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">"))

    from PIL import Image
    imgs = {}
    for name, d in data.items():
        raw = base64.b64decode(d["png"].split(",", 1)[1])
        im = Image.open(io.BytesIO(raw)).convert("RGBA")
        imgs[name] = (im, d["ax"], d["ay"])

    meta = {"scale": SCALE, "sprites": {}, "files": {}}
    # full-screen backdrops go in their own files
    for n in [n for n in imgs if n.startswith("bg_sky_") or n == "bg_title"]:
        im, ax, ay = imgs.pop(n)
        im.convert("RGB").save(os.path.join(ROOT, "assets", n + ".png"), optimize=True)
        meta["files"][n] = [n + ".png", im.width, im.height, ax, ay]

    # simple shelf packing, tallest first
    order = sorted(imgs, key=lambda n: (-imgs[n][0].height, n))
    sheet_w = 2048
    x = y = shelf = 0
    rects = {}
    for n in order:
        im = imgs[n][0]
        if x + im.width > sheet_w:
            x, y, shelf = 0, y + shelf + 1, 0
        rects[n] = (x, y, im.width, im.height)
        x += im.width + 1
        shelf = max(shelf, im.height)
    sheet = Image.new("RGBA", (sheet_w, y + shelf + 1), (0, 0, 0, 0))
    for n, (x, y, w, h) in rects.items():
        im, ax, ay = imgs[n]
        sheet.paste(im, (x, y))
        meta["sprites"][n] = [x, y, w, h, ax, ay]
    sheet.save(os.path.join(ROOT, "assets", "sheet.png"), optimize=True)
    with open(os.path.join(ROOT, "assets", "sheet.json"), "w") as f:
        json.dump(meta, f, separators=(",", ":"), sort_keys=True)
    # desktop-menu icon: Danny on a sky-blue tile
    from PIL import ImageDraw
    icon = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    mask = Image.new("L", (128, 128), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, 127, 127), 26, fill=255)
    sky = Image.new("RGBA", (128, 128))
    for y in range(128):
        t = y / 127
        c = tuple(int(a + (b - a) * t) for a, b in ((79, 201), (195, 240), (255, 255)))
        ImageDraw.Draw(sky).line((0, y, 127, y), fill=c + (255,))
    ImageDraw.Draw(sky).rectangle((0, 104, 127, 127), fill=(94, 201, 79, 255))
    icon.paste(sky, (0, 0), mask)
    d, ax, ay = imgs["danny_t_idle"]
    ax, ay = ax * SCALE, ay * SCALE
    d = d.crop((ax - 75, ay - 146, ax + 75, ay + 10)).resize((112, 116), Image.LANCZOS)
    icon.alpha_composite(d, (8, 6))
    icon.save(os.path.join(ROOT, "assets", "icon.png"))
    print("%d sprites -> assets/sheet.png (%dx%d)" % (len(rects), sheet.width, sheet.height))


if __name__ == "__main__":
    main()
