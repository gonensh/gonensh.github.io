#!/usr/bin/env python3
"""Danny Go! Jump Adventure - terminal edition.

    python3 dannygo.py [--ascii] [--no-music] [--level N] [--autoplay]

Needs only Python 3. Sound plays through pw-play, paplay or aplay if one
is installed. The window must be at least 80 x 24.
"""
import argparse
import atexit
import curses
import locale
import os
import select
import signal
import sys
import time

import game as G
from audio import Audio
from keys import Keyboard
from render import Renderer

FPS = 30


def run(stdscr, args, audio):
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    curses.raw()                 # we read the bytes ourselves
    curses.noecho()
    stdscr.keypad(False)
    fd = sys.stdin.fileno()
    console = os.environ.get("TERM", "") == "linux"
    renderer = Renderer(stdscr, ascii_mode=args.ascii, console=console)
    kb = Keyboard()
    atexit.register(kb.close)
    kb.probe()
    game = G.Game(music_on=not args.no_music)
    if args.level > 1:
        game.load_level(max(0, min(len(game.levels) - 1, args.level - 1)))
        game.state = G.PLAY
    bot = G.Bot(game) if args.autoplay else None

    resized = [False]

    def on_winch(*_):
        resized[0] = True
    try:
        signal.signal(signal.SIGWINCH, on_winch)
    except (AttributeError, ValueError):
        pass

    frame = 1.0 / FPS
    last = time.monotonic()
    started = last
    acc = 0.0
    victory_since = None
    try:
        while not game.quit:
            now = time.monotonic()
            if resized[0]:
                resized[0] = False
                try:
                    sz = os.get_terminal_size(fd)
                    curses.resizeterm(sz.lines, sz.columns)
                except (OSError, curses.error):
                    pass
                renderer.resize()

            data = b""
            while select.select([fd], [], [], 0)[0]:
                chunk = os.read(fd, 4096)
                if not chunk:
                    break
                data += chunk
                if len(data) > 65536:
                    break
            kb.feed(data, now)

            for key, _shift in kb.take_presses():
                if key == "ctrl-c" or (key == "q" and game.confirm_quit):
                    game.quit = True
                elif key == "esc":
                    game.key("esc")
                elif key in ("m", "1"):
                    game.key("m")
                elif game.confirm_quit:
                    game.key(key if key in ("y", "n", "enter") else "x")
                elif key in ("down", "s") and not kb.kitty:
                    kb.stop()
                elif game.state in (G.TITLE, G.GAMEOVER, G.VICTORY) and key not in (
                        "shift", "ctrl", "alt"):
                    game.key("enter")
            if game.quit:
                break

            acc += min(0.1, now - last)
            last = now
            steps = 0
            while acc >= G.STEP and steps < 6:
                game.inp = bot.inputs() if bot else kb.state(now)
                game.step()
                acc -= G.STEP
                steps += 1

            for ev in game.pop_events():
                audio.handle(ev)
            audio.tick(game.music_wanted)
            renderer.frame(game)

            if bot:
                if game.state == G.VICTORY:
                    victory_since = victory_since or now
                    if now - victory_since > 3:
                        break
                if args.seconds and now - started > args.seconds:
                    break
            spare = frame - (time.monotonic() - now)
            if spare > 0:
                select.select([fd], [], [], spare)     # wake early on a key press
    finally:
        kb.close()


def main(argv=None):
    ap = argparse.ArgumentParser(description="Danny Go! Jump Adventure - terminal edition")
    ap.add_argument("--ascii", action="store_true", help="plain ASCII characters only")
    ap.add_argument("--no-music", action="store_true", help="start with sound off")
    ap.add_argument("--level", type=int, default=1, help="start on this level (1-4)")
    ap.add_argument("--autoplay", action="store_true", help="the game plays itself, then exits")
    ap.add_argument("--seconds", type=float, default=0, help="with --autoplay: stop after this long")
    args = ap.parse_args(argv)

    locale.setlocale(locale.LC_ALL, "")
    enc = (locale.getpreferredencoding(False) or "").lower().replace("-", "")
    if enc != "utf8":
        args.ascii = True

    if not sys.stdin.isatty():
        print("Please run this in a terminal.", file=sys.stderr)
        return 1
    os.environ.setdefault("ESCDELAY", "25")
    audio = Audio(music_on=not args.no_music)
    atexit.register(audio.close)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        signal.signal(signal.SIGHUP, lambda *_: sys.exit(0))
    except (AttributeError, ValueError):
        pass
    try:
        curses.wrapper(run, args, audio)
    except KeyboardInterrupt:
        pass
    finally:
        audio.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
