"""Drawing for the graphics edition (pygame). Reads game state; never changes it.

All pictures come from assets/sheet.png, which tools/make_assets.py draws
with the browser game's own canvas code. They're scaled once, at start-up,
to the chosen resolution, so each frame is just blits.
"""
import json
import math
import os
import random

import pygame

import game as G

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")
FONT = os.path.join(ASSETS, "FredokaOne-Regular.ttf")
TAU = math.pi * 2
DW, DH = G.VW, G.VH
INK = (43, 26, 69)

THEME_BRICK = {"grass": "#d1703f", "sky": "#c88ce0", "volcano": "#8f4a3a", "ice": "#8fd6ff"}


def rgb(c):
    if isinstance(c, tuple):
        return c
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


WING_FRAMES, WING_MIN, WING_MAX = 9, -0.3, 1.0     # as drawn by tools/make_assets.py


def wing_frame(prefix, lift):
    t = (lift - WING_MIN) / (WING_MAX - WING_MIN)
    return "%s%d" % (prefix, max(0, min(WING_FRAMES - 1, int(round(t * (WING_FRAMES - 1))))))


def frame_of(phase, n):
    return int(round((phase % TAU) / TAU * n)) % n


class Renderer:
    def __init__(self, screen, K):
        self.screen = screen
        self.K = K
        self.ox = self.oy = 0
        self.sprites = {}
        self._flip = {}
        self._text = {}
        self._fonts = {}
        self._panels = {}
        self._dots = {}
        self._dead = {}
        self.rng = random.Random(1)
        self._load()

    # ------------------------------------------------ loading
    def _load(self):
        with open(os.path.join(ASSETS, "sheet.json")) as f:
            meta = json.load(f)
        f = self.K / meta["scale"]
        sheet = pygame.image.load(os.path.join(ASSETS, "sheet.png")).convert_alpha()
        # tiles are stretched by a pixel so neighbours overlap: no seams
        tile_m = (math.ceil(G.TILE * self.K) + 1) / (G.TILE * self.K)
        for name, (x, y, w, h, ax, ay) in meta["sprites"].items():
            m = tile_m if name.startswith("tile_") else 1.0
            sub = sheet.subsurface((x, y, w, h))
            size = (max(1, round(w * f * m)), max(1, round(h * f * m)))
            self.sprites[name] = (pygame.transform.smoothscale(sub, size),
                                  ax * self.K * m, ay * self.K * m)
        del sheet
        for name, (fn, w, h, ax, ay) in meta["files"].items():
            img = pygame.image.load(os.path.join(ASSETS, fn)).convert()
            size = (round(DW * self.K), round(DH * self.K))
            self.sprites[name] = (pygame.transform.smoothscale(img, size), 0, 0)
        peb = pygame.Surface((max(1, round(6 * self.K)), max(1, round(5 * self.K))), pygame.SRCALPHA)
        peb.fill((0, 0, 0, 26))
        self.pebble = peb

    # ------------------------------------------------ primitives
    def blit(self, name, x, y, flip=False, alpha=None):
        """Draw sprite `name` with its anchor at world-on-screen point (x, y)."""
        surf, ax, ay = self.sprites[name]
        if flip:
            fs = self._flip.get(name)
            if fs is None:
                fs = self._flip[name] = pygame.transform.flip(surf, True, False)
            surf = fs
            ax = surf.get_width() - ax
        if alpha is not None:
            surf.set_alpha(int(255 * max(0.0, min(1.0, alpha))))
        K = self.K
        self.screen.blit(surf, (round(x * K - ax + self.ox), round(y * K - ay + self.oy)))
        if alpha is not None:
            surf.set_alpha(None)

    def font(self, size):
        px = max(6, round(size * self.K * 1.02))
        f = self._fonts.get(px)
        if f is None:
            f = self._fonts[px] = pygame.font.Font(FONT, px)
        return f

    def text_surf(self, s, size, color, outline=None):
        key = (s, size, color, outline)
        surf = self._text.get(key)
        if surf is not None:
            return surf
        font = self.font(size)
        main = font.render(s, True, rgb(color))
        if outline:
            r = max(1, round(size / 10 * self.K))
            w, h = main.get_width() + 2 * r, main.get_height() + 2 * r
            surf = pygame.Surface((w, h), pygame.SRCALPHA)
            o = font.render(s, True, rgb(outline))
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    if dx * dx + dy * dy <= r * r + r:
                        surf.blit(o, (r + dx, r + dy))
            surf.blit(main, (r, r))
        else:
            surf = main
        if len(self._text) > 400:
            self._text.clear()
        self._text[key] = surf
        return surf

    def text(self, s, x, y, size, color, align="left", outline=None, alpha=None):
        surf = self.text_surf(s, size, color, outline)
        K = self.K
        px = x * K
        if align == "center":
            px -= surf.get_width() / 2
        elif align == "right":
            px -= surf.get_width()
        py = y * K - surf.get_height() / 2
        if alpha is not None:
            surf.set_alpha(int(255 * max(0, min(1, alpha))))
        self.screen.blit(surf, (round(px + self.ox), round(py + self.oy)))
        if alpha is not None:
            surf.set_alpha(None)

    def panel(self, x, y, w, h, r, alpha, color=INK):
        key = (w, h, r, alpha, color)
        surf = self._panels.get(key)
        if surf is None:
            K = self.K
            surf = pygame.Surface((round(w * K), round(h * K)), pygame.SRCALPHA)
            pygame.draw.rect(surf, color + (int(255 * alpha),), surf.get_rect(),
                             border_radius=round(r * K))
            self._panels[key] = surf
        self.screen.blit(surf, (round(x * self.K + self.ox), round(y * self.K + self.oy)))

    def shade(self, alpha):
        self.panel(-20, -20, DW + 40, DH + 40, 0, alpha)

    def dot(self, x, y, r, color, alpha):
        K = self.K
        rr = max(1, round(r * K))
        key = (color, rr)
        surf = self._dots.get(key)
        if surf is None:
            surf = pygame.Surface((2 * rr + 2, 2 * rr + 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, rgb(color), (rr + 1, rr + 1), rr)
            self._dots[key] = surf
        surf.set_alpha(int(255 * max(0, min(1, alpha))))
        self.screen.blit(surf, (round(x * K - rr - 1 + self.ox), round(y * K - rr - 1 + self.oy)))

    # ------------------------------------------------ frame
    def draw(self, g):
        self.ox = self.oy = 0
        if g.shake > 0:
            self.ox = (self.rng.random() - .5) * g.shake * self.K
            self.oy = (self.rng.random() - .5) * g.shake * self.K
        if g.state == G.TITLE:
            self.ox = self.oy = 0
            self.draw_title(g)
        else:
            self.draw_world(g)
            self.draw_hud(g)
            if g.state == G.CLEARED:
                self.banner("LEVEL CLEAR!", "%s - %d stars" % (g.level.name, g.stars),
                            "#4be3a0", g.tick)
            elif g.state == G.GAMEOVER:
                self.draw_gameover(g)
            elif g.state == G.VICTORY:
                self.draw_victory(g)
        if g.confirm_quit:
            self.ox = self.oy = 0
            self.shade(0.7)
            self.text("Leave the game?", DW / 2, DH / 2 - 30, 46, "#ffd23f", "center", "#2b1a45")
            self.text("Y = yes, quit      N = keep playing", DW / 2, DH / 2 + 30, 22,
                      "#ffffff", "center", "#2b1a45")

    # ------------------------------------------------ world
    def draw_world(self, g):
        lv, th, cam, tick = g.level, g.level.theme, g.cam, g.tick
        self.screen.blit(self.sprites["bg_sky_" + th][0], (round(self.ox), round(self.oy)))
        off1 = math.fmod(-(cam * 0.22), 420)
        for i in range(-1, 4):
            self.blit("bg_far_" + th, off1 + i * 420, DH - 220)
        off2 = math.fmod(-(cam * 0.42), 380)
        for i in range(-1, 4):
            self.blit("bg_near_" + th, off2 + i * 380, DH - 160)
        off3 = math.fmod(-(cam * 0.55), 680)
        for i in range(-1, 3):
            self.blit("bg_cloud_" + th, off3 + i * 680, 70)
            self.blit("bg_cloud_" + th, off3 + i * 680 + 340, 125)
        if th == "ice":
            for i in range(40):
                sx = ((i * 137 + cam * 0.3 + tick * 0.6) % (DW + 40)) - 20
                sy = (i * 97 + tick * 1.3) % DH
                self.dot(sx, sy, 1.6 + (i % 3), "#ffffff", 0.85)

        # tiles
        bumps = {(b[0], b[1]): b[2] for b in g.bumps}
        c_start = max(0, int(cam // G.TILE) - 1)
        c_end = min(lv.width - 1, int(math.ceil((cam + DW) / G.TILE)) + 1)
        live = lv.live
        for c in range(c_start, c_end + 1):
            x = c * G.TILE - cam
            for r in range(G.ROWS):
                ch = live[r][c]
                if ch == " ":
                    continue
                y = r * G.TILE
                bt = bumps.get((c, r))
                if bt is not None:
                    y -= math.sin((14 - bt) / 14 * math.pi) * 10
                self.draw_tile(ch, x, y, c, r, th, tick, live)

        self.draw_flag(g)
        for cp in lv.checkpoints:
            x = cp["c"] * G.TILE - cam
            if -60 <= x <= DW + 60:
                name = "cp_on%d" % frame_of(tick * 0.12, 8) if cp["hit"] else "cp_off"
                self.blit(name, x, cp["r"] * G.TILE)
        for m in g.movers:
            x = m.x - cam
            if -160 <= x <= DW + 160:
                self.blit("mover", x, m.y)
        for it in g.items:
            if it.type == "wings":
                lift = 0.35 + math.sin(tick * 0.25) * 0.45
                self.blit(wing_frame("item_wings", lift), it.x - cam + it.w / 2, it.y + it.h / 2)
            elif it.type == "fire":
                self.blit("item_fire%d" % frame_of(tick * 0.15, 6), it.x - cam, it.y)
            else:
                self.blit("snack", it.x - cam, it.y)
        self.draw_enemies(g)
        for s in g.snowballs:
            self.blit("ball_boss" if s.owner == "boss" else "ball_player", s.x - cam, s.y)
        for f in g.fireballs:
            self.blit("fireball%d" % frame_of(f.spin * 5, 6), f.x - cam, f.y)
        self.draw_player(g)
        self.draw_particles(g)

    def draw_tile(self, ch, x, y, c, r, th, tick, live):
        if ch == "=":
            top = r == 0 or live[r - 1][c] not in G.SOLID
            self.blit("tile_%s_ground%s" % (th, "_top" if top else ""), x, y)
            K = self.K
            self.screen.blit(self.pebble, (round((x + 8 + (c * 7) % 14) * K + self.ox),
                                           round((y + 16 + (r * 5) % 12) * K + self.oy)))
        elif ch == "b":
            self.blit("tile_%s_brick" % th, x, y)
        elif ch == "?":
            self.blit("tile_q%d" % frame_of(tick * 0.11 + c, 8), x, y)
        elif ch == "!":
            self.blit("tile_snack%d" % frame_of(tick * 0.11 + c, 8), x, y)
        elif ch == "W":
            self.blit("tile_wings%d" % frame_of(tick * 0.11 + c, 8), x, y)
        elif ch == "F":
            self.blit("tile_fire%d" % frame_of(tick * 0.11 + c, 8), x, y)
        elif ch == "u":
            self.blit("tile_used", x, y)
        elif ch == "n":
            self.blit("tile_stump", x, y)
        elif ch == "c":
            self.blit("tile_cloud", x, y)
        elif ch == "-":
            self.blit("tile_plank", x, y)
        elif ch == "^":
            self.blit("tile_lavatop%d" % frame_of(tick * 0.08 + c * 0.7, 8), x, y)
        elif ch == "~":
            self.blit("tile_lava%d" % frame_of(tick * 0.06 + c, 8), x, y)
        elif ch == "o":
            bob = math.sin(tick * 0.1 + c * 0.5) * 3
            self.blit("tile_star%d" % frame_of(tick * 0.05 + c * 0.4, 12), x, y + bob)

    def draw_flag(self, g):
        fc, fr = g.level.flag_pos
        x, base = fc * G.TILE - g.cam, (fr + 1) * G.TILE
        if x < -120 or x > DW + 120:
            return
        self.blit("flag_pole", x, base)
        fy = base - 250 + g.level.flag_down * 210
        self.blit("flag_pen%d" % frame_of(g.tick * 0.03 * 5, 6), x, fy)

    def draw_enemies(self, g):
        cam, tick = g.cam, g.tick
        for e in g.enemies:
            x = e.x - cam
            if x < -80 or x > DW + 80:
                continue
            if e.dead:
                self.draw_dead(e, x)
                continue
            if e.type == "blob":
                self.blit("blob_%s%d" % ("R" if e.face > 0 else "L", frame_of(e.wob, 8)),
                          x + e.w / 2, e.y + e.h)
            elif e.type == "fly":
                self.blit("fly_%s%d" % ("R" if e.face > 0 else "L", frame_of(tick * 0.35, 8)),
                          x + e.w / 2, e.y + e.h / 2)
            else:
                self.blit("king_flash" if e.hit_flash > 0 else "king_normal",
                          x + e.w / 2, e.y + e.h, flip=e.face < 0)

    def draw_dead(self, e, x):
        d = e.dead
        surf, _, _ = self.sprites["dead_" + e.type]
        K = self.K
        w = max(1, round(e.w * (1 + d * 0.02) * K + 8 * K))
        h = max(1, round(e.h * max(0.12, 1 - d * 0.05) * K + 8 * K))
        key = (e.type, w, h)
        s = self._dead.get(key)
        if s is None:
            s = self._dead[key] = pygame.transform.smoothscale(surf, (w, h))
        s.set_alpha(int(255 * max(0, 1 - d / 26)))
        cx, bottom = (x + e.w / 2) * K, (e.y + e.h) * K
        self.screen.blit(s, (round(cx - w / 2 + self.ox), round(bottom - h + 4 * K + self.oy)))

    def draw_player(self, g):
        p = g.p
        if not g.player_visible():
            return
        anim = g.player_anim()
        size = "b" if p.big else "s"
        cx, bottom = p.x + p.w / 2 - g.cam, p.y + p.h
        if anim == "run":
            name = "run%d" % frame_of(p.run * 4 * 0.42, 8)
        elif anim == "dance":
            name = "dance%d" % frame_of(g.tick * 0.3, 8)
        elif anim == "idle":
            name = "idle"
            bottom += math.sin(g.tick * 0.09) * 1.2
        else:
            name = "jump"
        lift = g.wing_lift()
        if lift is not None:
            self.blit(wing_frame("wings", lift), cx, bottom)
        hat = "_hat" if p.power == "fire" and p.big else ""
        self.blit("danny_%s_%s%s" % (size, name, hat), cx, bottom, flip=p.face < 0)

    def draw_particles(self, g):
        cam = g.cam
        brick = THEME_BRICK.get(g.level.theme, "#d1703f")
        for q in g.parts:
            col = brick if q[6] == "brick" else q[6]
            self.dot(q[0] - cam, q[1], q[5], col, q[4] / 34)
        for s in g.pops:
            self.text(s[2], s[0] - cam, s[1], 18, "#ffffff", "center", "#2b1a45", alpha=s[3] / 50)

    # ------------------------------------------------ HUD & screens
    def draw_hud(self, g):
        ox, oy = self.ox, self.oy
        self.ox = self.oy = 0
        lv = g.level
        self.panel(14, 14, 260, 68 if lv.has_boss else 46, 14, 0.55)
        for i in range(3):
            self.blit("heart_on" if i < g.hearts else "heart_off", 34 + i * 30, 37)
        self.blit("hud_star%d" % frame_of(g.tick * 0.02 * 5, 6), 140, 36)
        self.text("×%d" % g.stars, 156, 37, 22, "#ffffff")
        if g.p.power == "wings":
            self.blit("hud_wings", 240, 40)
        elif g.p.power == "fire":
            self.blit("hud_hat", 240, 44)
        self.text("LEVEL %d" % (g.li + 1), DW - 24, 30, 19, "#ffffff", "right", "#2b1a45")
        self.text(lv.name, DW - 24, 52, 15, "#ffe9a8", "right", "#2b1a45")
        if lv.has_boss:
            for i in range(5):
                self.blit("dia_on" if i < g.p.boss_hp else "dia_off", 34 + i * 15, 60)
            boss = g.boss()
            hp = boss.hp if (boss and not boss.dead) else 0
            if hp > 0:
                self.panel(DW / 2 - 140, 14, 280, 40, 14, 0.55)
                self.text("ICE KING", DW / 2 - 56, 34, 15, "#ffffff", "center", "#2b1a45")
                for i in range(5):
                    self.blit("bossdia_on" if i < hp else "bossdia_off", DW / 2 + 6 + i * 16, 34)
                if abs(boss.x - g.p.x) < 640:
                    self.text("press X to throw snowballs!", DW / 2, 70, 14, "#ffffff",
                              "center", "#2b1a45")
        self.ox, self.oy = ox, oy

    def banner(self, title, sub, color, tick):
        self.shade(0.45)
        y = DH / 2 - 20 + math.sin(tick * 0.08) * 4
        self.text(title, DW / 2, y, 58, color, "center", "#2b1a45")
        self.text(sub, DW / 2, y + 52, 22, "#ffffff", "center", "#2b1a45")

    def draw_gameover(self, g):
        self.shade(0.72)
        self.text("OOPS!", DW / 2, DH / 2 - 50, 62, "#ff8fa8", "center", "#2b1a45")
        self.text("Let's try that level again.", DW / 2, DH / 2 + 6, 24, "#ffffff", "center", "#2b1a45")
        if math.sin(g.tick * 0.09) > -0.3:
            self.text("Press SPACE to try again", DW / 2, DH / 2 + 60, 22, "#ffd23f", "center", "#2b1a45")

    def draw_victory(self, g):
        self.shade(0.6)
        self.draw_particles(g)
        self.text("YOU DID IT!", DW / 2, DH / 2 - 70, 66, "#ffd23f", "center", "#2b1a45")
        self.text("%d stars collected" % g.total_stars, DW / 2, DH / 2 - 8, 28, "#ffffff",
                  "center", "#2b1a45")
        self.blit("danny_t_dance%d" % frame_of(g.tick * 0.3, 8), DW / 2 - 6, DH / 2 + 74)
        if math.sin(g.tick * 0.09) > -0.3:
            self.text("Press SPACE to play again", DW / 2, DH - 46, 20, "#ffffff", "center", "#2b1a45")

    def draw_title(self, g):
        tick = g.tick
        self.screen.blit(self.sprites["bg_title"][0], (0, 0))
        for i in range(6):
            bx = ((tick * 0.4 + i * 160) % 960) - 80
            self.blit("title_cloud", bx, 60 + (i % 3) * 40)
        lx = 250
        y = 108 + math.sin(tick * 0.05) * 5
        self.text("DANNY GO!", lx, y, 62, "#ffd23f", "center", "#2b1a45")
        self.text("JUMP ADVENTURE", lx, y + 46, 26, "#ffffff", "center", "#2b1a45")
        self.blit("danny_t_idle", lx - 2, 354 + math.sin(tick * 0.09) * 1.2)
        if math.sin(tick * 0.09) > -0.3:
            self.text("Press SPACE to start", lx, 388, 22, "#ffffff", "center", "#2b1a45")
        self.text("bounce on enemies to defeat them!", lx, 432, 15, "#ffe9a8", "center", "#2b1a45")
        self.text("M = music on/off      Esc = quit", lx, 460, 13, "#ffffff", "center", "#2b1a45")

        x0, y0, w, h = 556, 66, 226, 396
        cx = x0 + w / 2
        self.panel(x0, y0, w, h, 16, 0.55)
        self.text("How to Play", cx, y0 + 28, 20, "#ffffff", "center", "#2b1a45")
        rows = [("Move", "arrow keys  or  A  D"),
                ("Jump", "up arrow, Space or W"),
                ("Run fast", "hold Ctrl or Shift"),
                ("Throw", "X: fireballs, snowballs"),
                ("Gamepad", "stick + A to jump")]
        yy = y0 + 70
        for label, keys in rows:
            self.text(label, cx, yy, 16, "#ffd23f", "center")
            self.text(keys, cx, yy + 22, 14, "#ffffff", "center")
            yy += 56
        self.text("Blue block: wings to fly!", cx, yy + 6, 13, "#ffe9a8", "center")
        self.text("Orange block: fire hat!", cx, yy + 24, 13, "#ffe9a8", "center")
